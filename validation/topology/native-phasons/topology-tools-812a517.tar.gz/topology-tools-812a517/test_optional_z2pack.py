"""Run the numerical core in a fresh interpreter that rejects Z2Pack imports."""

from pathlib import Path
import subprocess
import sys
import pytest


def test_core_without_z2pack():
    code = """
import sys
from importlib.abc import MetaPathFinder
class BlockZ2Pack(MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.')[0] == 'z2pack':
            raise ModuleNotFoundError('Z2Pack intentionally unavailable')
sys.meta_path.insert(0, BlockZ2Pack())
import cp2k_overlap, phason_system, gaussian_states, topology_mesh, native_phasons
from test_chern import test_rice_mele_pump, test_second_chern_product_pairing
from test_gaussian_states import test_parameter_mesh_sews_endpoint_frames
test_rice_mele_pump()
test_second_chern_product_pairing()
test_parameter_mesh_sews_endpoint_frames()
try:
    import cp2k_z2pack
except ImportError as error:
    assert 'optional adapter' in str(error)
else:
    raise AssertionError('Optional adapter silently accepted missing Z2Pack')
"""
    subprocess.run(
        [sys.executable, "-c", code],
        cwd=Path(__file__).parent,
        check=True,
        capture_output=True,
        text=True,
    )


def test_optional_adapter_compatibility():
    z2pack = pytest.importorskip("z2pack")
    from cp2k_z2pack import CP2KSystem, Z2PackPhasonSystem
    from test_gaussian_states import atom_frame
    from gaussian_states import validate_geometry_seam
    import numpy as np

    assert issubclass(CP2KSystem, z2pack.system.OverlapSystem)
    system = Z2PackPhasonSystem(
        lambda p: (atom_frame(0, phase=0.7 * p[3]), 0),
        lambda a, b, delta: validate_geometry_seam(a[0], b[0], [0], [[0, 0, 0]]),
    )
    result = z2pack.line.run(
        system=system, line=lambda t: [0, 0, 0, t], iterator=[8, 16], pos_tol=1e-8
    )
    assert abs(np.exp(2j * np.pi * result.wcc[0]) - 1) < 1e-12
