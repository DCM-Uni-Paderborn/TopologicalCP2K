"""Check moving-basis exports for bonded/multiorbital, SOC, and MPI cases."""

import argparse
import json
import os
from pathlib import Path
import subprocess
import numpy as np
from cp2k_overlap import nnkp_text, read_loop_mmn
from gaussian_states import read_snapshot, state_overlap, check_frame
from validate_cp2k import ROOT


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("binary", type=Path)
    parser.add_argument("workdir", type=Path)
    args = parser.parse_args()
    root = ROOT
    examples = Path(__file__).with_name("examples")
    helium = (
        (examples / "helium.inp")
        .read_text()
        .replace("EXCLUDE_BANDS 2", "EXCLUDE_BANDS 3")
    )
    helium = helium.replace(
        "He 0.5 0.5 0.5", "He 0.21 0.31 0.41\n      He 0.57 0.42 0.63"
    )
    helium = helium.replace("WILSON_LOOP T", "WILSON_LOOP T\n        STATE_EXPORT T")
    neon = (
        (examples / "neon-soc.inp")
        .read_text()
        .replace(
            "KPOINTS_SOURCE WILSON", "KPOINTS_SOURCE NNKP\n        NNKP_FILE loop.nnkp"
        )
    )
    neon = neon.replace(
        "SEED_NAME neon",
        "SEED_NAME loop\n        STATE_EXPORT T\n        WILSON_LOOP T",
    )
    neon = neon.replace("Z2 T", "Z2 F").replace("Ne 0.5 0.5 0.5", "Ne 0.23 0.31 0.47")
    points = [[0.13, 0.17, 0.09], [0.39, 0.24, -0.08], [1.13, 0.17, 0.09]]
    report = {}
    for name, text, length in [("helium-dimer", helium, 4.0), ("neon-soc", neon, 5.0)]:
        results = []
        for ranks in (1, 2):
            directory = args.workdir.resolve() / f"{name}-{ranks}r"
            directory.mkdir(parents=True, exist_ok=False)
            (directory / "loop.nnkp").write_text(nnkp_text(points, length * np.eye(3)))
            (directory / "input.inp").write_text(text)
            argv = [
                "mpiexec",
                "-n",
                str(ranks),
                str(args.binary.resolve()),
                "-i",
                "input.inp",
            ]
            with (directory / "run.log").open("w") as log:
                subprocess.run(
                    argv,
                    cwd=directory,
                    check=True,
                    stdout=log,
                    stderr=subprocess.STDOUT,
                    env={
                        **os.environ,
                        "CP2K_DATA_DIR": str(root / "data"),
                        "OMP_NUM_THREADS": "2",
                        "OPENBLAS_NUM_THREADS": "1",
                    },
                    timeout=120,
                )
            snapshot = read_snapshot(directory / "loop.topology")
            native = read_loop_mmn(directory / "loop.mmn", points, len(snapshot.bands))
            error = max(
                float(
                    np.max(np.abs(native[0] - state_overlap(snapshot, snapshot, 0, 1)))
                ),
                float(
                    np.max(
                        np.abs(
                            native[1]
                            - state_overlap(
                                snapshot, snapshot, 1, 0, reciprocal_shift=(1, 0, 0)
                            )
                        )
                    )
                ),
            )
            metric = max(check_frame(snapshot, i) for i in range(2))
            assert error < 1e-8 and metric < 1e-8
            values = dict(ranks=ranks, native_overlap_error=error, metric_error=metric)
            print(name, json.dumps(values), flush=True)
            results.append(values)
        report[name] = results
    (args.workdir / "validation.json").write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()
