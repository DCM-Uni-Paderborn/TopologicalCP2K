"""Run real CP2K state-export, moving-basis, seam, and native C1 smoke tests."""

import argparse
import json
from pathlib import Path
import numpy as np
from cp2k_overlap import nnkp_text, read_loop_mmn
from gaussian_states import (
    read_snapshot,
    state_overlap,
    check_frame,
    validate_geometry_seam,
)
from validate_cp2k import run


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("binary", type=Path)
    parser.add_argument("workdir", type=Path)
    args = parser.parse_args()
    binary, root = args.binary.resolve(), args.workdir.resolve()
    root.mkdir(parents=True, exist_ok=True)
    template = Path(__file__).with_name("examples").joinpath("helium.inp").read_text()
    cell = np.array([[5.0, 0.0, 0.0], [1.1, 5.0, 0.0], [0.3, 0.7, 5.0]])
    base = template.replace(
        "ABC 4.0 4.0 4.0", "A 5 0 0\n      B 1.1 5 0\n      C .3 .7 5"
    )
    base = base.replace("WILSON_LOOP T", "WILSON_LOOP T\n        STATE_EXPORT T")
    points = [[0.13, 0.17, 0.09], [0.39, 0.24, -0.08], [1.13, 0.17, 0.09]]
    snapshots, report = {}, {}
    for name, position in [
        ("start", ".23 .31 .47"),
        ("shifted", ".29 .31 .47"),
        ("endpoint", "1.23 .31 .47"),
    ]:
        directory = root / name
        directory.mkdir(exist_ok=True)
        (directory / "loop.nnkp").write_text(nnkp_text(points, cell))
        run(binary, directory, base.replace("He 0.5 0.5 0.5", f"He {position}"))
        snapshot = read_snapshot(directory / "loop.topology")
        snapshots[name] = snapshot
        report[name + "_metric_error"] = max(check_frame(snapshot, i) for i in range(2))
        native = read_loop_mmn(directory / "loop.mmn", points, 1)
        cross = [
            state_overlap(snapshot, snapshot, 0, 1),
            state_overlap(snapshot, snapshot, 1, 0, reciprocal_shift=(1, 0, 0)),
        ]
        error = max(float(np.max(np.abs(a - b))) for a, b in zip(native, cross))
        report[name + "_native_cross_k_error"] = error
        assert error < 1e-8, report
    a, b = snapshots["start"], snapshots["shifted"]
    forward, reverse = state_overlap(a, b), state_overlap(b, a)
    report["cross_geometry_adjoint_error"] = float(
        np.max(np.abs(forward - reverse.conj().T))
    )
    assert report["cross_geometry_adjoint_error"] < 1e-10
    # A changed atomic centre must not silently become an identity connection.
    assert np.linalg.svd(forward, compute_uv=False).min() < 0.999
    # CP2K exports centres in its canonical periodic atom images.
    report["geometry_seam_error"] = validate_geometry_seam(
        a, snapshots["endpoint"], [0], [[0, 0, 0]]
    )
    closure = state_overlap(a, snapshots["endpoint"])
    report["seam_subspace_error"] = float(
        np.max(np.abs(np.linalg.svd(closure, compute_uv=False) - 1))
    )
    assert report["seam_subspace_error"] < 1e-7
    native_c1 = template.replace(
        "KPOINTS_SOURCE NNKP",
        "KPOINTS_SOURCE WILSON\n        CHERN T\n"
        "        WILSON_TRANSVERSE 0 1 0\n        WILSON_MESH 4 3\n"
        "        WILSON_MAX_REFINEMENT 3\n        REQUIRE_GLOBAL_GAP T",
    )
    run(binary, root / "native-chern", native_c1)
    log = (root / "native-chern/run.log").read_text()
    assert "Converged first Chern number: 0" in log
    assert "Sampled indirect gap [eV]:" in log
    report["native_chern"] = 0
    (root / "validation.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
