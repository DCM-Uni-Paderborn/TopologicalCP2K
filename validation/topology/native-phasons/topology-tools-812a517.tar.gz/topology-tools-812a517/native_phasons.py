"""File interfaces for the independent native CP2K phason postprocessor.

Only file preparation and process invocation happen here. Gaussian integrals,
sewing, metric/gap checks and C1/C2 evaluation run in the native executable.
"""

from pathlib import Path
import os
import subprocess
import numpy as np


def write_links(path, links, phase_limit=np.pi / 2):
    links = np.asarray(links, complex)
    dim = links.ndim - 3
    if dim not in (2, 4) or links.shape[-3] != dim:
        raise ValueError("Expected a 2D or 4D link mesh")
    rank = links.shape[-1]
    if links.shape[-2] != rank or rank < 1 or not np.isfinite(links).all():
        raise ValueError("Invalid link matrices")
    shape = links.shape[:dim]
    if min(shape) < 3 or not np.isfinite(phase_limit) or not 0 < phase_limit < np.pi:
        raise ValueError("Invalid mesh resolution or phase limit")
    with Path(path).open("x") as out:
        out.write(f"CP2K_TOPOLOGY_LINKS 1\n{dim} {rank}\n")
        out.write(" ".join(map(str, shape)) + "\n")
        out.write(f"1e-7 1e-7 1e-8 {phase_limit:.17g}\n")
        for reversed_index in np.ndindex(*shape[::-1]):
            index = reversed_index[::-1]
            for axis in range(dim):
                for z in links[index + (axis,)].T.ravel():
                    out.write(f"{z.real:.17g} {z.imag:.17g}\n")


def write_mesh(
    path,
    shape,
    origin,
    k_directions,
    frame_provider,
    permutations,
    *,
    common_energy_reference=False,
    phase_limit=np.pi / 2,
):
    """Provider(index) returns (absolute snapshot filename, one-based point, energy offset).

    Include endpoints: each index runs from zero through shape[axis].
    Permutations are zero-based end-atom -> start-atom maps, one per axis.
    Rank is read from the first snapshot header, not guessed from occupations.
    """
    raw_shape = np.asarray(shape)
    if (
        raw_shape.ndim != 1
        or not np.isfinite(raw_shape).all()
        or np.any(raw_shape != np.floor(raw_shape))
    ):
        raise ValueError("Mesh intervals must be integers")
    shape = tuple(map(int, raw_shape))
    dim = len(shape)
    origin = np.asarray(origin, float)
    directions = np.asarray(k_directions, float)
    raw_maps = np.asarray(permutations)
    if not np.isfinite(raw_maps).all() or np.any(raw_maps != np.floor(raw_maps)):
        raise ValueError("Atom permutations must contain integers")
    maps = raw_maps.astype(int)
    if dim not in (2, 4) or min(shape) < 3 or directions.shape != (dim, 3):
        raise ValueError("Invalid physical mesh")
    if origin.shape != (3,) or not np.isfinite(origin).all():
        raise ValueError("Invalid reciprocal origin")
    if not np.isfinite(directions).all() or np.any(directions != np.floor(directions)):
        raise ValueError("Reciprocal periods must contain integers")
    if not np.isfinite(phase_limit) or not 0 < phase_limit < np.pi:
        raise ValueError("Invalid phase limit")
    if maps.ndim != 2 or maps.shape[0] != dim:
        raise ValueError("One explicit atom permutation per axis is required")
    first_file, _, _ = frame_provider((0,) * dim)
    with Path(first_file).open() as source:
        if source.readline().strip() != "CP2K_TOPOLOGY_STATE 1":
            raise ValueError("Invalid snapshot header")
        nat, _, rank, *_ = map(int, source.readline().split())
    if maps.shape[1] != nat or any(sorted(row) != list(range(nat)) for row in maps):
        raise ValueError("Invalid atom permutation")
    with Path(path).open("x") as out:
        out.write(f"CP2K_PHASON_MESH 1\n{dim} {rank}\n")
        out.write(" ".join(map(str, shape)) + "\n")
        out.write(f"1e-7 1e-7 1e-8 {phase_limit:.17g}\n")
        out.write(" ".join(f"{x:.17g}" for x in origin) + "\n")
        for direction in directions:
            out.write(" ".join(f"{x:.17g}" for x in direction) + "\n")
        out.write(f"{nat} {'T' if common_energy_reference else 'F'}\n")
        for permutation in maps:
            out.write(" ".join(str(i + 1) for i in permutation) + "\n")
        for reverse in np.ndindex(*(np.asarray(shape) + 1)[::-1]):
            filename, point, offset = frame_provider(reverse[::-1])
            if (
                not np.isfinite(point)
                or point != int(point)
                or point < 1
                or not np.isfinite(offset)
            ):
                raise ValueError("Invalid snapshot point or energy offset")
            filename = str(Path(filename).resolve(strict=True))
            if '"' in filename or "\n" in filename or len(filename) > 1024:
                raise ValueError("Unsupported snapshot path")
            out.write(f'"{filename}" {int(point)} {offset:.17g}\n')


def run_native(binary, mode, path, *, threads=1):
    result = subprocess.run(
        [str(Path(binary).resolve()), mode, str(Path(path).resolve())],
        capture_output=True,
        text=True,
        env={
            **os.environ,
            "OMP_NUM_THREADS": str(threads),
            "OPENBLAS_NUM_THREADS": "1",
        },
    )
    if result.returncode:
        raise RuntimeError(result.stdout + result.stderr)
    values = {}
    for line in result.stdout.splitlines():
        fields = line.split()
        if len(fields) == 2:
            try:
                values[fields[0]] = float(fields[1])
            except ValueError:
                pass
    return values, result.stdout
