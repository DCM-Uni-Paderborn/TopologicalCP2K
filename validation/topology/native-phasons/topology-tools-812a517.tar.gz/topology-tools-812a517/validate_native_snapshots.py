"""Compare native integrals and phason meshes against archived CP2K validation runs.

Uses no Z2Pack and performs no new SCF or graphene calculation.
"""

import argparse
import json
import os
from pathlib import Path
import subprocess
import numpy as np
from gaussian_states import read_snapshot, state_overlap
from native_phasons import write_mesh, run_native


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("binary", type=Path)
    parser.add_argument("archive", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    binary, root = args.binary.resolve(), args.archive.resolve()
    report = {}
    frames = [
        root / "post-merge-states/start/loop.topology",
        root / "post-merge-states/shifted/loop.topology",
        root / "final-variants/helium-dimer-1r/loop.topology",
        root / "final-variants/neon-soc-1r/loop.topology",
    ]
    for index, path in enumerate(frames):
        a = read_snapshot(path)
        for pa, pb, shift in [(0, 1, (0, 0, 0)), (1, 0, (1, 0, 0))]:
            reference = state_overlap(a, a, pa, pb, reciprocal_shift=shift)
            for threads in (1, 2):
                result = subprocess.run(
                    [
                        str(binary),
                        "overlap",
                        str(path),
                        str(pa + 1),
                        str(path),
                        str(pb + 1),
                        *map(str, shift),
                    ],
                    capture_output=True,
                    text=True,
                    check=True,
                    env={
                        **os.environ,
                        "OMP_NUM_THREADS": str(threads),
                        "OPENBLAS_NUM_THREADS": "1",
                    },
                )
                rows = result.stdout.split("OVERLAP ", 1)[1].splitlines()
                rank = int(rows[0])
                values = np.loadtxt(rows[1 : 1 + rank * rank], ndmin=2)
                native = (values[:, 0] + 1j * values[:, 1]).reshape(rank, rank).T
                error = float(np.max(np.abs(native - reference)))
                assert error < 1e-10, (path, error)
                report[f"overlap_{index}_{pa}_{threads}"] = error
    a, b = map(read_snapshot, frames[:2])
    reference = state_overlap(a, b)
    result = subprocess.run(
        [
            str(binary),
            "overlap",
            str(frames[0]),
            "1",
            str(frames[1]),
            "1",
            "0",
            "0",
            "0",
        ],
        check=True,
        capture_output=True,
        text=True,
        env={**os.environ, "OMP_NUM_THREADS": "2", "OPENBLAS_NUM_THREADS": "1"},
    )
    rows = result.stdout.split("OVERLAP ", 1)[1].splitlines()
    values = np.loadtxt(rows[1:], ndmin=2)
    report["moving_basis_error"] = float(
        np.max(
            np.abs(
                (values[:, 0] + 1j * values[:, 1]).reshape(reference.shape).T
                - reference
            )
        )
    )
    assert report["moving_basis_error"] < 1e-10
    for n in (4, 8, 12):
        source_n = 8 if n == 4 else n
        stride = source_n // n

        def provider(index):
            k, phi = index
            return (
                root
                / f"atomic-pump-{source_n}/displacement-{phi * stride:03d}/loop.topology",
                (k * stride) % source_n + 1,
                0.0,
            )

        path = args.output / f"pump-{n}.mesh"
        write_mesh(
            path, [n, n], [0, 0, 0], [[1, 0, 0], [0, 0, 0]], provider, [[0], [0]]
        )
        result, log = run_native(binary, "mesh", path, threads=2)
        (args.output / f"pump-{n}.log").write_text(log)
        assert abs(result["CHERN_RAW"] + 1) < 1e-10
        report[f"pump_{n}"] = result
    result = subprocess.run(
        [
            str(binary),
            "converge",
            str(args.output / "pump-4.mesh"),
            str(args.output / "pump-8.mesh"),
            "1e-8",
        ],
        capture_output=True,
        text=True,
        check=True,
        env={**os.environ, "OMP_NUM_THREADS": "2", "OPENBLAS_NUM_THREADS": "1"},
    )
    assert "REFINEMENT_CHECK_PASSED" in result.stdout
    (args.output / "pump-refinement.log").write_text(result.stdout)
    report["physical_refinement_passed"] = True
    n = 4

    def provider4(index):
        kx, ky, px, py = index
        return (
            root / f"atomic-pump-4d-4/translation-{px:03d}-{py:03d}/loop.topology",
            (kx % n) * n + ky % n + 1,
            0.0,
        )

    path = args.output / "pump-4d.mesh"
    write_mesh(
        path,
        [n] * 4,
        [0, 0, 0],
        [[1, 0, 0], [0, 1, 0], [0, 0, 0], [0, 0, 0]],
        provider4,
        [[0]] * 4,
    )
    result, log = run_native(binary, "mesh", path, threads=2)
    (args.output / "pump-4d.log").write_text(log)
    assert abs(result["CHERN_RAW"] + 1) < 1e-10
    report["pump_4d"] = result
    (args.output / "validation.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
