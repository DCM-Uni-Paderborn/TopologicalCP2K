"""Optional Z2Pack adapters; all numerical kernels live in independent modules."""

try:
    from z2pack.system import OverlapSystem
except ImportError as error:
    raise ImportError(
        "The optional adapter requires pip install 'cp2k-topology-tools[z2pack]'. "
        "Use cp2k_overlap and phason_system for calculations without Z2Pack."
    ) from error

from cp2k_overlap import CP2KOverlapSystem, nnkp_text, read_loop_mmn
from phason_system import PhasonSystem

__all__ = ["CP2KSystem", "Z2PackPhasonSystem", "nnkp_text", "read_loop_mmn"]


class CP2KSystem(CP2KOverlapSystem, OverlapSystem):
    """CP2K provider implementing Z2Pack's optional OverlapSystem interface."""


class Z2PackPhasonSystem(PhasonSystem, OverlapSystem):
    """Optional adapter for the independent moving-basis phason provider."""
