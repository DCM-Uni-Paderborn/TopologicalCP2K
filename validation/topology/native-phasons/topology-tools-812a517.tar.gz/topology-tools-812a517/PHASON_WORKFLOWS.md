# Chern numbers, spectral gaps, and sliding geometries

## Native execution without Z2Pack

The `topology-native-phasons` extension adds CP2K's `topology_phasons` executable.
It uses CP2K Gaussian integrals for cross-geometry links and native C1/C2 kernels.
It streams link matrices to an anonymous scratch file and evaluates plaquettes
one vertex at a time. Atom-row contractions use OpenMP, not a dense AO operator.
Run one process with the desired `OMP_NUM_THREADS`.

`native_phasons.write_mesh` prepares a physical manifest from existing snapshots;
its provider returns `(snapshot_path, one_based_point, energy_offset_hartree)`.
For example, for a mixed `(kx,phi)` family with one atom:

```python
from native_phasons import write_mesh, run_native

write_mesh("coarse.mesh", [8, 8], [0, 0, 0],
           [[1, 0, 0], [0, 0, 0]], provider, [[0], [0]])
result, log = run_native("/path/topology_phasons.psmp", "mesh", "coarse.mesh", threads=4)
```

The provider must include endpoint geometries. K-points can be represented modulo
reciprocal vectors, which the native reader restores from the manifest. The full
manifest format and a Python-free workflow are documented in CP2K's
`docs/methods/electronic_structure/phason-topology.md`.

```sh
topology_phasons.psmp converge coarse.mesh fine.mesh 0.01
```

Every fine axis must refine the coarse grid by an integer factor of at least two.
The native checks compare the unrounded estimates and the fine integer residual.
For C2, mesh admissibility alone does not establish convergence.

Both the Python reference kernels and the native workflow run without Z2Pack.
`PhasonSystem` is independent; use `cp2k_z2pack.Z2PackPhasonSystem` only when passing
the provider to the optional external Z2Pack driver.

This guide accompanies the CP2K `topology-chern-phasons` follow-up to #6038.
Run the commands below from this package checkout. Set `CP2K_SOURCE_DIR` to the matching
CP2K source tree for native-kernel comparisons and manual DFT validators. Python-only tests
remain available without a CP2K checkout; native comparisons are skipped in that case.


The sections below document the native reciprocal-space calculation and the
independent Python reference algorithms. The native postprocessor described above
also supports moving-basis/phason and four-dimensional meshes. Neither route adds
SOC, a magnetic field or a change to the Hamiltonian implicitly. The original Z2
route and its restrictions are unchanged.

### Native first Chern number and gap diagnostics

For a full closed reciprocal-space surface, use for example:

```text
&WANNIER90
  KPOINTS_SOURCE WILSON
  CHERN T
  WILSON_DIRECTION 1 0 0
  WILSON_TRANSVERSE 0 1 0
  WILSON_MESH 16 17
  WILSON_MAX_REFINEMENT 3
  EXCLUDE_BANDS ...
  REQUIRE_GLOBAL_GAP T
&END
```

Replace the illustrative exclusions with the correct band indices. `CHERN` requires integer
transverse winding and is incompatible with a Z2 half-surface. It returns determinant-Wilson-phase
winding in the Z2Pack sign convention. The native code requires endpoint closure, resolved phase
steps, stable integer winding, and converged WCC under joint refinement. It supports isolated
scalar, collinear-channel, or second-variational SOC subspaces without imposing time reversal. No
physical Hall response is inferred solely from the keyword.

For a selected lowest-band prefix, output distinguishes the minimum sampled direct separation from
`min(E[N+1]) - max(E[N])`, the sampled indirect gap. The former can be positive while the latter is
negative. `REQUIRE_GLOBAL_GAP` is optional: it rejects the latter case but is not required for the
mathematics of an isolated band bundle. It requires an excluded band above the prefix. All values
use the same potential/energy reference; no individual Fermi shifts are made. Finite sampling does
not rule out a missed gap closing. Across separately self-consistent geometries, choose and document
a common energy reference before interpreting an indirect gap; `gap_diagnostics` never invents an
alignment.

### Physical cross-geometry overlaps

`STATE_EXPORT T` writes `SEED_NAME.topology` for explicit NNKP/WILSON points. Version 1 stores
lattice vectors and periodicity, canonical periodic atomic centres, atom/AO dimensions, Gaussian
exponents and screening radii, Cartesian powers and complete spherical contraction matrices,
selected complex AO coefficients, and **all computed** eigenvalues. Lengths and energies are in bohr
and Hartree. SOC coefficients contain both physical spinor components; a scalar UKS export
identifies its single selected channel. Text output can be large.

`gaussian_states.read_snapshot` rejects incomplete files. `state_overlap` analytically evaluates the
directed Gaussian operator between two snapshots, including shifted centres, nonorthogonality, Bloch
phases, and reciprocal seam vectors. This independent reference evaluator reproduces the native
operator and does not replace it. Its dense atom/image loops are suitable for validation and small
examples, **not yet for production-scale graphene calculations**. Cell changes are rejected. Keep
the atom count, physical orbital basis, rank, spin convention, and converged SCF branch consistent
along the family.

The `PhasonSystem` adapter accepts a provider returning `(snapshot, point_index)` for
`(kx, ky, kz, phi1, ...)` and a mandatory seam validator. Phasons are normalized to their declared
periods. The provider may load precomputed snapshots or run CP2K with translated coordinates. Each
new geometry needs its own consistent SCF potential. At a fixed geometry, the SCF mesh and potential
must not depend on the Wilson loop requested by Z2Pack. Converge the underlying SCF mesh separately.

Before each link, the adapter checks AO-metric normalization and sampled selected/excluded band
separation. Endpoint geometry sewing must be declared explicitly, e.g. with `validate_geometry_seam`
and its atom permutation/lattice translations. Endpoint subspaces are checked as well; their polar
sewing matrix closes the Wilson product despite independent eigenvector gauges. Rebuilding a finite
patch by dropping/adding atoms is not a valid fixed-rank phason cycle.

```python
from phason_system import PhasonSystem
from topology_mesh import first_chern, second_chern

# User functions: physically consistent snapshots and endpoint geometry checks.
system = PhasonSystem(frame_provider, seam_validator)
# Example full (kx, phi_x) torus, parameters (kx, ky, kz, phi_x).
links = system.mesh([0, 0, 0, 0], [[1, 0, 0, 0], [0, 0, 0, 1]], [16, 16])
result = first_chern(links)
print(result, system.last_diagnostics)
```

The same adapter's `get_mmn` can be used by Z2Pack on a parameterized surface. The automatic mesh
helper also supports four independent parameter directions, for example `(kx, ky, phi_x, phi_y)`
embedded in the five coordinates `(kx, ky, kz, phi_x, phi_y)`. Physical periodicity and a bulk
interpretation must be justified for the chosen periodic approximant; the adapter cannot establish
them for a finite patch or infer them from a butterfly image.

### Four-dimensional second Chern pairing

`topology_mesh.second_chern` uses the principal matrix logarithm of non-Abelian polar-link
plaquettes, retaining matrix information rather than just determinant phases. The oriented estimator
is

`-sum Tr(F01 F23 - F02 F13 + F03 F12)/(4*pi**2)`.

Here `F` is anti-Hermitian and already includes each plaquette area. This is the physics second
Chern **character pairing**, not the Z2 index and not the second Chern class `c2` when first Chern
classes are nonzero. In particular, the product of two line bundles has this pairing equal to the
product of their C1 values. The chosen C1 sign agrees with native/Z2Pack Wilson winding;
simultaneous curvature-sign reversal leaves this C2 convention unchanged. Reversing one axis
reverses the pairing.

Unlike determinant-plaquette C1, this C2 estimator is **not exactly integer on a finite mesh**. The
API reports the unrounded value, mesh, minimum link singular value, and largest plaquette
eigenphase. Singular links and phases near the log branch cut are rejected, but admissibility is not
convergence. Repeat on finer meshes and test orientation and non-Abelian gauge invariance. Do not
turn a coarse value into a claimed invariant by integer rounding. This is a reference
implementation. The separate native postprocessor now implements the same pairing;
it is not a keyword that changes an SCF calculation. Physical material interpretation
still requires a justified family and convergence.

### Reproducible tests

```sh
python -m pytest -q test_topology.py test_chern.py test_gaussian_states.py
python validate_phason_states.py /path/cp2k.psmp /path/new-state-tests
python validate_state_variants.py /path/cp2k.psmp /path/new-mpi-state-tests
python validate_atomic_pump.py /path/cp2k.psmp /path/new-pump-8 --mesh 8
python validate_atomic_pump.py /path/cp2k.psmp /path/new-pump-12 --mesh 12
python validate_atomic_pump_4d.py /path/cp2k.psmp /path/new-pump-4d --mesh 4
python validate_chern_mesh.py /path/new-c2-report.json --mesh 8 16 24 32
```

The package tests cover known C1=0,+1,-1 models against native Fortran, Z2Pack, and an independent plaquette
algorithm; a Rice-Mele pump; moving-Gaussian overlaps; seam/gauge failures; and small C2
Dirac/product-bundle tests. A short registered helium test exercises native CHERN, the positive-gap
guard, and the state export. The larger DFT/MPI/pump and 4D refinement studies are manual tests
only.

Local extension validation (2026-09-17): helium/dimer and neon SOC snapshots match native cross-k
overlaps within 7e-15, including reciprocal closure and one/two MPI ranks. Both 8x8 and 12x12
sliding-helium electronic pumps give C1=-1 with metric and seam errors below 4e-15. Two independent
translations on a 4x4x4x4 `(kx, ky, phi_x, phi_y)` mesh give the expected C2=-1, using 25 CP2K
geometries and physical moving-basis links. This separable atomic test exercises the full
export/link/sewing workflow but is not a convergence test for a general non-Abelian material
calculation. These pumps are validation models, not results for graphene or for net
electron-plus-ion transport. For the 4D Dirac reference with mass -3, lower doublet and ordered
gamma product -I, the exact pairing is -1. Meshes 8,16,24,32 give
-0.742413,-0.928890,-0.967823,-0.981781. This establishes the expected refinement trend while
displaying, not hiding, the remaining 1.82% error of the finest test.

### Additional method references

- [Fukui, Hatsugai and Suzuki, J. Phys. Soc. Jpn. 74, 1674 (2005)](https://doi.org/10.1143/JPSJ.74.1674)
- [Mochol-Grzelak et al., Efficient algorithm to compute the second Chern number in four dimensional systems](https://arxiv.org/abs/1803.07003)
- [Rosa, Ruzzene and Prodan, Topological gaps by twisting](https://doi.org/10.1038/s42005-021-00630-3)
