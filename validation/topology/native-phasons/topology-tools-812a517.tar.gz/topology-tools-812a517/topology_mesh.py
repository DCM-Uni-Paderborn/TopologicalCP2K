"""Gauge-covariant link analysis on closed two- and four-parameter tori.

Links include the physical sewing operation at each periodic seam. Arrays have
shape (*mesh, dimension, rank, rank), with no repeated endpoints. Orientations
follow the listed parameter order. Four-dimensional output is the second Chern
character pairing (the conventional physics C2), not a Z2 invariant. Its lattice
estimator is NOT exactly quantized and must be converged before interpretation.
"""

from dataclasses import dataclass
import numpy as np


@dataclass(frozen=True)
class MeshResult:
    value: float
    minimum_singular_value: float
    maximum_plaquette_phase: float
    mesh: tuple


def polar_links(links, singular_tol=1e-8):
    links = np.asarray(links, dtype=complex)
    dimension = links.ndim - 3
    if dimension not in (2, 4) or links.shape[-3] != dimension:
        raise ValueError("Expected a two- or four-dimensional periodic link mesh")
    if links.shape[-1] < 1 or links.shape[-2] != links.shape[-1]:
        raise ValueError("Links must have a constant positive square rank")
    if min(links.shape[:dimension]) < 3 or not np.isfinite(links).all():
        raise ValueError("A finite mesh of at least three points per axis is required")
    if not np.isfinite(singular_tol) or not 0 < singular_tol < 1:
        raise ValueError("Invalid singular-value tolerance")
    u, s, vh = np.linalg.svd(links)
    minimum = float(s.min())
    if minimum <= singular_tol:
        raise ValueError("Singular subspace link: refine the mesh or check the gap")
    return u @ vh, minimum


def adjoint(a):
    return a.conj().swapaxes(-1, -2)


def plaquette(links, mu, nu):
    """Ordered plaquette based at x; every factor has compatible endpoint gauges."""
    um, un = links[..., mu, :, :], links[..., nu, :, :]
    return (
        um @ np.roll(un, -1, axis=mu) @ adjoint(np.roll(um, -1, axis=nu)) @ adjoint(un)
    )


def first_chern(links, *, phase_limit=np.pi / 2, singular_tol=1e-8):
    """Determinant-plaquette C1 in the native/Z2Pack Wilson-winding convention.

    Positive Wilson winding along the second coordinate is minus the ordered
    (first, second) plaquette phase for links <u(x)|u(x+dx)>. No integer rounding.
    """
    u, minimum = polar_links(links, singular_tol)
    if u.ndim != 5:
        raise ValueError("C1 requires two parameter dimensions")
    phase = np.angle(np.linalg.det(plaquette(u, 0, 1)))
    maximum = float(np.max(np.abs(phase)))
    if not 0 < phase_limit < np.pi or maximum >= phase_limit:
        raise ValueError("Unresolved determinant plaquette phase")
    return MeshResult(float(-phase.sum() / (2 * np.pi)), minimum, maximum, u.shape[:2])


def second_chern(links, *, phase_limit=np.pi / 2, singular_tol=1e-8):
    r"""C2 = -sum Tr(F01 F23 - F02 F13 + F03 F12)/(4 pi^2).

    F is the principal anti-Hermitian matrix logarithm of each polar-link
    plaquette, based at the same vertex. The link lengths are already absorbed
    in F. Unlike C1's determinant, this retains the non-Abelian information.
    Values approach the continuum pairing with mesh refinement. The admissible
    phase check alone is NOT a convergence certificate.
    """
    from scipy.linalg import schur

    u, minimum = polar_links(links, singular_tol)
    if u.ndim != 7:
        raise ValueError("C2 requires four parameter dimensions")
    if not 0 < phase_limit < np.pi:
        raise ValueError("Invalid plaquette phase limit")
    curvature = {}
    maximum = 0.0
    rank = u.shape[-1]
    for mu in range(4):
        for nu in range(mu + 1, 4):
            p = plaquette(u, mu, nu)
            f = np.empty_like(p)
            for src, dst in zip(p.reshape(-1, rank, rank), f.reshape(-1, rank, rank)):
                t, v = schur(src, output="complex")
                angles = np.angle(np.diag(t))
                maximum = max(maximum, float(np.max(np.abs(angles))))
                if maximum >= phase_limit:
                    raise ValueError("Unresolved non-Abelian plaquette phase")
                dst[:] = (v * (1j * angles)) @ v.conj().T
            curvature[mu, nu] = f
    integrand = (
        curvature[0, 1] @ curvature[2, 3]
        - curvature[0, 2] @ curvature[1, 3]
        + curvature[0, 3] @ curvature[1, 2]
    )
    value = -np.trace(integrand, axis1=-2, axis2=-1).real.sum() / (4 * np.pi**2)
    return MeshResult(float(value), minimum, maximum, u.shape[:4])


def links_from_states(states):
    """Links in a fixed orthonormal, strictly periodic basis (model tests only).

    Do not pass CP2K AO coefficient vectors here: their moving basis requires
    cross-geometry overlap operators. Physical seam maps must already have been
    represented in the fixed-periodic states supplied to this helper.
    """
    states = np.asarray(states, dtype=complex)
    dimension = states.ndim - 2
    if dimension not in (2, 4) or not np.isfinite(states).all():
        raise ValueError("Invalid model state mesh")
    if not np.allclose(
        adjoint(states) @ states, np.eye(states.shape[-1]), atol=1e-9, rtol=0
    ):
        raise ValueError("States are not orthonormal in the supplied representation")
    return np.stack(
        [adjoint(states) @ np.roll(states, -1, axis=d) for d in range(dimension)],
        axis=-3,
    )


def gap_diagnostics(energies, nselected):
    """Separate sampled direct isolation from an indirect gap, without EF shifts."""
    e = np.asarray(energies, dtype=float)
    if e.ndim < 2 or not np.isfinite(e).all():
        raise ValueError("Expected finite ordered spectra at multiple parameter points")
    if (
        isinstance(nselected, bool)
        or int(nselected) != nselected
        or not 0 < nselected < e.shape[-1]
    ):
        raise ValueError("An integer selected rank and a band above it are required")
    if np.any(np.diff(e, axis=-1) < 0):
        raise ValueError("Eigenvalues must be sorted")
    vb, cb = e[..., nselected - 1], e[..., nselected]
    return dict(
        direct_gap=float(np.min(cb - vb)),
        indirect_gap=float(cb.min() - vb.max()),
        valence_max=float(vb.max()),
        conduction_min=float(cb.min()),
        rank=int(nselected),
    )
