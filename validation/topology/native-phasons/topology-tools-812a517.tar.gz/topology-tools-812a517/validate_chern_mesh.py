"""Manual C2 refinement study; keeps unrounded values and diagnostics in JSON."""

import argparse
from dataclasses import asdict
import json
from pathlib import Path
import numpy as np
from topology_mesh import links_from_states, second_chern


def dirac_states(n, mass):
    sx = np.array([[0, 1], [1, 0]], complex)
    sy = np.array([[0, -1j], [1j, 0]], complex)
    sz = np.diag([1.0, -1.0])
    gamma = [
        np.kron(sx, sx),
        np.kron(sx, sy),
        np.kron(sx, sz),
        np.kron(sy, np.eye(2)),
        np.kron(sz, np.eye(2)),
    ]
    k = np.stack(
        np.meshgrid(*([2 * np.pi * np.arange(n) / n] * 4), indexing="ij"), axis=-1
    )
    h = sum(np.sin(k[..., i])[..., None, None] * gamma[i] for i in range(4))
    h += (mass + np.cos(k).sum(axis=-1))[..., None, None] * gamma[4]
    return np.linalg.eigh(h)[1][..., :2]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("--mesh", nargs="+", type=int, default=[8, 12, 16])
    parser.add_argument("--mass", type=float, default=-3.0)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("Choose a new report path; existing evidence is not overwritten")
    if any(n < 4 for n in args.mesh) or any(
        b <= a for a, b in zip(args.mesh, args.mesh[1:])
    ):
        parser.error("Use increasing mesh sizes >=4")
    if args.mass in [-4, -2, 0, 2, 4]:
        parser.error("The Dirac reference is gapless at this mass")
    from math import comb

    # Lower doublet for ordered Gamma1...Gamma5=-I: C2=-degree(d/|d|).
    expected = -sum(
        comb(4, j) * (-1) ** j for j in range(5) if args.mass + 4 - 2 * j > 0
    )
    results = []
    for n in args.mesh:
        result = asdict(second_chern(links_from_states(dirac_states(n, args.mass))))
        result["absolute_error"] = abs(result["value"] - expected)
        results.append(result)
        print(json.dumps(result), flush=True)
    report = dict(
        model="4D lattice Dirac, lower doublet",
        mass=args.mass,
        expected_pairing=expected,
        orientation="kx,ky,kz,kw",
        results=results,
        note="Finite-mesh estimators are not rounded and are not an atomistic topology result.",
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()
