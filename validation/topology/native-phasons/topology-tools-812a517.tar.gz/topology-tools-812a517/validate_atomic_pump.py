"""End-to-end CP2K sliding-atom pump on a mixed (kx, displacement) torus.

This deliberately small electronic pump validates moving Gaussian bases and
sewing. It is not a graphene model or a prediction of net electron+ion transport.
"""

import argparse
from dataclasses import asdict
import json
from pathlib import Path
import numpy as np
from cp2k_overlap import nnkp_text
from gaussian_states import read_snapshot, validate_geometry_seam
from phason_system import PhasonSystem
from topology_mesh import first_chern
from validate_cp2k import run


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("binary", type=Path)
    parser.add_argument("workdir", type=Path)
    parser.add_argument("--mesh", type=int, default=8)
    args = parser.parse_args()
    n = args.mesh
    if n < 6:
        parser.error("Use at least six samples per axis")
    root = args.workdir.resolve()
    root.mkdir(parents=True, exist_ok=False)
    template = Path(__file__).with_name("examples").joinpath("helium.inp").read_text()
    template = template.replace(
        "WILSON_LOOP T", "WILSON_LOOP T\n        STATE_EXPORT T"
    )
    template = template.replace("ABC 4.0 4.0 4.0", "ABC 5.0 5.0 5.0")
    points = np.zeros((n + 1, 3))
    points[:, 0] = np.linspace(0, 1, n + 1)
    frames = []
    for j in range(n + 1):
        directory = root / f"displacement-{j:03d}"
        directory.mkdir()
        (directory / "loop.nnkp").write_text(nnkp_text(points, 5 * np.eye(3)))
        text = template.replace("He 0.5 0.5 0.5", f"He {0.13 + j/n:.17g} 0.31 0.47")
        run(args.binary.resolve(), directory, text)
        frames.append(read_snapshot(directory / "loop.topology"))
        print(f"DFT geometry {j+1}/{n+1} complete", flush=True)

    def provider(p):
        ix, ip = int(round(p[0] * n)), int(round(p[3] * n))
        if not 0 <= ix <= n or not 0 <= ip <= n:
            raise ValueError("Requested point outside the stored parameter mesh")
        return frames[ip], ix % n

    def seam(a, b, delta):
        # Wrapped centres coincide for a complete cell translation.
        validate_geometry_seam(a[0], b[0], [0], [[0, 0, 0]])

    system = PhasonSystem(provider, seam)
    links = system.mesh([0, 0, 0, 0], [[1, 0, 0, 0], [0, 0, 0, 1]], [n, n])
    result = first_chern(links)
    assert abs(result.value + 1) < 1e-10, result
    np.savez_compressed(root / "links.npz", links=links, axes=np.array(["kx", "phi_x"]))
    report = dict(
        result=asdict(result),
        diagnostics=system.last_diagnostics,
        expected=-1,
        scope="Electronic sliding-atom pump, not a material prediction",
    )
    (root / "validation.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
