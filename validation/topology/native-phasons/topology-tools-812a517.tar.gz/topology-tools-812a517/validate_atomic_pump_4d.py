"""Manual 4D CP2K snapshot/sewing test: two independent atomic translations.

Axes (kx,ky,phi_x,phi_y) have pairing -1, opposite to the product ordering
(kx,phi_x,ky,phi_y). A small helium validation model, not a graphene result.
"""

import argparse
from dataclasses import asdict
import json
from pathlib import Path
import numpy as np
from cp2k_overlap import nnkp_text
from gaussian_states import read_snapshot, validate_geometry_seam
from phason_system import PhasonSystem
from topology_mesh import second_chern
from validate_cp2k import run


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("binary", type=Path)
    parser.add_argument("workdir", type=Path)
    parser.add_argument("--mesh", type=int, default=4)
    parser.add_argument(
        "--analyze-only",
        action="store_true",
        help="Reanalyze snapshots from an existing run with the same mesh",
    )
    args = parser.parse_args()
    n = args.mesh
    if n < 4:
        parser.error("Use at least four points per axis")
    root = args.workdir.resolve()
    if not args.analyze_only:
        root.mkdir(parents=True, exist_ok=False)
    template = Path(__file__).with_name("examples").joinpath("helium.inp").read_text()
    template = template.replace(
        "WILSON_LOOP T", "WILSON_LOOP F\n        STATE_EXPORT T"
    )
    template = template.replace("ABC 4.0 4.0 4.0", "ABC 5.0 5.0 5.0")
    points = [[i / n, j / n, 0] for i in range(n) for j in range(n)] + [[0, 0, 0]]
    frames = {}
    for i in range(n + 1):
        for j in range(n + 1):
            directory = root / f"translation-{i:03d}-{j:03d}"
            if not args.analyze_only:
                directory.mkdir()
                (directory / "loop.nnkp").write_text(nnkp_text(points, 5 * np.eye(3)))
                text = template.replace(
                    "He 0.5 0.5 0.5", f"He {0.13+i/n:.17g} {0.31+j/n:.17g} 0.47"
                )
                run(args.binary.resolve(), directory, text)
            frames[i, j] = read_snapshot(directory / "loop.topology")
            if not np.allclose(frames[i, j].kpoints, points[:-1], atol=1e-12):
                raise ValueError("Snapshot mesh does not match the requested mesh")
        print(f"Translation row {i+1}/{n+1} complete", flush=True)

    def provider(p):
        ix, iy, _, px, py = np.rint(np.asarray(p) * n).astype(int)
        return frames[px, py], (ix % n) * n + iy % n

    def seam(a, b, delta):
        validate_geometry_seam(a[0], b[0], [0], [[0, 0, 0]])

    system = PhasonSystem(provider, seam)
    directions = np.eye(5)[[0, 1, 3, 4]]
    links = system.mesh(np.zeros(5), directions, [n] * 4)
    result = second_chern(links)
    assert abs(result.value + 1) < 0.02, result
    report = dict(
        result=asdict(result),
        diagnostics=system.last_diagnostics,
        expected=-1,
        scope="Two-translation electronic atomic reference, not a graphene result",
    )
    print(json.dumps(report, indent=2))
    (root / "validation.json").write_text(json.dumps(report, indent=2) + "\n")
    np.savez_compressed(
        root / "links.npz", links=links, axes=np.array(["kx", "ky", "phi_x", "phi_y"])
    )


if __name__ == "__main__":
    main()
