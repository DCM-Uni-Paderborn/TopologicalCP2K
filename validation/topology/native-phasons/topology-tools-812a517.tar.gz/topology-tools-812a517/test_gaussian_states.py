"""Moving basis, metric and physical seam tests independent of CP2K execution."""

from dataclasses import replace
import numpy as np
import pytest
from gaussian_states import (
    Shell,
    Snapshot,
    cross_ao,
    state_overlap,
    check_frame,
    check_isolation,
    validate_geometry_seam,
)
from phason_system import PhasonSystem
from topology_mesh import first_chern


def atom_frame(x=0, phase=0):
    center = np.array([x, 0.0, 0.0])
    shell = Shell(
        center,
        np.array([0]),
        np.array([1.0]),
        np.array([5.0]),
        np.array([[0, 0, 0]]),
        np.array([[[(2 / np.pi) ** 0.75]]]),
        5.0,
    )
    return Snapshot(
        20 * np.eye(3),
        np.zeros(3, int),
        center[None],
        np.array([1]),
        np.array([1]),
        [shell],
        np.array([0]),
        np.zeros((1, 3)),
        np.array([[-1.0, 1.0]]),
        np.array([[[[np.exp(1j * phase)]]]]),
        1,
    )


def test_displaced_gaussian_is_not_euclidean_coeff_overlap():
    a, b = atom_frame(), atom_frame(0.7)
    assert check_frame(a) < 1e-14
    assert state_overlap(a, b)[0, 0] == pytest.approx(np.exp(-(0.7**2) / 2))
    assert np.allclose(state_overlap(a, b), state_overlap(b, a).conj().T, atol=1e-14)
    changed = replace(b, coefficients=b.coefficients * np.exp(0.3j))
    assert state_overlap(a, changed)[0, 0] == pytest.approx(
        np.exp(-(0.7**2) / 2 + 0.3j)
    )
    with pytest.raises(ValueError, match="same cell"):
        cross_ao(a, replace(b, cell=21 * np.eye(3)), [0, 0, 0], [0, 0, 0])


def test_phason_adapter_closes_endpoint_gauge():
    def provider(p):
        return atom_frame(0.3 * np.sin(2 * np.pi * p[3]), phase=0.7 * p[3]), 0

    def seam(a, b, delta):
        validate_geometry_seam(a[0], b[0], [0], [[0, 0, 0]])

    system = PhasonSystem(provider, seam)
    points = [[0, 0, 0, t] for t in np.linspace(0, 1, 9)]
    links = system.get_mmn(points)
    assert np.prod(np.array(links)[:, 0, 0]) == pytest.approx(1.0, abs=1e-13)
    assert system.last_diagnostics["seam_subspace_error"] < 1e-13


def test_invalid_phason_closure_and_metric_rejected():
    def seam(a, b, delta):
        validate_geometry_seam(a[0], b[0], [0], [[0, 0, 0]])

    system = PhasonSystem(lambda p: (atom_frame(p[3]), 0), seam)
    with pytest.raises(ValueError, match="does not close"):
        system.get_mmn([[0, 0, 0, t] for t in [0, 0.5, 1]])
    a = atom_frame()
    with pytest.raises(ValueError, match="not normalized"):
        check_frame(replace(a, coefficients=2 * a.coefficients))
    with pytest.raises(ValueError, match="integer"):
        state_overlap(a, a, reciprocal_shift=[0.5, 0, 0])
    with pytest.raises(ValueError, match="Nonfinite"):
        check_frame(replace(a, coefficients=a.coefficients * np.nan))
    with pytest.raises(ValueError, match="Nonfinite"):
        check_isolation(replace(a, energies=a.energies * np.nan))
    with pytest.raises(ValueError, match="permutation"):
        validate_geometry_seam(a, a, [0.0], [[0, 0, 0]])


def test_parameter_mesh_sews_endpoint_frames():
    def provider(p):
        return (
            atom_frame(
                0.2 * np.sin(2 * np.pi * p[3]) + 0.1 * np.cos(2 * np.pi * p[4]),
                phase=0.7 * p[3] + 0.3 * p[4],
            ),
            0,
        )

    def seam(a, b, delta):
        validate_geometry_seam(a[0], b[0], [0], [[0, 0, 0]])

    system = PhasonSystem(provider, seam)
    links = system.mesh(np.zeros(5), [[0, 0, 0, 1, 0], [0, 0, 0, 0, 1]], [4, 4])
    assert first_chern(links).value == pytest.approx(0.0, abs=1e-13)
    assert system.last_diagnostics["minimum_direct_gap_ha"] == 2.0
