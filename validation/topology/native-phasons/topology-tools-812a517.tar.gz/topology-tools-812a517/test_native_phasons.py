"""Independent native mesh comparisons. Set CP2K_PHASON_BINARY to enable."""

import os
from pathlib import Path
import subprocess
import numpy as np
import pytest
from native_phasons import write_links, write_mesh, run_native
from test_chern import qwz_states, dirac_states
from topology_mesh import links_from_states, first_chern, second_chern


def test_manifest_validation_before_writing(tmp_path):
    def unused_provider(index):
        raise AssertionError("Invalid metadata must fail before accessing snapshots")

    valid = dict(
        shape=[3, 3],
        origin=[0, 0, 0],
        k_directions=[[1, 0, 0], [0, 0, 0]],
        frame_provider=unused_provider,
        permutations=[[0], [0]],
    )
    for changes in (
        {"shape": [3.5, 3]},
        {"origin": [0, np.nan, 0]},
        {"k_directions": [[0.5, 0, 0], [0, 0, 0]]},
        {"permutations": [[0.5], [0]]},
        {"phase_limit": np.pi},
    ):
        path = tmp_path / "invalid.mesh"
        with pytest.raises(ValueError):
            write_mesh(path, **(valid | changes))
        assert not path.exists()
    path = tmp_path / "invalid.links"
    with pytest.raises(ValueError):
        write_links(path, np.ones((2, 3, 2, 1, 1)))
    assert not path.exists()
    path.write_text("existing data\n")
    with pytest.raises(FileExistsError):
        write_links(path, np.ones((3, 3, 2, 1, 1)))
    assert path.read_text() == "existing data\n"


@pytest.fixture
def binary():
    value = os.environ.get("CP2K_PHASON_BINARY")
    if not value:
        pytest.skip("Set CP2K_PHASON_BINARY for native snapshot/mesh tests")
    assert Path(value).is_file()
    return value


@pytest.mark.parametrize("mass,expected", [(-1, 1), (1, -1), (-3, 0)])
def test_native_first_chern(binary, tmp_path, mass, expected):
    links = links_from_states(qwz_states(16, mass))
    path = tmp_path / "model.links"
    write_links(path, links)
    result, _ = run_native(binary, "links", path)
    assert result["CHERN_RAW"] == pytest.approx(expected, abs=1e-12)
    assert result["CHERN_RAW"] == pytest.approx(first_chern(links).value, abs=1e-12)


def test_native_second_chern_refinement_gauge_orientation(binary, tmp_path):
    values = []
    for n in (6, 10):
        states = dirac_states(n)
        links = links_from_states(states)
        reference = second_chern(links).value
        path = tmp_path / f"dirac-{n}.links"
        write_links(path, links)
        result, _ = run_native(binary, "links", path)
        values.append(result["CHERN_RAW"])
        assert values[-1] == pytest.approx(reference, abs=2e-12)
    assert abs(values[1] + 1) < abs(values[0] + 1)
    assert abs(values[1] + 1) < 0.22
    rng = np.random.default_rng(729)
    gauge, _ = np.linalg.qr(
        rng.normal(size=states.shape[:-2] + (2, 2))
        + 1j * rng.normal(size=states.shape[:-2] + (2, 2))
    )
    for name, transformed, expected in (
        ("gauge", states @ gauge, values[-1]),
        ("reverse", states[::-1], -values[-1]),
    ):
        path = tmp_path / f"{name}.links"
        write_links(path, links_from_states(transformed))
        result, _ = run_native(binary, "links", path)
        assert result["CHERN_RAW"] == pytest.approx(expected, abs=2e-12)


def test_native_rejects_singular_and_underresolved_links(binary, tmp_path):
    path = tmp_path / "singular.links"
    write_links(path, np.zeros((3, 3, 2, 1, 1)))
    with pytest.raises(RuntimeError, match="Singular"):
        run_native(binary, "links", path)
    path = tmp_path / "underresolved.links"
    write_links(path, links_from_states(qwz_states(6)), phase_limit=0.01)
    with pytest.raises(RuntimeError, match="Unresolved"):
        run_native(binary, "links", path)


def test_native_refinement_acceptance_and_guards(binary, tmp_path):
    paths = []
    for n in (8, 16):
        path = tmp_path / f"qwz-{n}.links"
        write_links(path, links_from_states(qwz_states(n)))
        paths.append(path)
    env = {**os.environ, "OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1"}
    result = subprocess.run(
        [binary, "converge-links", *map(str, paths), "1e-8"],
        capture_output=True,
        text=True,
        env=env,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    assert "REFINEMENT_CHECK_PASSED" in result.stdout
    result = subprocess.run(
        [binary, "converge-links", str(paths[0]), str(paths[0]), "1e-8"],
        capture_output=True,
        text=True,
        env=env,
    )
    assert result.returncode != 0
    assert "Refine every mesh axis" in result.stdout + result.stderr
    paths = []
    for n in (4, 8):
        path = tmp_path / f"dirac-refine-{n}.links"
        write_links(path, links_from_states(dirac_states(n)))
        paths.append(path)
    result = subprocess.run(
        [binary, "converge-links", *map(str, paths), "0.01"],
        capture_output=True,
        text=True,
        env=env,
    )
    assert result.returncode != 0
    assert "REFINEMENT_CHECK_PASSED" not in result.stdout


def test_native_reader_rejects_truncated_links(binary, tmp_path):
    path = tmp_path / "truncated.links"
    write_links(path, links_from_states(qwz_states(6)))
    path.write_text("\n".join(path.read_text().splitlines()[:-1]) + "\n")
    with pytest.raises(RuntimeError):
        run_native(binary, "links", path)


@pytest.mark.parametrize("failure", [None, "seam", "metric", "gap"])
def test_native_physical_snapshot_guards(binary, tmp_path, failure):
    n = 3
    for x in range(n + 1):
        for y in range(n + 1):
            center = 0.2 * np.sin(2 * np.pi * x / n) + 0.1 * np.sin(2 * np.pi * y / n)
            if failure == "seam" and x == n:
                center += 0.1
            coefficient = np.exp(1j * (0.7 * x + 0.3 * y) / n)
            if failure == "metric" and x == 1:
                coefficient *= 2
            upper = -1 if failure == "gap" and x == 1 else 1
            path = tmp_path / f"frame-{x}-{y}.topology"
            path.write_text(
                "CP2K_TOPOLOGY_STATE 1\n1 1 1 1 1 2 1\n1\n"
                "20 0 0\n0 20 0\n0 0 20\n0 0 0\n1 1 1 1\n"
                f"{center:.17g} 0 0\n1 1 1 1 0 5\n1 5\n"
                f"0 0 0 {(2 / np.pi)**0.75:.17g}\n1 0 0 0\n-1 {upper}\n"
                f"{coefficient.real:.17g} {coefficient.imag:.17g}\n"
            )

    def provider(index):
        return tmp_path / f"frame-{index[0]}-{index[1]}.topology", 1, 0.0

    path = tmp_path / "physical.mesh"
    write_mesh(
        path,
        [n, n],
        [0, 0, 0],
        [[0, 0, 0], [0, 0, 0]],
        provider,
        [[0], [0]],
        common_energy_reference=True,
    )
    if failure:
        message = {
            "seam": "Geometry does not close",
            "metric": "AO-metric normalized",
            "gap": "subspace isolation",
        }[failure]
        with pytest.raises(RuntimeError, match=message):
            run_native(binary, "mesh", path, threads=2)
    else:
        result, _ = run_native(binary, "mesh", path, threads=2)
        assert abs(result["CHERN_RAW"]) < 1e-12
        assert result["SAMPLED_INDIRECT_GAP_HA"] == 2
