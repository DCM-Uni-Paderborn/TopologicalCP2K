"""Independent Chern/pump references and guard tests; no DFT executable needed."""

from types import SimpleNamespace
import numpy as np
import pytest
from test_topology import native, native_result  # shared Fortran fixture
from topology_mesh import (
    first_chern,
    second_chern,
    links_from_states,
    gap_diagnostics,
    adjoint,
)


def qwz(kx, ky, mass=-1):
    z = mass + np.cos(kx) + np.cos(ky)
    off = np.sin(kx) - 1j * np.sin(ky)
    return np.array([[z, off], [off.conjugate(), -z]])


def qwz_states(n, mass=-1):
    return np.array(
        [
            [
                np.linalg.eigh(qwz(x, y, mass))[1][:, :1]
                for y in np.arange(n) * 2 * np.pi / n
            ]
            for x in np.arange(n) * 2 * np.pi / n
        ]
    )


@pytest.mark.parametrize("mass,expected", [(-1, 1), (1, -1), (-3, 0)])
def test_native_chern_z2pack_plaquettes(native, mass, expected):
    states = qwz_states(32, mass)
    links = links_from_states(states)
    loops = [links[:, j, 0] for j in range(32)] + [links[:, 0, 0]]
    run, wcc, _ = native_result(native, loops)
    record = next(
        s.split()[1:] for s in run.stdout.splitlines() if s.strip().startswith("CHERN")
    )
    invariant, status = map(int, record[:2])
    assert status == 0 and invariant == expected
    assert first_chern(links).value == pytest.approx(expected)
    try:
        import z2pack
    except ImportError:
        return
    reference = z2pack.invariant.chern(
        SimpleNamespace(pol=[float(np.sum(w)) for w in wcc])
    )
    assert reference == pytest.approx(expected)


def test_native_chern_seam_and_resolution(native):
    for values, expected_status in [([0, 0.1, 0.2], -2), ([0, 0.3, 0.6, 0.9, 1], -3)]:
        loops = [[np.array([[np.exp(2j * np.pi * value)]])] for value in values]
        run, _, _ = native_result(native, loops)
        record = next(
            s.split()[1:]
            for s in run.stdout.splitlines()
            if s.strip().startswith("CHERN")
        )
        assert int(record[1]) == expected_status


def test_rice_mele_pump():
    n = 30
    states = np.empty((n, n, 2, 1), complex)
    for i, k in enumerate(2 * np.pi * np.arange(n) / n):
        for j, phi in enumerate(2 * np.pi * np.arange(n) / n):
            t1, t2, delta = 1 + 0.5 * np.cos(phi), 1 - 0.5 * np.cos(phi), np.sin(phi)
            off = t1 + t2 * np.exp(-1j * k)
            h = np.array([[delta, off], [off.conjugate(), -delta]])
            states[i, j] = np.linalg.eigh(h)[1][:, :1]
    c = first_chern(links_from_states(states))
    assert c.value == pytest.approx(-1)
    assert first_chern(links_from_states(states[:, ::-1])).value == pytest.approx(1)


def dirac_states(n, mass=-3):
    sx = np.array([[0, 1], [1, 0]], complex)
    sy = np.array([[0, -1j], [1j, 0]], complex)
    sz = np.diag([1.0, -1.0])
    # Product of these five ordered gamma matrices is -I. The lower doublet
    # has C2=-degree(d/|d|)=-1 for -4<m<-2 in topology_mesh's convention.
    # The degree is +1: only the all-zero momentum corner has positive d5.
    gamma = [
        np.kron(sx, sx),
        np.kron(sx, sy),
        np.kron(sx, sz),
        np.kron(sy, np.eye(2)),
        np.kron(sz, np.eye(2)),
    ]
    k = np.stack(
        np.meshgrid(*([2 * np.pi * np.arange(n) / n] * 4), indexing="ij"), axis=-1
    )
    h = sum(np.sin(k[..., i])[..., None, None] * gamma[i] for i in range(4))
    h += (mass + np.cos(k).sum(axis=-1))[..., None, None] * gamma[4]
    return np.linalg.eigh(h)[1][..., :2]


def test_second_chern_dirac_refinement_and_gauge():
    coarse = second_chern(links_from_states(dirac_states(6))).value
    states = dirac_states(10)
    fine = second_chern(links_from_states(states)).value
    assert abs(fine + 1) < abs(coarse + 1)
    assert abs(fine + 1) < 0.22
    rng = np.random.default_rng(6124)
    gauge, _ = np.linalg.qr(
        rng.normal(size=states.shape[:-2] + (2, 2))
        + 1j * rng.normal(size=states.shape[:-2] + (2, 2))
    )
    rotated = second_chern(links_from_states(states @ gauge)).value
    assert rotated == pytest.approx(fine, abs=2e-12)
    reversed_value = second_chern(links_from_states(states[::-1])).value
    assert reversed_value == pytest.approx(-fine, abs=2e-12)


def test_second_chern_product_pairing():
    # For the product of two line bundles, ch2 = c1(first) * c1(second).
    states2 = qwz_states(8)
    states4 = np.einsum("abir,cdjs->abcdijrs", states2, states2).reshape(
        8, 8, 8, 8, 4, 1
    )
    assert second_chern(links_from_states(states4)).value == pytest.approx(1, abs=1e-12)


def test_gap_isolation_does_not_imply_global_gap():
    assert gap_diagnostics([[-1, 1], [2, 4]], 1) == dict(
        direct_gap=2.0, indirect_gap=-1.0, valence_max=2.0, conduction_min=1.0, rank=1
    )
    with pytest.raises(ValueError):
        gap_diagnostics([[1, -1]], 1)
    with pytest.raises(ValueError):
        gap_diagnostics([[-1, 1]], 2)


def test_singular_and_inadmissible_mesh():
    with pytest.raises(ValueError, match="Singular"):
        first_chern(np.zeros((3, 3, 2, 1, 1)))
    with pytest.raises(ValueError, match="Unresolved"):
        first_chern(links_from_states(qwz_states(6)), phase_limit=0.01)
