"""Independent mixed k/phason loops of physical CP2K snapshots.

A provider returns (Snapshot, point_index) for each parameter vector (kx,ky,kz,
phi1,...), with phasons in units of their declared period. It may read existing
STATE_EXPORT files or run a converged CP2K calculation. Geometry changes require
their own self-consistent potentials; changing a loop must not change its SCF
mesh/settings. A user-supplied sewing validator declares the physical phason
periodicity; an endpoint singular-value test additionally checks state closure.
"""

import numpy as np
from gaussian_states import check_frame, check_isolation, state_overlap


class PhasonSystem:
    def __init__(
        self,
        frame_provider,
        seam_validator,
        *,
        metric_tol=1e-7,
        singular_tol=1e-8,
        gap_tol=1e-7
    ):
        if not callable(frame_provider) or not callable(seam_validator):
            raise TypeError(
                "A frame provider and explicit physical seam validator are required"
            )
        if not 0 < metric_tol < 1 or not 0 < singular_tol < 1 or not 0 < gap_tol < 1:
            raise ValueError("Invalid overlap tolerances")
        self.provider = frame_provider
        self.seam_validator = seam_validator
        self.metric_tol = metric_tol
        self.singular_tol = singular_tol
        self.gap_tol = gap_tol
        self.last_diagnostics = None

    @staticmethod
    def _shift(frame, parameter):
        snapshot, point = frame
        delta = parameter[:3] - snapshot.kpoints[point]
        if not np.allclose(delta, np.rint(delta), rtol=0, atol=1e-9):
            raise ValueError("Provider returned the wrong k-point")
        return np.rint(delta).astype(int)

    def _overlap(self, a, pa, b, pb):
        return state_overlap(
            a[0],
            b[0],
            a[1],
            b[1],
            reciprocal_shift=self._shift(b, pb) - self._shift(a, pa),
        )

    def get_mmn(self, kpt):
        parameters = np.asarray(kpt, dtype=float)
        if (
            parameters.ndim != 2
            or parameters.shape[1] < 4
            or len(parameters) < 3
            or not np.isfinite(parameters).all()
        ):
            raise ValueError(
                "Expected kx,ky,kz and at least one phason for a closed loop"
            )
        delta = parameters[-1] - parameters[0]
        if not np.allclose(delta, np.rint(delta), rtol=0, atol=1e-9):
            raise ValueError(
                "Parameter loop does not close modulo its declared periods"
            )
        if np.any(np.linalg.norm(np.diff(parameters, axis=0), axis=1) < 1e-12):
            raise ValueError("Repeated adjacent parameter points")
        frames = [self.provider(p.copy()) for p in parameters]
        metric_errors = [check_frame(s, i, self.metric_tol) for s, i in frames]
        gaps = [check_isolation(s, i, self.gap_tol) for s, i in frames]
        # Validator must check the prescribed geometry/basis sewing, not merely
        # accept integer parameter coordinates. It must raise on inconsistency.
        self.seam_validator(frames[0], frames[-1], np.rint(delta).astype(int))
        closure = self._overlap(frames[-1], parameters[-1], frames[0], parameters[-1])
        u, s, vh = np.linalg.svd(closure)
        closure_error = float(np.max(np.abs(s - 1)))
        if closure_error > self.metric_tol:
            raise ValueError(
                "Endpoint selected subspaces do not sew into a closed loop"
            )
        sewing = u @ vh
        links, minimum = [], 1.0
        for i in range(len(frames) - 1):
            m = self._overlap(
                frames[i], parameters[i], frames[i + 1], parameters[i + 1]
            )
            if i == len(frames) - 2:
                m = m @ sewing
            u, s, vh = np.linalg.svd(m)
            minimum = min(minimum, float(s.min()))
            if minimum <= self.singular_tol:
                raise ValueError(
                    "Singular phason link; refine the path and check subspace isolation"
                )
            links.append(u @ vh)
        self.last_diagnostics = dict(
            maximum_metric_error=max(metric_errors),
            minimum_direct_gap_ha=min(gaps),
            seam_subspace_error=closure_error,
            minimum_singular_value=minimum,
        )
        return links

    def mesh(self, origin, directions, shape):
        """Physical links on a 2D or 4D parameter torus, for topology_mesh.

        directions contains integer period vectors in (kx,ky,kz,phi...) space.
        The provider is evaluated also at each seam endpoint; the validator and
        the physical closure link are mandatory. Frames are cached for this call
        only. For large meshes use precomputed snapshots to avoid repeated SCF.
        """
        origin, directions = np.asarray(origin, float), np.asarray(directions, float)
        shape = tuple(shape)
        ndim = len(shape)
        if ndim not in (2, 4) or any(int(n) != n or n < 3 for n in shape):
            raise ValueError(
                "A 2D or 4D mesh with at least three samples per axis is required"
            )
        shape = tuple(map(int, shape))
        if (
            origin.ndim != 1
            or len(origin) < 4
            or directions.shape != (ndim, len(origin))
        ):
            raise ValueError("Incorrect parameter torus dimensions")
        if not np.isfinite(origin).all() or not np.isfinite(directions).all():
            raise ValueError("Nonfinite torus parameters")
        if (
            not np.allclose(directions, np.rint(directions), rtol=0, atol=1e-9)
            or np.linalg.matrix_rank(directions) != ndim
        ):
            raise ValueError(
                "Torus directions must be independent integer period vectors"
            )
        frames, metrics, gaps = {}, [], []

        def get(index):
            if index not in frames:
                parameter = (
                    origin + (np.asarray(index) / np.asarray(shape)) @ directions
                )
                frame = self.provider(parameter.copy())
                metrics.append(check_frame(*frame, self.metric_tol))
                gaps.append(check_isolation(*frame, self.gap_tol))
                frames[index] = frame, parameter
            return frames[index]

        first, _ = get((0,) * ndim)
        rank = len(first[0].bands)
        links = np.empty(shape + (ndim, rank, rank), complex)
        seam_error, minimum = 0.0, 1.0
        for index in np.ndindex(shape):
            a, pa = get(index)
            for axis in range(ndim):
                neighbour = list(index)
                neighbour[axis] += 1
                b, pb = get(tuple(neighbour))
                m = self._overlap(a, pa, b, pb)
                if neighbour[axis] == shape[axis]:
                    neighbour[axis] = 0
                    base, _ = get(tuple(neighbour))
                    self.seam_validator(base, b, directions[axis].astype(int))
                    closure = self._overlap(b, pb, base, pb)
                    u, s, vh = np.linalg.svd(closure)
                    seam_error = max(seam_error, float(np.max(np.abs(s - 1))))
                    if seam_error > self.metric_tol:
                        raise ValueError(
                            "Endpoint states do not sew across a parameter-mesh face"
                        )
                    m = m @ (u @ vh)
                u, s, vh = np.linalg.svd(m)
                minimum = min(minimum, float(s.min()))
                if minimum <= self.singular_tol:
                    raise ValueError("Singular parameter-mesh link")
                # Preserve raw amplitudes for independent analysis/diagnostics.
                links[index + (axis,)] = m
        self.last_diagnostics = dict(
            maximum_metric_error=max(metrics),
            minimum_direct_gap_ha=min(gaps),
            seam_subspace_error=seam_error,
            minimum_singular_value=minimum,
            evaluated_frames=len(frames),
            shape=shape,
        )
        return links
