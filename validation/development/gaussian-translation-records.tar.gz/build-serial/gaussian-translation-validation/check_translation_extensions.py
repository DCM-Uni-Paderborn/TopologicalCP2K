"""Additional finite-translation SOC/all-electron and invalid-input checks."""
import argparse
import json
import os
from pathlib import Path
import subprocess

import numpy as np

from check_gaussian_translation import values


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--replay", action="store_true")
    args = parser.parse_args()
    root = args.root.resolve()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=args.replay)
    env = dict(os.environ, CP2K_DATA_DIR=str(root / "data"), OPENBLAS_NUM_THREADS="1",
               OMP_NUM_THREADS="2", OMP_STACKSIZE="64M")
    tests = root / "tests/QS/regtest-quadratic-pseudospectrum"
    base = (tests / "translation-common.inc").read_text().replace("${QS_METHOD}", "GAPW")
    ae = base.replace("TZVP-MOLOPT-GGA-GTH-q1", "SVP-MOLOPT-GGA-ae")
    ae = ae.replace("POTENTIAL GTH-PBE-q1", "POTENTIAL ALL")
    soc = (tests / "neon-common.inc").read_text()
    soc = soc.replace("POSITION [angstrom] 3.0 3.0 3.0", "FORMULATION TRANSLATION\n"
                      "      TRANSLATION_VECTOR [angstrom] 0.8 0.2 -0.1\n"
                      "      WAVE_VECTOR [bohr^-1] 0.6 0.2 -0.3")
    soc = soc.replace("KAPPA [hartree*bohr^-1] 0.1", "TRANSLATION_SCALE [hartree] 0.25")
    soc = soc.replace("EPS_EIGEN 1.0E-9", "EPS_EIGEN 1.0E-10\n      MAX_ITER 2000")
    summary = {}

    def run(name, text, ranks=0, success=True):
        work = output / name
        if args.replay:
            log = (work / "output.out").read_text()
            assert ("PROGRAM ENDED AT" in log) == success, name
            return log
        work.mkdir()
        (work / "input.inp").write_text(text)
        command = [str(root / "build-serial/bin/cp2k.ssmp")]
        if ranks:
            command = ["mpiexec", "-n", str(ranks), str(root / "build-mpi/bin/cp2k.psmp")]
        with (work / "stdout.log").open("w") as stream:
            process = subprocess.run(command + ["-i", "input.inp", "-o", "output.out"],
                                     cwd=work, env=env, stdout=stream, stderr=subprocess.STDOUT)
        log = (work / "output.out").read_text()
        assert (process.returncode == 0) == success, (name, process.returncode)
        return log

    for name, text in (("all-electron", ae), ("soc", soc)):
        dense = run(name + "-dense", text.replace("${QUADRATIC_SOLVER}", "DENSE"))
        iterative = run(name + "-mpi4", text.replace("${QUADRATIC_SOLVER}", "ITERATIVE"), ranks=4)
        reversal = run(name + "-reverse", text.replace("${QUADRATIC_SOLVER}", "DENSE")
                       .replace("0.6 0.2 -0.3", "-0.6 -0.2 0.3"))
        error = np.max(abs(values(dense, "Gap [hartree]") - values(iterative, "Gap [hartree]")))
        tr_error = np.max(abs(values(dense, "Gap [hartree]") - values(reversal, "Gap [hartree]")))
        residual = np.max(values(iterative, "Eigenpair residual [hartree^2]"))
        record = dict(gap_difference=float(error), reversal_difference=float(tr_error),
                      iterative_residual=float(residual), ranks=4)
        print(name, json.dumps(record), flush=True)
        assert error < 1e-9 and tr_error < 1e-9 and residual <= 1.01e-10
        summary[name] = record

    base = base.replace("${QUADRATIC_SOLVER}", "DENSE")
    guards = {
        "missing-vector": ("\n".join(line for line in base.splitlines() if "TRANSLATION_VECTOR" not in line),
                           "requires at least one TRANSLATION_VECTOR"),
        "position": (base.replace("FORMULATION TRANSLATION", "FORMULATION TRANSLATION\n      POSITION 0 0 0"),
                     "uses WAVE_VECTOR, not POSITION"),
        "kappa": (base.replace("FORMULATION TRANSLATION", "FORMULATION TRANSLATION\n      KAPPA 0.1"),
                  "uses TRANSLATION_SCALE, not KAPPA"),
        "wrong-formulation": (base.replace("FORMULATION TRANSLATION", "FORMULATION FINITE"),
                              "TRANSLATION_VECTOR requires quadratic FORMULATION TRANSLATION"),
        "mesh": (base.replace("FORMULATION TRANSLATION", "FORMULATION TRANSLATION\n      MP_GRID 1 1 1"),
                 "MP_GRID requires FORMULATION PERIODIC"),
    }
    for name, (text, message) in guards.items():
        log = run("guard-" + name, text, success=False)
        assert message in log, name
        summary["guard-" + name] = "rejected with the expected diagnostic"
        print("guard-" + name, "OK", flush=True)
    (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")


if __name__ == "__main__":
    main()
