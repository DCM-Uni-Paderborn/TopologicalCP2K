"""Sparse, complete-band reference for the periodic AII AO localizer.

No band truncation or polar replacement of coordinate links is performed.
The polar factors of complete MO frames only express an orthonormal AO basis.
A sparse cosine/sine pairing of k and -k replaces a dense real-space Fourier
transform while retaining the physical spin time-reversal representation.
"""

import argparse
import ctypes
import hashlib
import json
from pathlib import Path
import time

import numpy as np
from scipy import sparse
from scipy.linalg import eigvalsh
from scipy.sparse.linalg import eigs

from check_bloch_localizer import aii_skew, read_links, skew_sign
from gaussian_states import read_snapshot


def maximum(a):
    return float(np.max(np.abs(a.data), initial=0.0))


def real_fourier_pairing(side):
    """Q has at most two entries per column, and the full Fourier matrix FQ is real."""
    rows, cols, values = [], [], []
    for k in range(side * side):
        x, y = k % side, k // side
        partner = (-x) % side + side * ((-y) % side)
        if k > partner:
            continue
        if k == partner:
            rows.append(k)
            cols.append(k)
            values.append(1.0)
        else:
            rows += [k, partner, k, partner]
            cols += [k, k, partner, partner]
            values += [2**-0.5, 2**-0.5, 1j * 2**-0.5, -1j * 2**-0.5]
    q = sparse.coo_matrix((values, (rows, cols)), shape=(side * side,) * 2).tocsr()
    assert maximum(q.conj().T @ q - sparse.eye(side * side)) < 1e-14
    return q


def prepare(work):
    snapshot = read_snapshot(work / "stanene.topology")
    nk, ns, nao, nb = snapshot.coefficients.shape
    if ns != 2 or nb != 2 * nao or not np.array_equal(snapshot.bands, np.arange(nb)):
        raise ValueError("Complete two-component AO spinor frames are required")
    side = int(round(np.sqrt(nk)))
    coordinates = np.array([[ix, iy, 0] for iy in range(side) for ix in range(side)])
    if side**2 != nk or np.max(abs(snapshot.kpoints - coordinates / side)) > 1e-12:
        raise ValueError("Expected a full square Gamma-centered XY mesh")
    links, targets = read_links(work, nk, nb)
    for k, (x, y, _) in enumerate(coordinates):
        assert list(targets[k]) == [(x + 1) % side + side * y, x + side * ((y + 1) % side)]
    singular = np.linalg.svd(links, compute_uv=False)
    diagnostics = {
        "coordinate_unitarity_defect": float(np.max(abs(singular**2 - 1))),
        "minimum_coordinate_singular_value": float(singular.min()),
        "coordinate_commutator_norm": float(max(np.linalg.norm(
            links[k, 0] @ links[targets[k, 0], 1] - links[k, 1] @ links[targets[k, 1], 0], 2)
            for k in range(nk))),
    }
    u, singular, vh = np.linalg.svd(snapshot.coefficients.reshape(nk, nb, nb))
    if np.min(singular) <= 1e-12 * np.max(singular):
        raise ValueError("Ill-conditioned complete MO frame")
    frames = u @ vh
    q = sparse.kron(real_fourier_pairing(side), sparse.eye(nb), format="csr")
    # Convert (k, spin, AO) into the physical (spin, k, AO) ordering.
    ordering = np.arange(nk * nb).reshape(nk, 2, nao).transpose(1, 0, 2).ravel()
    q = q[:, ordering]
    exponents = []
    for axis in range(2):
        blocks = np.array([frames[k] @ links[k, axis] @ frames[targets[k, axis]].conj().T
                           for k in range(nk)])
        operator = sparse.bsr_matrix((blocks, targets[:, axis], np.arange(nk + 1)), shape=(nk * nb,) * 2)
        exponents.append((q.conj().T @ operator @ q).tocsr())
    cosines = [(op + op.conj().T) / 2 for op in exponents]
    sines = [(op.conj().T - op) / (2j) for op in exponents]
    diagnostics["localizer_order"] = 2 * nk * nb
    return snapshot, frames, q, cosines, sines, diagnostics


def sparse_skew(localizer):
    """The same physical AII involution as the independent dense reference."""
    n = localizer.shape[0] // 4
    permutation = np.r_[np.arange(3*n, 4*n), np.arange(2*n, 3*n), np.arange(n, 2*n), np.arange(n)]
    signs = np.r_[np.ones(n), -np.ones(2*n), np.ones(n)]
    involution = sparse.coo_matrix((signs, (np.arange(4*n), permutation)), shape=(4*n, 4*n)).tocsr()
    left, right = involution @ localizer, localizer @ involution
    transformed = (localizer + left @ involution + 1j * (left - right)) / 2
    residual = maximum(transformed.real)
    if residual > 1e-9 * max(1.0, maximum(localizer)):
        raise ValueError(f"Physical time reversal not preserved: {residual}")
    skew = -transformed.imag.tocsr()
    if maximum(skew + skew.T) > 1e-10 * max(1.0, maximum(skew)):
        raise ValueError("Skew symmetry lost")
    # Do not drop small nonzero entries or average away a structure defect.
    skew.eliminate_zeros()
    return skew, residual


def tacho_sign_once(matrix, library):
    function = library.cp2k_tacho_pfaffian
    function.restype = ctypes.c_int
    function.argtypes = [ctypes.c_int, ctypes.c_int,
                          np.ctypeslib.ndpointer(np.int32, flags="C_CONTIGUOUS"),
                          np.ctypeslib.ndpointer(np.int32, flags="C_CONTIGUOUS"),
                          np.ctypeslib.ndpointer(np.float64, flags="C_CONTIGUOUS"),
                          ctypes.c_double, ctypes.POINTER(ctypes.c_int),
                          ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_longlong)]
    coo = matrix.tocoo()
    if coo.nnz > np.iinfo(np.int32).max:
        raise ValueError("Too many entries for the Tacho interface")
    rows, cols = np.array(coo.row + 1, np.int32), np.array(coo.col + 1, np.int32)
    values = np.array(coo.data, np.float64)
    sign, residual, fill = ctypes.c_int(), ctypes.c_double(), ctypes.c_longlong()
    status = function(matrix.shape[0], coo.nnz, rows, cols, values, 1e-10,
                      ctypes.byref(sign), ctypes.byref(residual), ctypes.byref(fill))
    if status != 0 or sign.value not in (-1, 1):
        print(json.dumps({"pfaffian_status": status, "sign": sign.value,
                          "residual": residual.value, "fill": fill.value}), flush=True)
        return None, residual.value, fill.value
    return sign.value, residual.value, fill.value


def tacho_sign(matrix, library):
    result = tacho_sign_once(matrix, library)
    attempts = [{"ordering": "original", "resolved": result[0] is not None,
                 "residual": result[1], "fill": result[2]}]
    if result[0] is not None:
        return (*result, attempts)
    n = matrix.shape[0]
    permutations = [(np.arange(n - 1, -1, -1), (-1)**(n * (n - 1) // 2), "reversed"),
                    (np.roll(np.arange(n), -1), (-1)**(n - 1), "cyclic")]
    for order, parity, label in permutations:
        sign, residual, fill = tacho_sign_once(matrix[order][:, order], library)
        attempts.append({"ordering": label, "resolved": sign is not None,
                         "residual": residual, "fill": fill})
        print(json.dumps({"retry_ordering": label, "resolved": sign is not None}), flush=True)
        if sign is not None:
            return parity * sign, residual, fill, attempts
    return (*result, attempts)


def analyze(work, energy, etas, scale, library, dense_check=False):
    snapshot, frames, q, cosines, sines, diagnostics = prepare(work)
    shifted = snapshot.energies - energy
    gap = float(np.min(abs(shifted)))
    if gap <= 1e-8:
        raise ValueError("Unresolved original electronic gap")
    nk, nb = shifted.shape
    diagnostics.update(sampled_energy_gap_hartree=gap,
                       occupied_spinors=int(np.count_nonzero(shifted < 0)),
                       valence_max=float(np.max(snapshot.energies[:, 7])),
                       conduction_min=float(np.min(snapshot.energies[:, 8])))
    if np.any(np.count_nonzero(shifted < 0, axis=1) != 8):
        raise ValueError("Energy does not isolate the eight occupied stanene spinors")
    h = sparse.block_diag([sparse.csr_matrix(frames[k] @ np.diag(scale * np.sign(shifted[k])) @ frames[k].conj().T)
                           for k in range(nk)], format="csr")
    h = (q.conj().T @ h @ q).tocsr()
    n = h.shape[0]
    reference = sparse.diags(np.r_[np.ones(n), -np.ones(n)], format="csr")
    ref_skew, _ = sparse_skew(reference)
    reference_sign, _, _, _ = tacho_sign(ref_skew, library)
    assert reference_sign in (-1, 1)
    results = []
    for eta in etas:
        start = time.monotonic()
        mass = h - eta * (2 * sparse.eye(n) - cosines[0] - cosines[1])
        cross = eta * (sines[0] - 1j * sines[1])
        localizer = sparse.bmat([[mass, cross], [cross.conj().T, -mass]], format="csr")
        assert maximum(localizer - localizer.conj().T) < 1e-10
        skew, residual = sparse_skew(localizer)
        # Real skew shift-invert avoids a complex sparse factorization. Eigenvalues
        # occur in conjugate imaginary pairs; residuals refer to the original matrix.
        start_vector = np.random.default_rng(1847).normal(size=2*n)
        eigenvalues, vectors = eigs(skew, k=8, sigma=0, which="LM", tol=1e-11,
                                   maxiter=4000, v0=start_vector)
        eig_residual = float(np.max(np.linalg.norm(skew @ vectors - vectors * eigenvalues, axis=0)))
        if eig_residual > 1e-8 or np.max(abs(eigenvalues.real)) > 1e-9:
            raise ValueError("Unresolved skew eigenproblem")
        nearzero = np.sort(abs(eigenvalues))
        if nearzero[0] <= 1e-8:
            raise ValueError("Unresolved localizer gap")
        pfaffian, factor_residual, fill, attempts = tacho_sign(skew, library)
        record = {"energy": energy, "eta": eta, "flatten_scale": scale,
                  "gap": float(nearzero[0]), "nu": None if pfaffian is None else (1 - pfaffian * reference_sign) // 2,
                  "nearzero": nearzero.tolist(), "aii_residual": residual,
                  "eigen_residual": eig_residual, "factor_residual": factor_residual,
                  "pfaffian_fill": fill, "nnz": skew.nnz, "factor_attempts": attempts}
        if dense_check:
            dense = localizer.toarray()
            dense_skew, _ = aii_skew(dense)
            assert abs(dense_skew - skew.toarray()).max() < 1e-12
            dense_gap = float(np.min(abs(eigvalsh(dense, subset_by_index=[n-2, n+1]))))
            record["dense_gap_error"] = abs(dense_gap - record["gap"])
            assert record["dense_gap_error"] < 1e-10
            dense_sign = skew_sign(dense_skew)
            record["dense_nu"] = (1 - dense_sign * reference_sign) // 2
            if pfaffian is not None:
                assert pfaffian == dense_sign
        record["elapsed_seconds"] = time.monotonic() - start
        results.append(record)
        print(json.dumps(record), flush=True)
    return {"diagnostics": diagnostics, "queries": results}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("work", type=Path)
    parser.add_argument("--library", type=Path, required=True)
    parser.add_argument("--energy", type=float, default=-0.1592)
    parser.add_argument("--eta", type=float, nargs="+", default=[0.75, 1.0, 1.25])
    parser.add_argument("--scale", type=float, default=1.0)
    parser.add_argument("--dense-check", action="store_true")
    parser.add_argument("--output", default="sparse-flattened-scan.json")
    args = parser.parse_args()
    if not np.isfinite([args.energy, args.scale, *args.eta]).all() or min(args.scale, *args.eta) <= 0:
        raise ValueError("Invalid query")
    output = args.work / args.output
    if output.exists():
        raise FileExistsError(output)
    library = ctypes.CDLL(str(args.library.resolve()))
    report = analyze(args.work, args.energy, args.eta, args.scale, library, args.dense_check)
    report["inputs"] = {name: hashlib.sha256((args.work / name).read_bytes()).hexdigest()
                        for name in ("stanene.topology", "stanene.mmn")}
    report["script_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    report["library_sha256"] = hashlib.sha256(args.library.read_bytes()).hexdigest()
    output.write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()
