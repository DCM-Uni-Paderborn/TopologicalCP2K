"""Independent full-band Bloch reconstruction and explicit flattening experiments."""

import argparse
import json
from pathlib import Path
import sys

import numpy as np
from scipy.linalg import eigh, eigvalsh
from scipy.linalg.lapack import dgehrd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gaussian_states import read_snapshot


def skew_sign(matrix):
    """Pfaffian sign from orthogonal Hessenberg reduction, not pivoted skew LDL."""
    assert matrix.shape[0] % 2 == 0
    scale = max(abs(matrix).max(), 1e-300)
    assert abs(matrix+matrix.T).max() < 1e-10*scale
    packed, tau, info = dgehrd(np.array(matrix/scale, order="F"), lwork=64*len(matrix))
    assert info == 0
    tri = np.triu(packed, -1)
    assert abs(tri+tri.T).max() < 1e-10
    upper = np.diag(tri, 1)[::2]
    assert min(abs(upper)) > 1e-13
    return int((-1)**np.count_nonzero(tau) * np.prod(np.sign(upper)))


def aii_skew(localizer):
    n = len(localizer)//4
    permutation = np.r_[np.arange(3*n, 4*n), np.arange(2*n, 3*n), np.arange(n, 2*n), np.arange(n)]
    signs = np.r_[np.ones(n), -np.ones(2*n), np.ones(n)]
    left = signs[:, None]*localizer[permutation, :]
    right = localizer[:, permutation]*signs[None, :]
    transformed = (localizer + left[:, permutation]*signs[None, :] + 1j*(left-right))/2
    residual = float(abs(transformed.real).max())
    assert residual < 1e-9*max(1.0, abs(localizer).max()), residual
    return -transformed.imag, residual


def pfaffian_tests():
    def recursive(a):
        if len(a) == 0:
            return 1.0
        return sum((-1)**(j+1)*a[0, j]*recursive(np.delete(np.delete(a, [0, j], 0), [0, j], 1))
                   for j in range(1, len(a)))
    rng = np.random.default_rng(6174)
    for order in (2, 4, 6, 8):
        for _ in range(8):
            a = rng.normal(size=(order, order))
            a -= a.T
            assert skew_sign(a) == np.sign(recursive(a))


def read_links(work, nk, nb):
    links = np.empty((nk, 2, nb, nb), dtype=complex)
    targets = np.empty((nk, 2), dtype=int)
    with (work/"stanene.mmn").open() as stream:
        next(stream)
        assert list(map(int, next(stream).split())) == [nb, nk, 2]
        for ik in range(nk):
            for axis in range(2):
                source, target, *shift = map(int, next(stream).split())
                assert source == ik+1 and 1 <= target <= nk
                values = np.array([list(map(float, next(stream).split())) for _ in range(nb*nb)])
                links[ik, axis] = (values[:, 0]+1j*values[:, 1]).reshape(nb, nb, order="F")
                targets[ik, axis] = target-1
        assert not stream.read().strip()
    return links, targets


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("work", type=Path)
    parser.add_argument("--energy", type=float, default=-0.1592)
    parser.add_argument("--eta", type=float, nargs="+", default=[0.03])
    parser.add_argument("--flatten", type=float, nargs="+", default=[0.0])
    parser.add_argument("--scale", type=float, default=1.0)
    parser.add_argument("--polar-coordinates", action="store_true")
    parser.add_argument("--output", default="bloch-analysis.json")
    parser.add_argument("--native", type=Path)
    args = parser.parse_args()
    pfaffian_tests()
    snapshot = read_snapshot(args.work/"stanene.topology")
    nk, ns, nao, nb = snapshot.coefficients.shape
    assert ns == 2 and nb == 2*nao and np.array_equal(snapshot.bands, np.arange(nb))
    side = int(round(np.sqrt(nk)))
    assert side**2 == nk
    coordinates = np.array([[ix, iy, 0] for iy in range(side) for ix in range(side)])
    assert np.max(abs(snapshot.kpoints-coordinates/side)) < 1e-12
    links, targets = read_links(args.work, nk, nb)
    for ik, (ix, iy, _) in enumerate(coordinates):
        assert list(targets[ik]) == [(ix+1) % side+side*iy, ix+side*((iy+1) % side)]
    singular = np.linalg.svd(links, compute_uv=False)
    diagnostics = {"coordinate_unitarity_defect": float(np.max(abs(singular**2-1))),
                   "minimum_coordinate_singular_value": float(singular.min())}
    commutators = [links[k, 0]@links[targets[k, 0], 1]-links[k, 1]@links[targets[k, 1], 0] for k in range(nk)]
    diagnostics["coordinate_commutator_norm"] = float(max(np.linalg.norm(a, 2) for a in commutators))
    if args.polar_coordinates:
        u, s, vh = np.linalg.svd(links)
        links = u@vh
    n = nk*nb
    transform = np.empty((n, n), dtype=complex)
    for ik in range(nk):
        coefficients = snapshot.coefficients[ik].reshape(nb, nb)
        u, s, vh = np.linalg.svd(coefficients)
        frame = u@vh
        for ir, r in enumerate(coordinates):
            phase = np.exp(2j*np.pi*np.dot(snapshot.kpoints[ik], r))/np.sqrt(nk)
            for spin in range(2):
                rows = slice(spin*nk*nao+ir*nao, spin*nk*nao+(ir+1)*nao)
                transform[rows, ik*nb:(ik+1)*nb] = phase*frame[spin*nao:(spin+1)*nao]
    diagnostics["fourier_frame_unitarity"] = float(abs(transform.conj().T@transform-np.eye(n)).max())
    assert diagnostics["fourier_frame_unitarity"] < 1e-11
    cosine, sine = [], []
    for axis in range(2):
        exponent = np.zeros((n, n), dtype=complex)
        for ik in range(nk):
            exponent[ik*nb:(ik+1)*nb, targets[ik, axis]*nb:(targets[ik, axis]+1)*nb] = links[ik, axis]
        exponent = transform@exponent@transform.conj().T
        cosine.append((exponent+exponent.conj().T)/2)
        sine.append((exponent.conj().T-exponent)/(2j))
    shifted = snapshot.energies.ravel()-args.energy
    diagnostics["hamiltonian_norm_hartree"] = float(max(abs(shifted)))
    diagnostics["sampled_energy_gap_hartree"] = float(min(abs(shifted)))
    diagnostics["occupied_spinors"] = int(np.count_nonzero(shifted < 0))
    assert diagnostics["occupied_spinors"] == 8*nk
    reference = np.diag(np.r_[np.ones(n), -np.ones(n)]).astype(complex)
    ref_skew, _ = aii_skew(reference)
    pf_reference = skew_sign(ref_skew)
    records = []
    for amount in args.flatten:
        assert 0 <= amount <= 1
        spectrum = (1-amount)*shifted + amount*args.scale*np.sign(shifted)
        h = (transform*spectrum[None, :])@transform.conj().T
        for eta in args.eta:
            mass = h-eta*(2*np.eye(n)-cosine[0]-cosine[1])
            cross = eta*(sine[0]-1j*sine[1])
            localizer = np.block([[mass, cross], [cross.conj().T, -mass]])
            if args.native:
                with args.native.open("rb") as stream:
                    dim = np.fromfile(stream, np.int32, count=1)[0]
                    assert dim == 2*n
                    native_l, native_b = [np.fromfile(stream, np.complex128, count=dim*dim).reshape(dim, dim, order="F") for _ in range(2)]
                w, v = eigh(native_b[:n, :n])
                rootinv = (v/w**.5)@v.conj().T
                native_orth = np.block([[rootinv@native_l[:n, :n]@rootinv, rootinv@native_l[:n, n:]@rootinv],
                                       [rootinv@native_l[n:, :n]@rootinv, rootinv@native_l[n:, n:]@rootinv]])
                native_values = eigvalsh(native_orth, subset_by_index=[n-2, n+1])
                diagnostics["native_gap"] = float(min(abs(native_values)))
                diagnostics["native_offdiagonal_difference"] = float(abs(native_orth[:n, n:]-cross).max())
                diagnostics["native_diagonal_difference"] = float(abs(native_orth[:n, :n]-mass).max())
                delta = native_orth[:n, :n]-mass
                half = n//2
                diagnostics["native_scalar_difference"] = float(abs((delta[:half, :half]+delta[half:, half:])/2).max())
            nearzero = eigvalsh(localizer, subset_by_index=[n-2, n+1], driver="evr")
            skew, residual = aii_skew(localizer)
            pf = skew_sign(skew)
            row = {"eta": eta, "flatten": amount, "flatten_scale": args.scale,
                   "polar_coordinates": args.polar_coordinates, "gap": float(min(abs(nearzero))),
                   "nu": (1-pf*pf_reference)//2, "aii_residual": residual}
            records.append(row)
            print(row, flush=True)
    report = {"diagnostics": diagnostics, "queries": records}
    (args.work/args.output).write_text(json.dumps(report, indent=2)+"\n")
    print(diagnostics, flush=True)


if __name__ == "__main__":
    main()
