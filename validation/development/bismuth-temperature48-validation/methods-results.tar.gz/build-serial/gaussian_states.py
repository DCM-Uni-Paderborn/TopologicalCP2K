"""Physical cross-k / cross-geometry overlaps from CP2K STATE_EXPORT snapshots.

The reference evaluator analytically integrates contracted Cartesian Gaussians,
using CP2K's exported spherical contraction coefficients and screening radii.
It is intended for validation and small phason calculations, not large-scale
production. No Euclidean AO-vector overlaps or independent Loewdin gauges are
substituted for the moving-basis overlap. All lengths/energies are atomic units.
"""

from dataclasses import dataclass
from itertools import product
from math import comb, factorial
from pathlib import Path

import numpy as np


@dataclass
class Shell:
    center: np.ndarray
    indices: np.ndarray
    exponents: np.ndarray
    radii: np.ndarray
    powers: np.ndarray
    contraction: np.ndarray
    radius: float


@dataclass
class Snapshot:
    cell: np.ndarray  # lattice vectors are rows
    periodic: np.ndarray
    positions: np.ndarray
    kinds: np.ndarray
    atom_sizes: np.ndarray
    shells: list
    bands: np.ndarray  # zero based
    kpoints: np.ndarray
    energies: np.ndarray
    coefficients: np.ndarray  # point, spin component, AO, selected state
    spin_channel: int


def read_snapshot(path):
    """Strict reader of the versioned text format; rejects partial CP2K output."""
    with Path(path).open() as stream:
        if stream.readline().strip() != "CP2K_TOPOLOGY_STATE 1":
            raise ValueError("Unsupported topology snapshot format")

        def record(count, integer=False):
            line = stream.readline()
            if not line:
                raise ValueError("Truncated topology snapshot")
            try:
                values = np.array(line.split(), dtype=int if integer else float)
            except ValueError as exc:
                raise ValueError("Malformed topology snapshot record") from exc
            if len(values) != count or not np.isfinite(values).all():
                raise ValueError("Invalid snapshot record length or nonfinite value")
            return values

        nat, nao, nb, nk, ns, nt, channel = record(7, True)
        if min(nat, nao, nb, nk, nt, channel) < 1 or ns not in (1, 2) or nb > nt:
            raise ValueError("Invalid snapshot dimensions")
        bands = record(nb, True) - 1
        if len(set(bands)) != nb or bands.min() < 0 or bands.max() >= nt:
            raise ValueError("Invalid selected band indices")
        cell = np.array([record(3) for _ in range(3)])
        if abs(np.linalg.det(cell)) < 1e-10:
            raise ValueError("Singular cell")
        periodic = record(3, True)
        if not np.isin(periodic, [0, 1]).all():
            raise ValueError("Invalid periodicity")
        positions, kinds, sizes, shells = [], [], [], []
        offset = 0
        for atom in range(nat):
            index, kind, nset, size = record(4, True)
            if index != atom + 1 or min(kind, nset, size) < 1:
                raise ValueError("Invalid atom record")
            center = record(3)
            positions.append(center)
            kinds.append(kind)
            sizes.append(size)
            covered = np.zeros(size, dtype=bool)
            for _ in range(nset):
                meta = record(6)
                if not np.equal(meta[:5], np.rint(meta[:5])).all():
                    raise ValueError("Noninteger shell dimensions")
                first, count, npgf, ncart, lmin = meta[:5].astype(int)
                radius = float(meta[5])
                if (
                    min(first, count, npgf, ncart) < 1
                    or radius <= 0
                    or lmin < 0
                    or first + count - 1 > size
                ):
                    raise ValueError("Invalid shell dimensions")
                selected = slice(first - 1, first - 1 + count)
                if covered[selected].any():
                    raise ValueError("Overlapping shell AO indices")
                covered[selected] = True
                exponents, radii, powers, coefficients = [], [], [], []
                for _ in range(npgf):
                    exponent, r = record(2)
                    if min(exponent, r) <= 0:
                        raise ValueError("Invalid Gaussian exponent/radius")
                    exponents.append(exponent)
                    radii.append(r)
                    rows = np.array([record(3 + count) for _ in range(ncart)])
                    if (
                        not np.equal(rows[:, :3], np.rint(rows[:, :3])).all()
                        or (rows[:, :3] < 0).any()
                    ):
                        raise ValueError("Invalid Cartesian powers")
                    powers.append(rows[:, :3].astype(int))
                    coefficients.append(rows[:, 3:])
                if any(not np.array_equal(p, powers[0]) for p in powers):
                    raise ValueError("Inconsistent primitive Cartesian ordering")
                shells.append(
                    Shell(
                        center,
                        offset + np.arange(first - 1, first - 1 + count),
                        np.array(exponents),
                        np.array(radii),
                        powers[0],
                        np.array(coefficients),
                        radius,
                    )
                )
            if not covered.all():
                raise ValueError("Incomplete shell AO coverage")
            offset += size
        if offset != nao:
            raise ValueError("Atom/AO count mismatch")
        kpoints, energies, states = [], [], []
        for point in range(nk):
            header = record(4)
            if header[0] != point + 1:
                raise ValueError("Incorrect snapshot point ordering")
            kpoints.append(header[1:])
            energies.append(record(nt))
            values = np.array([record(2) for _ in range(ns * nao * nb)])
            values = values[:, 0] + 1j * values[:, 1]
            states.append(values.reshape(nb, ns, nao).transpose(1, 2, 0))
        if stream.read().strip():
            raise ValueError("Unexpected trailing snapshot content")
    if (np.diff(energies, axis=-1) < -1e-12).any():
        raise ValueError("Unordered snapshot eigenvalues")
    return Snapshot(
        cell,
        periodic,
        np.array(positions),
        np.array(kinds),
        np.array(sizes),
        shells,
        bands,
        np.array(kpoints),
        np.array(energies),
        np.array(states),
        int(channel),
    )


def primitive_integrals(a, b, alpha, beta, powers_a, powers_b, q):
    r"""Integral of polynomial Gaussians times exp(-i q.r), without normalization."""
    p = alpha + beta
    center = (alpha * a + beta * b) / p
    z = center - 1j * q / (2 * p)
    prefactor = (np.pi / p) ** 1.5 * np.exp(
        -alpha * beta / p * np.dot(a - b, a - b)
        - np.dot(q, q) / (4 * p)
        - 1j * np.dot(q, center)
    )
    result = np.full((len(powers_a), len(powers_b)), prefactor, dtype=complex)
    for axis in range(3):
        la, lb = int(powers_a[:, axis].max()), int(powers_b[:, axis].max())
        table = np.zeros((la + 1, lb + 1), dtype=complex)
        for i in range(la + 1):
            for j in range(lb + 1):
                for h in range(i + 1):
                    for k in range(j + 1):
                        degree = h + k
                        if degree % 2:
                            continue
                        moment = factorial(degree) / (
                            factorial(degree // 2) * (4 * p) ** (degree // 2)
                        )
                        table[i, j] += (
                            comb(i, h)
                            * comb(j, k)
                            * (z[axis] - a[axis]) ** (i - h)
                            * (z[axis] - b[axis]) ** (j - k)
                            * moment
                        )
        result *= table[powers_a[:, axis, None], powers_b[None, :, axis]]
    return result


def cross_ao(left, right, k_left, k_right):
    r"""O_ab = sum_R exp(i k_right.R) <a,0|exp(-i (k_right-k_left).r)|b,R>.

    k points are unwrapped reduced coordinates. This includes reciprocal seam
    shifts and physical basis motion. Cell changes are deliberately rejected:
    a different cell needs an explicitly defined common Hilbert-space mapping.
    """
    if not np.allclose(left.cell, right.cell, atol=1e-10, rtol=0) or not np.array_equal(
        left.periodic, right.periodic
    ):
        raise ValueError("Cross-geometry links require the same cell and periodicity")
    if len(left.positions) != len(right.positions) or sorted(left.atom_sizes) != sorted(
        right.atom_sizes
    ):
        raise ValueError(
            "Atom count and AO dimensions must stay fixed along a phason family"
        )
    k_left, k_right = np.asarray(k_left, float), np.asarray(k_right, float)
    if (
        k_left.shape != (3,)
        or k_right.shape != (3,)
        or not np.isfinite([k_left, k_right]).all()
    ):
        raise ValueError("Invalid k-point")
    inverse = np.linalg.inv(left.cell)
    q = 2 * np.pi * (k_right - k_left) @ inverse.T
    result = np.zeros((sum(left.atom_sizes), sum(right.atom_sizes)), dtype=complex)
    # Fractional component bounds of a Cartesian ball, valid also in skew cells.
    reciprocal_norms = np.linalg.norm(inverse, axis=0)
    for sa in left.shells:
        for sb in right.shells:
            cutoff = sa.radius + sb.radius
            displacement = (sb.center - sa.center) @ inverse
            bounds = cutoff * reciprocal_norms
            ranges = [
                (
                    range(
                        int(np.ceil(-displacement[d] - bounds[d])),
                        int(np.floor(-displacement[d] + bounds[d])) + 1,
                    )
                    if left.periodic[d]
                    else range(1)
                )
                for d in range(3)
            ]
            block = np.zeros((len(sa.indices), len(sb.indices)), dtype=complex)
            for image in product(*ranges):
                rb = sb.center + np.asarray(image) @ left.cell
                distance = np.linalg.norm(sa.center - rb)
                if distance > cutoff:
                    continue
                phase = np.exp(2j * np.pi * np.dot(k_right, image))
                for ia, alpha in enumerate(sa.exponents):
                    for ib, beta in enumerate(sb.exponents):
                        if distance > sa.radii[ia] + sb.radii[ib]:
                            continue
                        primitive = primitive_integrals(
                            sa.center, rb, alpha, beta, sa.powers, sb.powers, q
                        )
                        block += (
                            phase
                            * sa.contraction[ia].T
                            @ primitive
                            @ sb.contraction[ib]
                        )
            result[np.ix_(sa.indices, sb.indices)] += block
    return result


def state_overlap(
    left, right, point_left=0, point_right=0, *, reciprocal_shift=(0, 0, 0)
):
    """Physical selected-state overlap, including both spinor components."""
    if (
        left.spin_channel != right.spin_channel
        or left.coefficients.shape[1::2] != right.coefficients.shape[1::2]
    ):
        raise ValueError("Spin channel/components and selected rank must remain fixed")
    if not np.array_equal(left.bands, right.bands):
        raise ValueError("Selected band indices differ")
    shift = np.asarray(reciprocal_shift)
    if (
        shift.shape != (3,)
        or not np.isfinite(shift).all()
        or not np.equal(shift, np.rint(shift)).all()
    ):
        raise ValueError("Reciprocal seam shift must be an integer vector")
    op = cross_ao(
        left, right, left.kpoints[point_left], right.kpoints[point_right] + shift
    )
    a, b = left.coefficients[point_left], right.coefficients[point_right]
    return sum(ca.conj().T @ op @ cb for ca, cb in zip(a, b))


def check_frame(snapshot, point=0, tolerance=1e-7):
    """Reject inconsistent coefficient/basis snapshots before topology analysis."""
    if not np.isfinite(snapshot.coefficients[point]).all():
        raise ValueError("Nonfinite state coefficients")
    overlap = state_overlap(snapshot, snapshot, point, point)
    error = float(np.max(np.abs(overlap - np.eye(len(snapshot.bands)))))
    if not np.isfinite(error) or error > tolerance:
        raise ValueError(
            f"Exported frame is not normalized in its AO metric: {error:.3e}"
        )
    return error


def check_isolation(snapshot, point=0, tolerance=1e-7):
    """Check every selected/excluded band boundary, in Hartree, at this sample."""
    selected = np.zeros(snapshot.energies.shape[-1], dtype=bool)
    selected[snapshot.bands] = True
    boundaries = np.flatnonzero(selected[:-1] != selected[1:])
    if not len(boundaries):
        raise ValueError("No excluded band is available to test subspace isolation")
    e = snapshot.energies[point]
    if not np.isfinite(e).all() or (np.diff(e) < -1e-12).any():
        raise ValueError("Nonfinite or unordered state eigenvalues")
    gap = float(np.min(e[boundaries + 1] - e[boundaries]))
    if gap <= tolerance:
        raise ValueError(
            "Selected subspace is not isolated at a sampled parameter point"
        )
    return gap


def validate_geometry_seam(start, end, permutation, translations, tolerance=1e-8):
    """Validate explicit atom permutation/lattice translations at a phason seam.

    end atom i equals start atom permutation[i] plus translations[i] @ cell.
    The physical overlap still uses all AO pairs; the permutation is never
    substituted for the cross-geometry integral. Cell vectors/coordinates: bohr.
    """
    permutation, translations = np.asarray(permutation), np.asarray(translations)
    nat = len(start.positions)
    if end.positions.shape != start.positions.shape:
        raise ValueError("Seam atom counts differ")
    if not np.allclose(start.cell, end.cell, atol=tolerance, rtol=0):
        raise ValueError("Seam cells differ")
    if (
        permutation.shape != (nat,)
        or not np.issubdtype(permutation.dtype, np.integer)
        or sorted(permutation.tolist()) != list(range(nat))
    ):
        raise ValueError("Seam atom map is not a permutation")
    if (
        translations.shape != (nat, 3)
        or not np.isfinite(translations).all()
        or not np.equal(translations, np.rint(translations)).all()
    ):
        raise ValueError("Seam translations must be integer lattice vectors")
    if not np.array_equal(
        start.atom_sizes[permutation], end.atom_sizes
    ) or not np.array_equal(start.kinds[permutation], end.kinds):
        raise ValueError("Seam changes atom kinds or AO dimensions")
    target = start.positions[permutation] + translations @ start.cell
    error = float(np.max(np.abs(target - end.positions)))
    if not np.isfinite(error) or error > tolerance:
        raise ValueError("Geometry does not close under the supplied sewing map")
    return error
