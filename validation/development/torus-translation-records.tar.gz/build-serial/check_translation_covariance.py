"""Full-spectrum lattice translation and torus/frame covariance checks."""
import argparse
import json
import os
from pathlib import Path
import subprocess

import numpy as np

from check_periodic_translation import ANGSTROM, ENERGY, ROOT, SCALE, make_input, reference


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("--reference", type=Path, required=True)
    parser.add_argument("--replay", action="store_true")
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=args.replay)
    hcell = np.diag([4.5, 4.5, 4.5])
    grid = np.array([3, 1, 1])
    short = np.array([0.7, -0.3, 0.4])
    wave = np.array([0.21, 0.10, -0.31])
    k = ANGSTROM*2*np.pi/3*np.linalg.inv(hcell)[0]
    theta, phi = 0.37, 0.29
    rz = np.array([[np.cos(theta), -np.sin(theta), 0], [np.sin(theta), np.cos(theta), 0], [0, 0, 1]])
    rx = np.array([[1, 0, 0], [0, np.cos(phi), -np.sin(phi)], [0, np.sin(phi), np.cos(phi)]])
    rot = rz@rx
    cases = {
        "lattice": make_input(hcell, grid, hcell[:, 0], k, "primitive", states=18),
        "zero": make_input(hcell, grid, np.zeros(3), k, "primitive", states=18),
        "commensurate": make_input(hcell, grid, short, k, "primitive"),
        "wrapped": make_input(hcell, grid, short+grid[0]*hcell[:, 0], k, "primitive"),
        "rotated": make_input(rot@hcell, grid, rot@short, rot@wave, "primitive"),
        "reduced": make_input(hcell, grid, short, wave, "primitive", symmetry=True),
        "reverse": make_input(hcell, grid, short, -wave, "primitive"),
    }
    env = dict(os.environ, CP2K_DATA_DIR=str(ROOT / "data"), OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="2", OMP_STACKSIZE="64M")
    logs = {}
    for name, text in cases.items():
        work = output / name
        if not args.replay:
            work.mkdir()
            (work / "input.inp").write_text(text)
            with (work / "stdout.log").open("w") as stream:
                subprocess.run([str(ROOT / "build-serial/bin/cp2k.ssmp"), "-i", "input.inp", "-o", "output.out"],
                               cwd=work, env=env, stdout=stream, stderr=subprocess.STDOUT, check=True)
        logs[name] = (work / "output.out").read_text()
        assert "PROGRAM ENDED AT" in logs[name]
    base = (args.reference / "primitive/output.out").read_text()
    supercell = (args.reference / "supercell/output.out").read_text()
    s = reference.matrix(supercell.split(" *** SCF run converged")[0], "OVERLAP MATRIX", 18)
    h = reference.matrix(supercell, "KOHN-SHAM MATRIX", 18)
    permutation = np.zeros((18, 18))
    for cell in range(3):
        permutation[6*((cell-1)%3):6*((cell-1)%3)+6, 6*cell:6*cell+6] = np.eye(6)
    t = s@permutation
    phase = np.exp(2j*np.pi/3)
    delta = h-ENERGY*s
    q = delta@np.linalg.solve(s, delta) + SCALE**2*(2*s-phase.conjugate()*t-phase*t.T)
    se, sc = np.linalg.eigh(s)
    invsqrt = (sc / np.sqrt(se)) @ sc.T
    exact = np.linalg.eigvalsh(invsqrt@q@invsqrt)
    lam = reference.values(logs["lattice"], "Gap [hartree]").ravel()**2
    energy = np.linalg.eigvalsh(invsqrt@h@invsqrt)
    identity = np.sort((energy-ENERGY)**2)
    means = reference.values(logs["lattice"], "Translation expectation 1 real/imag")
    means = means[:, 0] + 1j*means[:, 1]
    result = dict(full_spectrum_error=float(max(abs(lam-exact))),
                  identity_spectrum_error=float(max(abs(reference.values(logs["zero"], "Gap [hartree]").ravel()**2-identity))),
                  lattice_mean_root_error=float(max(abs(means**3-1))),
                  maximum_lattice_leakage=float(max(reference.values(logs["lattice"], "Translation residual 1 full/projected/leakage")[:, 2])),
                  wrapping_gap_difference=float(np.max(abs(reference.values(logs["wrapped"], "Gap [hartree]")-
                                                          reference.values(logs["commensurate"], "Gap [hartree]")))))
    for name in ("rotated", "reduced", "reverse"):
        result[name+"_gap_difference"] = float(np.max(abs(reference.values(logs[name], "Gap [hartree]")-
                                                          reference.values(base, "Gap [hartree]"))))
    print(json.dumps(result, indent=2), flush=True)
    assert result["full_spectrum_error"] < 1e-8 and result["identity_spectrum_error"] < 1e-8
    assert result["lattice_mean_root_error"] < 1e-9 and result["maximum_lattice_leakage"] < 2e-7
    assert result["wrapping_gap_difference"] < 1e-10
    assert all(result[name+"_gap_difference"] < 1e-8 for name in ("rotated", "reduced", "reverse"))
    (output / "summary.json").write_text(json.dumps(result, indent=2)+"\n")


if __name__ == "__main__":
    main()
