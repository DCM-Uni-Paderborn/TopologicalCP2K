"""Compare primitive meshes, explicit supercells and independent ghost AO overlaps."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import subprocess

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("gaussian_reference", ROOT / "build-serial/gaussian-translation-validation/check_gaussian_translation.py")
reference = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reference)
ANGSTROM = reference.ANGSTROM
ENERGY = -0.1
SCALE = 0.3


def make_input(h, grid, shift, wave, variant, solver="DENSE", method="GPW", symmetry=False, states=3):
    supercell = variant != "primitive"
    ghost = variant == "ghost"
    offsets = [h @ np.array([i, j, k]) for k in range(grid[2]) for j in range(grid[1]) for i in range(grid[0])]
    center = h @ np.array([0.5, 0.5, 0.5])
    positions = [center + offset for offset in offsets] if supercell else [center]
    cell = h @ np.diag(grid) if supercell else h
    coords = ["He " + " ".join(map(str, p)) for p in positions]
    if ghost:
        coords += ["He_G " + " ".join(map(str, p-shift)) for p in positions]
    vectors = "\n".join(f"      {axis} " + " ".join(map(str, cell[:, i])) for i, axis in enumerate("ABC"))
    mesh = np.ones(3, dtype=int) if supercell else grid
    kpoints = "" if supercell else f"""&KPOINTS
      SCHEME MONKHORST-PACK {' '.join(map(str, grid))}
      GAMMA_CENTERED T
      WAVEFUNCTIONS COMPLEX
      SYMMETRY {'T' if symmetry else 'F'}
    &END KPOINTS"""
    properties = "" if ghost else f"""&PROPERTIES
    &QUADRATIC_PSEUDOSPECTRUM ON
      FORMULATION TRANSLATION
      MP_GRID {' '.join(map(str, mesh))}
      TRANSLATION_VECTOR [angstrom] {' '.join(map(str, shift))}
      WAVE_VECTOR [bohr^-1] {' '.join(map(str, wave))}
      ENERGY {ENERGY}
      TRANSLATION_SCALE {SCALE}
      SOLVER {solver}
      NSTATES {states}
      MAX_SUBSPACE 14
      MAX_ITER 2000
      EPS_EIGEN 1e-10
      &STATES ON
      &END
    &END
  &END"""
    ghost_kind = "" if not ghost else """&KIND He_G
      ELEMENT He
      GHOST T
      BASIS_SET TZVP-MOLOPT-GGA-GTH-q2
    &END"""
    return f"""&GLOBAL
  PROJECT translated-torus
  PRINT_LEVEL LOW
  RUN_TYPE ENERGY
&END
&FORCE_EVAL
  METHOD QUICKSTEP
  &DFT
    BASIS_SET_FILE_NAME BASIS_MOLOPT_UZH
    POTENTIAL_FILE_NAME POTENTIAL_UZH
    &QS
      METHOD {method}
      EPS_DEFAULT 1e-12
    &END
    &MGRID
      CUTOFF 300
      NGRIDS 1
      REL_CUTOFF 40
    &END
    &POISSON
      PERIODIC XYZ
      POISSON_SOLVER PERIODIC
    &END
    {kpoints}
    &SCF
      EPS_SCF 1e-11
      MAX_SCF 100
      &DIAGONALIZATION
      &END
      &MIXING
        METHOD BROYDEN_MIXING
        ALPHA 0.4
      &END
    &END
    &XC
      &XC_FUNCTIONAL PADE
      &END
    &END
    &PRINT
      &AO_MATRICES ON
        NDIGITS 16
        OVERLAP T
        KOHN_SHAM_MATRIX T
      &END
    &END
  &END
  {properties}
  &SUBSYS
    &CELL
{vectors}
      PERIODIC XYZ
    &END
    &COORD
      {chr(10).join(coords)}
    &END
    &KIND He
      BASIS_SET TZVP-MOLOPT-GGA-GTH-q2
      POTENTIAL GTH-PBE-q2
    &END
    {ghost_kind}
  &END
&END
"""


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("--ranks", type=int, default=0)
    parser.add_argument("--solver", default="DENSE")
    parser.add_argument("--method", default="GPW")
    parser.add_argument("--skew", action="store_true")
    parser.add_argument("--replay", action="store_true")
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=args.replay)
    h = np.diag([4.5, 4.5, 4.5])
    if args.skew:
        h = np.array([[4.5, 0.7, 0.3], [0., 4.8, 0.4], [0., 0., 5.1]])
    grid = np.array([3, 1, 1])
    shift = np.array([0.7, -0.3, 0.4])
    wave = np.array([0.21, 0.10, -0.31])
    env = dict(os.environ, CP2K_DATA_DIR=str(ROOT / "data"), OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="2", OMP_STACKSIZE="64M")
    command = [str(ROOT / "build-serial/bin/cp2k.ssmp")]
    if args.ranks:
        command = ["mpiexec", "-n", str(args.ranks), str(ROOT / "build-mpi/bin/cp2k.psmp")]
    logs, dirs = {}, {}
    for variant in ("primitive", "supercell", "ghost"):
        work = output / variant
        if not args.replay:
            work.mkdir()
            (work / "input.inp").write_text(make_input(h, grid, shift, wave, variant, args.solver, args.method))
            with (work / "stdout.log").open("w") as stream:
                subprocess.run(command + ["-i", "input.inp", "-o", "output.out"], cwd=work, env=env,
                               stdout=stream, stderr=subprocess.STDOUT, check=True)
        dirs[variant] = work
        logs[variant] = (work / "output.out").read_text()
        assert "PROGRAM ENDED AT" in logs[variant]
    n = int(reference.values(logs["supercell"], "AO/spinor dimension")[0, 0])
    # Gamma-to-image initialization prints additional individual image overlaps.
    s = reference.matrix(logs["supercell"].split(" *** SCF run converged")[0], "OVERLAP MATRIX", n)
    h = reference.matrix(logs["supercell"], "KOHN-SHAM MATRIX", n)
    ghost = reference.matrix(logs["ghost"], "OVERLAP MATRIX", 2*n)
    assert np.max(abs(s-ghost[:n, :n])) < 1e-11
    t = ghost[:n, n:]
    phase = np.exp(1j*np.dot(wave, shift/ANGSTROM))
    delta = h - ENERGY*s
    q = delta@np.linalg.solve(s, delta) + SCALE**2*(2*s-phase.conjugate()*t-phase*t.T)
    se, sc = np.linalg.eigh(s)
    invsqrt = (sc / np.sqrt(se)) @ sc.T
    eigenvalues = np.linalg.eigvalsh(invsqrt@q@invsqrt)
    c = reference.coefficients(next(dirs["supercell"].glob("*.states")))
    lam = reference.values(logs["supercell"], "Gap [hartree]").ravel()**2
    cc = q@c - s@(c*lam)
    ritz = np.sqrt(np.maximum(0, np.sum(cc.conj()*np.linalg.solve(s, cc), axis=0).real))
    means = np.sum(c.conj()*(t@c), axis=0)
    printed = reference.values(logs["supercell"], "Translation expectation 1 real/imag")
    summary = dict(nao=n, spectrum_error=float(max(abs(lam-eigenvalues[:len(lam)]))),
                   true_residual=float(max(ritz)), mean_error=float(max(abs(means-printed[:, 0]-1j*printed[:, 1]))),
                   primitive_supercell_gap=float(np.max(abs(reference.values(logs["primitive"], "Gap [hartree]") -
                                                          reference.values(logs["supercell"], "Gap [hartree]")))))
    print(json.dumps(summary, indent=2), flush=True)
    assert summary["spectrum_error"] < 1e-9 and summary["true_residual"] < 1e-8
    assert summary["mean_error"] < 1e-10 and summary["primitive_supercell_gap"] < 1e-7
    (output / "summary.json").write_text(json.dumps(summary, indent=2)+"\n")


if __name__ == "__main__":
    main()
