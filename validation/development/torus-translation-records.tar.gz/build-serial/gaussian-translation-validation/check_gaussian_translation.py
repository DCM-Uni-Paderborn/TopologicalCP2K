"""Check translated AO analysis against separate ghost-basis overlap calculations."""
import argparse
import json
import os
from pathlib import Path
import subprocess

import numpy as np

ANGSTROM = 0.52917720859
SHIFT = np.array([0.63, -0.37, 0.21])
K = np.array([0.31, -0.22, 0.18])
ENERGY = -0.1
SCALE = 0.3


def matrix(text, label, n):
    block = text.split(" " + label)[-1]
    result = np.full((n, n), np.nan)
    columns = []
    for line in block.splitlines():
        fields = line.split()
        if fields and all(field.isdigit() for field in fields):
            columns = [int(field) - 1 for field in fields]
        elif columns and len(fields) == 4 + len(columns) and fields[0].isdigit():
            row = int(fields[0]) - 1
            result[row, columns] = list(map(float, fields[4:]))
            if row == n - 1 and columns[-1] == n - 1:
                break
    assert np.isfinite(result).all(), label
    assert np.max(abs(result-result.T)) < 1e-10, label
    return result


def values(text, label):
    prefix = "QUADRATIC_PSEUDOSPECTRUM| " + label + ":"
    return np.array([[float(v) for v in line.split(prefix)[1].split()]
                     for line in text.splitlines() if prefix in line])


def coefficients(path):
    columns = []
    for block in path.read_text().split("# State ")[1:]:
        rows = [line.split() for line in block.splitlines()[1:] if line and not line.startswith("#")]
        columns.append([complex(float(row[1]), float(row[2])) for row in rows])
    return np.array(columns).T


def input_text(element, basis, positions, method, solver, ghost=False, analytic=False, reverse=False, identity=False):
    q = {"H": 1, "He": 2, "Ne": 8}[element]
    coords = "\n".join(f"{element} " + " ".join(map(str, p)) for p in positions)
    kinds = f"""&KIND {element}
      BASIS_SET {basis}
      POTENTIAL GTH-PBE-q{q}
    &END KIND"""
    if ghost:
        coords += "\n" + "\n".join(f"{element}_G " + " ".join(map(str, p-SHIFT)) for p in positions)
        kinds += f"""
    &KIND {element}_G
      ELEMENT {element}
      GHOST T
      BASIS_SET {basis}
    &END KIND"""
    shift = np.zeros(3) if identity else SHIFT
    k = -K if reverse else K
    props = "" if ghost else f"""&PROPERTIES
    &QUADRATIC_PSEUDOSPECTRUM ON
      FORMULATION TRANSLATION
      SOLVER {solver}
      TRANSLATION_VECTOR [angstrom] {' '.join(map(str, shift))}
      WAVE_VECTOR [bohr^-1] {' '.join(map(str, k))}
      ENERGY {ENERGY}
      TRANSLATION_SCALE {SCALE}
      NSTATES {1 if analytic else 3}
      MAX_SUBSPACE 14
      MAX_ITER 2000
      EPS_EIGEN 1e-10
    &END
  &END"""
    return f"""&GLOBAL
  PROJECT translated
  PRINT_LEVEL LOW
  RUN_TYPE ENERGY
&END
&FORCE_EVAL
  METHOD QUICKSTEP
  &DFT
    BASIS_SET_FILE_NAME {'analytic-basis' if analytic else 'BASIS_MOLOPT_UZH'}
    POTENTIAL_FILE_NAME POTENTIAL_UZH
    &QS
      METHOD {method}
      EPS_DEFAULT 1e-12
    &END
    &MGRID
      CUTOFF 150
      REL_CUTOFF 30
    &END
    &POISSON
      PERIODIC NONE
      POISSON_SOLVER MT
    &END
    &SCF
      EPS_SCF 1e-10
      MAX_SCF 100
      &OT
        MINIMIZER DIIS
        PRECONDITIONER FULL_ALL
      &END
    &END
    &XC
      &XC_FUNCTIONAL PBE
      &END
    &END
    &PRINT
      &AO_MATRICES
        NDIGITS 16
        OVERLAP T
        KOHN_SHAM_MATRIX T
      &END
    &END
  &END
  {props}
  &SUBSYS
    &CELL
      ABC 7 7 7
      PERIODIC NONE
    &END
    &COORD
      {coords}
    &END
    {kinds}
  &END
&END
"""


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--ranks", type=int, default=0)
    parser.add_argument("--solver", default="DENSE", choices=("DENSE", "ITERATIVE"))
    parser.add_argument("--replay", action="store_true")
    args = parser.parse_args()
    root = args.root.resolve()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    command = [str(args.binary.resolve())]
    if args.ranks:
        command = ["mpiexec", "-n", str(args.ranks)] + command
    env = dict(os.environ, CP2K_DATA_DIR=str(root / "data"), OPENBLAS_NUM_THREADS="1",
               OMP_NUM_THREADS="2", OMP_STACKSIZE="64M")
    cases = [("primitive", "He", "ANALYTIC-S", [[3, 3, 3]], "GPW", True),
             ("helium", "He", "TZVP-MOLOPT-GGA-GTH-q2", [[3, 3, 3]], "GPW", False),
             ("hydrogen", "H", "TZVP-MOLOPT-GGA-GTH-q1", [[3, 3, 3], [3.74, 3, 3]], "GPW", False),
             ("neon-gapw", "Ne", "TZVP-MOLOPT-GGA-GTH-q8", [[3, 3, 3]], "GAPW", False)]
    results = {}
    for name, element, basis, coords, method, analytic in cases:
        logs = {}
        dirs = {}
        for variant in ("base", "ghost", "reverse", "identity"):
            work = output / f"{name}-{variant}"
            if not args.replay:
                work.mkdir(exist_ok=False)
                (work / "analytic-basis").write_text("He ANALYTIC-S\n1\n1 0 0 1 1\n0.7 1.0\n")
                text = input_text(element, basis, np.array(coords), method, args.solver,
                                  ghost=variant == "ghost", analytic=analytic,
                                  reverse=variant == "reverse", identity=variant == "identity")
                (work / "input.inp").write_text(text)
                with (work / "stdout.log").open("w") as stream:
                    subprocess.run(command + ["-i", "input.inp", "-o", "output.out"], cwd=work,
                                   env=env, stdout=stream, stderr=subprocess.STDOUT, check=True)
            logs[variant] = (work / "output.out").read_text()
            assert "PROGRAM ENDED AT" in logs[variant]
            dirs[variant] = work
        n = int(values(logs["base"], "AO/spinor dimension")[0, 0])
        s = matrix(logs["base"], "OVERLAP MATRIX", n)
        h = matrix(logs["base"], "KOHN-SHAM MATRIX", n)
        combined = matrix(logs["ghost"], "OVERLAP MATRIX", 2*n)
        assert np.max(abs(combined[:n, :n]-s)) < 1e-12
        assert np.max(abs(combined[n:, n:]-s)) < 1e-12
        t = combined[:n, n:]
        if analytic:
            assert abs(t[0, 0]-np.exp(-0.7*np.sum((SHIFT/ANGSTROM)**2)/2)) < 1e-13
        phase = np.exp(1j*np.dot(K, SHIFT/ANGSTROM))
        shifted = h - ENERGY*s
        q = shifted@np.linalg.solve(s, shifted) + SCALE**2*(2*s-phase.conjugate()*t-phase*t.T)
        se, sc = np.linalg.eigh(s)
        invsqrt = (sc / np.sqrt(se)) @ sc.T
        ev = np.linalg.eigvalsh(invsqrt @ q @ invsqrt)
        c = coefficients(next(dirs["base"].glob("*.states")))
        count = c.shape[1]
        lam = values(logs["base"], "Gap [hartree]").ravel()**2
        norm_error = np.max(abs(c.conj().T @ s @ c - np.eye(count)))
        spectrum_error = np.max(abs(lam-ev[:count]))
        cq = q @ c - s @ (c*lam)
        ritz = np.sqrt(np.maximum(0, np.sum(cq.conj()*np.linalg.solve(s, cq), axis=0).real))
        means = np.sum(c.conj()*(t@c), axis=0)
        recorded = values(logs["base"], "Translation expectation 1 real/imag")
        mean_error = np.max(abs(means - recorded[:, 0] - 1j*recorded[:, 1]))
        projected = (t-phase*s)@c
        proj2 = np.sum(projected.conj()*np.linalg.solve(s, projected), axis=0).real
        full2 = 2 - 2*np.real(phase.conjugate()*means)
        measured = values(logs["base"], "Translation residual 1 full/projected/leakage")
        residual_error = np.max(abs(measured**2 - np.array([full2, proj2, full2-proj2]).T))
        reversal = np.max(abs(values(logs["base"], "Gap [hartree]")-values(logs["reverse"], "Gap [hartree]")))
        identity_residual = np.max(values(logs["identity"], "Translation residual 1 full/projected/leakage")[:, :2])
        record = dict(nao=n, spectrum_error=float(spectrum_error), norm_error=float(norm_error),
                      eigenpair_residual=float(max(ritz)), mean_error=float(mean_error),
                      residual_decomposition_error=float(residual_error), time_reversal_gap=float(reversal),
                      identity_residual=float(identity_residual), maximum_leakage=float(max(measured[:, 2])))
        print(name, json.dumps(record), flush=True)
        assert spectrum_error < 1e-9 and norm_error < 1e-9
        assert max(ritz) < 2e-8 and mean_error < 1e-10 and residual_error < 1e-10
        assert reversal < 1e-9 and identity_residual < 1e-6
        results[name] = record
    (output / "summary.json").write_text(json.dumps(results, indent=2)+"\n")


if __name__ == "__main__":
    main()
