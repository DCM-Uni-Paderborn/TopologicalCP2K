"""Metric, origin and independent spectral controls for the 3D torus reference."""

import argparse
import hashlib
import json
from pathlib import Path
import time

import numpy as np
from scipy.linalg import eigvalsh

import periodic_3d_reference as reference


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("--side", type=int, default=4)
    parser.add_argument("--mass", type=float, default=-2.)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    started = time.monotonic()
    h, s, co, si, electronic_gap, bulk = reference.dirac_model(args.side, args.mass)
    result, normalized = reference.evaluate(h, s, co, si)
    n = len(normalized)
    # An independent Hermitian spectral pencil must reproduce the singular gap.
    pencil = np.block([[np.zeros_like(normalized), normalized],
                       [normalized.conj().T, np.zeros_like(normalized)]])
    middle = eigvalsh(pencil, subset_by_index=[n-2, n+1], driver="evr")
    pencil_error = abs(float(min(abs(middle)))-result["gap"])
    assert pencil_error < 1e-10
    del pencil, normalized
    translated, _ = reference.evaluate(h, s, co, si, origin=[2*np.pi, -4*np.pi, 6*np.pi])
    shift_error = abs(translated["gap"]-result["gap"])
    assert translated["z2"] == result["z2"] and shift_error < 1e-10
    # A nonorthogonal spin-mixing onsite quaternion transformation preserves J K.
    spin_z = reference.PAULI[2]
    orbital = np.array([[1.1, .12], [.12, .9]])
    mixing = np.array([[.0, .08], [-.08, .0]])
    onsite = np.kron(np.eye(2), orbital)+1j*np.kron(spin_z, mixing)
    t = np.kron(onsite, np.eye(args.side**3))
    ht, st = t.conj().T @ h @ t, t.conj().T @ s @ t
    ct, tt = [np.array([t.conj().T @ a @ t for a in ops]) for ops in [co, si]]
    transformed, _ = reference.evaluate(ht, st, ct, tt)
    metric_error = abs(transformed["gap"]-result["gap"])
    assert transformed["z2"] == result["z2"] and metric_error < 1e-10
    shifted, _ = reference.evaluate(h+.23*s, s, co, si, energy=.23)
    energy_error = abs(shifted["gap"]-result["gap"])
    assert shifted["z2"] == result["z2"] and energy_error < 1e-10
    report = {"side": args.side, "mass": args.mass, "electronic_gap": electronic_gap,
              "bulk_strong_index": bulk, "localizer": result,
              "matches_bulk_strong_index": result["z2"] == bulk,
              "pencil_singular_gap_error": pencil_error, "origin_periodicity_gap_error": shift_error,
              "nonorthogonal_basis_gap_error": metric_error, "energy_zero_gap_error": energy_error,
              "elapsed_seconds": time.monotonic()-started,
              "methods": {name: hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest()
                          for name in ["check_periodic_3d.py", "periodic_3d_reference.py"]}}
    with args.output.open("x") as stream:
        stream.write(json.dumps(report, indent=2, allow_nan=False)+"\n")
    print(json.dumps(report), flush=True)


if __name__ == "__main__":
    main()
