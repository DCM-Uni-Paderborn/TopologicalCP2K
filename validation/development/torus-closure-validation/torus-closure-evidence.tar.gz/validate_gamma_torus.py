"""Check Gamma-supercell and explicit one-point 3D torus assembly agree."""

import json
import os
from pathlib import Path
import re
import subprocess

root = Path("/Users/tkuehne/cp2k-spectral-localizer")
work = Path(__file__).resolve().parent/"gamma-torus-verified"
work.mkdir(exist_ok=False)
source = (work.parent/"native-torus-serial/gpw/input.inp").read_text()
source = re.sub(r"    &PRINT\n.*?    &END PRINT\n", "", source, flags=re.S)
source = source.replace("MP_GRID 2 2 2", "MP_GRID 1 1 1").replace("      GAMMA_CENTERED T\n", "")
env = os.environ | {"OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1", "OMP_STACKSIZE": "128M",
    "CP2K_DATA_DIR": str(root/"data"), "DYLD_LIBRARY_PATH": str(root/"build-serial/openblas-thread-safe/lib")}
results = []
for name in ["implicit", "explicit"]:
    directory = work/name
    directory.mkdir()
    text = source
    if name == "implicit":
        text = re.sub(r"    &KPOINTS\n.*?    &END KPOINTS\n", "", text, flags=re.S)
    else:
        text = text.replace("SCHEME MONKHORST-PACK 2 2 2", "SCHEME GAMMA")
    (directory/"input.inp").write_text(text)
    with (directory/"stdout.log").open("x") as stream:
        result = subprocess.run([str(root/"build-serial/bin/cp2k.ssmp"), "-i", "input.inp", "-o", "output.out"],
            cwd=directory, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=120)
    output = (directory/"output.out").read_text()
    assert result.returncode == 0 and "PROGRAM ENDED AT" in output
    gap = float(re.search(r"SPECTRAL_LOCALIZER\| Gap \[hartree\]:\s+([-+\d.E]+)", output)[1])
    index = int(re.search(r"SPECTRAL_LOCALIZER\| Z2 index:\s+(\d+)", output)[1])
    results.append({"case": name, "gap": gap, "z2": index})
assert results[0]["z2"] == results[1]["z2"]
assert abs(results[0]["gap"]-results[1]["gap"]) < 2e-10
(work/"summary.json").write_text(json.dumps({"completed": True, "cases": results}, indent=2)+"\n")
print(json.dumps(results))
