"""Focused finite/periodic topology regressions on SSMP and MPI/OpenMP."""

import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time


root = Path("/Users/tkuehne/cp2k-spectral-localizer")
work = Path(sys.argv[1]).resolve()
work.mkdir(exist_ok=False)
paths = subprocess.check_output(["git", "ls-files", "-z", "--cached", "--others", "--exclude-standard"], cwd=root)
paths = sorted(set(p for p in paths.decode().split("\0") if p and (root/p).is_file()))


def hashes():
    return {p: hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}


before = hashes()
records = []
for mode, ranks, threads in [("serial", 0, 1), ("serial", 0, 2), ("mpi", 1, 2), ("mpi", 2, 1)]:
    suffix = "ssmp" if mode == "serial" else "psmp"
    env = os.environ | {"OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": str(threads),
        "OMP_STACKSIZE": "128M", "VECLIB_MAXIMUM_THREADS": "1", "CP2K_DATA_DIR": str(root/"data"),
        "DYLD_LIBRARY_PATH": str(root/"build-serial/openblas-thread-safe/lib")}
    prefix = ["mpiexec", "--bind-to", "none", "-np", str(ranks)] if ranks else []
    units = ["spectral_localizer_unittest", "spectral_localizer_3d_unittest",
             "spectral_localizer_flatten_unittest", "quadratic_pseudospectrum_unittest", "quadratic_dbcsr_unittest"]
    commands = [(unit, prefix+[str(root/f"build-{mode}/bin/{unit}.{suffix}")]) for unit in units]
    if ranks:
        commands.append(("spectral_localizer_sparse_unittest",
            prefix+[str(root/f"build-{mode}/bin/spectral_localizer_sparse_unittest.psmp"), "5"]))
    commands.append(("regtests", [sys.executable, "-B", str(root/"tests/do_regtest.py"),
        "--mpiranks", str(max(1, ranks)), "--ompthreads", str(threads), "--maxtasks", "1",
        "--timeout", "180", "--skip_unittests", "--mpiexec", "mpiexec --bind-to none -np {N}",
        "--restrictdir", r"QS/regtest-(spectral-localizer(|-3d|-mumps|-tacho)|quadratic-pseudospectrum(|-mumps))",
        "--workbasedir", str(work/f"regtests-{mode}-{ranks}r{threads}t"),
        "--cp2kdatadir", str(root/"data"), str(root/f"build-{mode}/bin"), suffix]))
    for name, command in commands:
        name += f"-{mode}-{ranks}r{threads}t"
        log = work/(name+".log")
        started = time.monotonic()
        with log.open("x") as stream:
            result = subprocess.run(command, cwd=work, env=env, stdout=stream,
                                    stderr=subprocess.STDOUT, timeout=1800)
        text = log.read_text()
        row = {"name": name, "command": command, "returncode": result.returncode,
               "seconds": time.monotonic()-started, "log_sha256": hashlib.sha256(log.read_bytes()).hexdigest()}
        if name.startswith("regtests"):
            row["summary"] = re.findall(r"^Summary:.*$", text, re.M)
            assert "Status: OK" in text, name
        records.append(row)
        (work/"summary.json").write_text(json.dumps({"completed": False, "runs": records}, indent=2)+"\n")
        print(json.dumps(row), flush=True)
        assert result.returncode == 0, name
assert hashes() == before, "Sources changed during validation"
(work/"summary.json").write_text(json.dumps({"completed": True, "runs": records,
    "source_sha256": before}, indent=2)+"\n")
