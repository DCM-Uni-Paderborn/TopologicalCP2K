"""Package completed torus and roundoff checks without caches or binaries."""

import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile


ROOT = Path(__file__).resolve().parent
SOURCE = Path("/Users/tkuehne/cp2k-spectral-localizer")
BASE = "c4fa12b8bd2001b390a92fdfcd12e56a25ba999f"
FINAL = "bddfabb8bd"


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main():
    files = {}

    def retain(path):
        assert path.is_file() and not path.is_symlink(), path
        files[str(path.relative_to(ROOT))] = path

    for name in [
        "archive_torus_closure.py", "replay_torus_closure.py", "gaussian_states.py",
        "periodic_3d_reference.py", "check_periodic_3d.py", "validate_native_torus.py",
        "validate_gamma_torus.py", "validate_torus_guards.py", "validate_periodic_regressions.py",
        "validate_roundoff.py", "tzvp_roundoff_test.F", "periodic-3d-model-results.json",
        "periodic-3d-controls.json", "periodic-3d-eight-controls.json",
    ]:
        retain(ROOT / name)
    for mode in ["serial", "mpi"]:
        directory = ROOT / ("native-torus-" + mode)
        summary = json.loads((directory / "summary.json").read_text())
        assert summary["completed"]
        for name, expected in summary["methods"].items():
            assert digest(ROOT / name) == expected, name
        retain(directory / "summary.json")
        for case in summary["cases"]:
            for name in ["input.inp", "output.out", "stdout.log", "torus.nnkp",
                         "torus.topology", "torus.eig", "torus.mmn"]:
                path = directory / case["case"] / name
                assert digest(path) == case["files"][name], path
                retain(path)
    for dirname in ["gamma-torus-verified", "periodic-3d-guards-final",
                    "periodic-3d-regressions", "roundoff-validation"]:
        directory = ROOT / dirname
        retain(directory / "summary.json")
        for path in directory.glob("*.log"):
            retain(path)
        if dirname in {"gamma-torus-verified", "periodic-3d-guards-final"}:
            for name in ["input.inp", "output.out", "stdout.log"]:
                for path in directory.glob("*/" + name):
                    retain(path)
    for name in ["periodic-3d-controls.json", "periodic-3d-eight-controls.json"]:
        for method, expected in json.loads((ROOT / name).read_text())["methods"].items():
            assert digest(ROOT / method) == expected
    for name in ["periodic-3d-regressions", "roundoff-validation"]:
        assert json.loads((ROOT / name / "summary.json").read_text())["completed"]

    def git(*args):
        return subprocess.check_output(["git", *args], cwd=SOURCE)

    assert not git("status", "--porcelain")
    final = git("rev-parse", FINAL).decode().strip()
    assert git("rev-parse", "HEAD").decode().strip() == final
    extra = {"source-update.patch": git("diff", "--binary", BASE, final)}
    changed = git("diff", "--name-only", BASE, final).decode().splitlines()
    for name in changed:
        extra["source/" + name] = git("show", final + ":" + name)
    summary = {
        "source_base": BASE, "source_final": final,
        "scope": "Native finite-AO torus checks and bounded AII roundoff correction",
        "native_reference_cases": 8,
        "exclusions": ["Build products, caches, restart backups and unneeded Wannier outputs omitted.",
                       "Model checks do not prove Gaussian-basis or material/bulk convergence.",
                       "Native torus exports predate the roundoff-only correction; closing regressions include it."],
    }
    hashes = {name: digest(path) for name, path in files.items()}
    hashes.update({name: hashlib.sha256(data).hexdigest() for name, data in extra.items()})
    manifest = json.dumps({"files": hashes, "summary": summary}, indent=2).encode() + b"\n"
    target = ROOT / "torus-closure-evidence.tar.gz"
    with tarfile.open(target, "x:gz") as archive:
        for name, path in sorted(files.items()):
            archive.add(path, arcname=name, recursive=False)
        for name, data in sorted(extra.items() | {"manifest.json": manifest}.items()):
            member = tarfile.TarInfo(name)
            member.size = len(data)
            archive.addfile(member, io.BytesIO(data))
    assert all(digest(path) == hashes[name] for name, path in files.items())
    index = {"archive_sha256": digest(target), "archive_bytes": target.stat().st_size,
             "files": hashes, "summary": summary}
    (ROOT / "torus-closure-evidence.index.json").write_text(json.dumps(index, indent=2) + "\n")
    print(json.dumps({"bytes": index["archive_bytes"], "files": len(hashes)}))


if __name__ == "__main__":
    main()
