"""Independent 3D AII torus reference, Doll et al. (2025), Proposition 20.

DOI: 10.1007/s11040-025-09508-0. This is a model validation, not a Gaussian
projection theorem or a production CP2K implementation. The chiral block
uses the adjoint of the paper's convention, preserving its real determinant.
"""

import argparse
import hashlib
from itertools import product
import json
from pathlib import Path
import time

import numpy as np
from scipy.linalg import eigh, eigvalsh, svdvals


PAULI = np.array([[[0, 1], [1, 0]], [[0, -1j], [1j, 0]], [[1, 0], [0, -1]]])


def dirac_model(side, mass, flatten=True):
    """Periodic H(k)=(m+sum cos(k)) tau_z + sum sin(k_j) sigma_j tau_x."""
    sites = side**3
    coords = np.array(list(product(range(side), repeat=3)))
    identity = np.eye(sites)
    diagonal = mass*identity
    hops = []
    for direction in range(3):
        shift = np.zeros((sites, sites))
        for row, position in enumerate(coords):
            neighbor = position.copy()
            neighbor[direction] = (neighbor[direction]+1) % side
            column = int(neighbor @ np.array([side**2, side, 1]))
            shift[row, column] += 1.
        diagonal += .5*(shift+shift.T)
        hops.append((shift-shift.T)/(2j))
    h = np.kron(np.eye(2), np.kron(PAULI[2], diagonal))
    for j in range(3):
        h += np.kron(PAULI[j], np.kron(PAULI[0], hops[j]))
    values, vectors = eigh(h)
    if min(abs(values)) <= 1e-10:
        raise ValueError("Gapless input model")
    if flatten:
        h = (vectors*np.sign(values)) @ vectors.conj().T
    angles = 2*np.pi*coords/side
    cosine = np.array([np.kron(np.eye(4), np.diag(np.cos(angles[:, j]))) for j in range(3)])
    sine = np.array([np.kron(np.eye(4), np.diag(np.sin(angles[:, j]))) for j in range(3)])
    masses = [mass+sum(np.cos(np.pi*np.array(k))) for k in product([0, 1], repeat=3)]
    strong = int((1-np.prod(np.sign(masses)))//2)
    return h, np.eye(len(h)), cosine, sine, float(min(abs(values))), strong


def block(h, s, cosine, sine, origin, energy, eta):
    """Covariant chiral block, not trigonometric functions of projected X."""
    c = np.array([np.cos(origin[j])*cosine[j]+np.sin(origin[j])*sine[j] for j in range(3)])
    t = np.array([np.cos(origin[j])*sine[j]-np.sin(origin[j])*cosine[j] for j in range(3)])
    result = np.kron(np.eye(2), h-energy*s-eta*(3*s-c.sum(axis=0))).astype(complex)
    for j in range(3):
        result -= 1j*eta*np.kron(PAULI[j], t[j])
    return result


def evaluate(h, s, cosine, sine, origin=(0., 0., 0.), energy=0., eta=1.):
    n = len(h)
    if n % 2 or eta <= 0:
        raise ValueError("Invalid spin dimension or scale")
    jspin = np.kron(1j*PAULI[1], np.eye(n//2))
    operators = [h, s, *cosine, *sine]
    for matrix in operators:
        if not np.isfinite(matrix).all() or np.max(abs(matrix-matrix.conj().T)) > 1e-10:
            raise ValueError("Invalid Hermitian operator")
        if np.max(abs(jspin @ matrix.conj() @ jspin.conj().T-matrix)) > 1e-10:
            raise ValueError("Broken fixed time reversal")
    a = block(h, s, cosine, sine, origin, energy, eta)
    c = np.kron(1j*PAULI[1], jspin)
    q = (np.eye(2*n)-1j*c)/np.sqrt(2.)
    real = q.conj().T @ a @ q
    imaginary_residual = float(np.max(abs(real.imag)))
    if imaginary_residual > 1e-10:
        raise ValueError("Chiral block does not admit the required real structure")
    metric_values, metric_vectors = eigh(s)
    if min(metric_values) <= 1e-10*max(metric_values):
        raise ValueError("Nonpositive or unresolved AO metric")
    inv = np.kron(np.eye(2), (metric_vectors/np.sqrt(metric_values)) @ metric_vectors.conj().T)
    normalized = inv @ a @ inv
    gap = float(svdvals(normalized)[-1])
    sign, logabs = np.linalg.slogdet(real.real)
    if gap <= 1e-10 or sign == 0:
        raise ValueError("Unresolved localizer")
    # The atomic positive-H reference has no occupied topological subspace.
    atomic = block(s, s, cosine, sine, origin, 0., eta)
    atomic_real = q.conj().T @ atomic @ q
    reference_gap = float(svdvals(inv @ atomic @ inv)[-1])
    reference_sign = np.linalg.slogdet(atomic_real.real)[0]
    if reference_gap <= 1e-10 or np.max(abs(atomic_real.imag)) > 1e-10 or reference_sign == 0:
        raise ValueError("Unresolved atomic reference")
    return {"z2": int((1-sign*reference_sign)//2), "gap": gap,
            "determinant_sign": int(sign), "reference_sign": int(reference_sign),
            "reference_gap": reference_gap, "imaginary_residual": imaginary_residual,
            "log_absolute_determinant": float(logabs)}, normalized


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    started = time.monotonic()
    cases = []
    for side, mass in product([3, 4, 6], [-4., -2., 0., 2., 4.]):
        h, s, co, si, physical_gap, expected = dirac_model(side, mass)
        try:
            result, _ = evaluate(h, s, co, si)
            result["matches_bulk_strong_index"] = result["z2"] == expected
        except ValueError as error:
            result = {"error": str(error), "matches_bulk_strong_index": False}
        cases.append({"side": side, "mass": mass, "physical_gap": physical_gap,
                      "bulk_strong_index": expected, **result})
        print(json.dumps(cases[-1]), flush=True)
    report = {"cases": cases, "elapsed_seconds": time.monotonic()-started,
              "method_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "reference": "https://doi.org/10.1007/s11040-025-09508-0",
              "scope": "Dense exact-sign periodic Wilson-Dirac model, not AO or native CP2K validation"}
    with args.output.open("x") as stream:
        stream.write(json.dumps(report, indent=2, allow_nan=False)+"\n")


if __name__ == "__main__":
    main()
