"""Native 3D torus compared with full-band SOC Bloch/MMN reconstruction."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

import numpy as np
from scipy.linalg import svdvals

from gaussian_states import read_snapshot
from periodic_3d_reference import PAULI, block


ROOT = Path("/Users/tkuehne/cp2k-spectral-localizer")
CELL = np.array([[6., 0., 0.], [1.2, 6., 0.], [.8, .4, 6.]])
COORDS = np.array([[x, y, z] for z in range(2) for y in range(2) for x in range(2)])
ORIGIN = np.array([1.2, 2.3, 3.1])


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def nnkp():
    lines = ["begin real_lattice"]
    lines += [" ".join(f"{x:.16g}" for x in row) for row in CELL]
    lines += ["end real_lattice", "begin recip_lattice"]
    lines += [" ".join(f"{x:.16g}" for x in row) for row in 2*np.pi*np.linalg.inv(CELL).T]
    lines += ["end recip_lattice", "begin kpoints", "8"]
    lines += [" ".join(f"{x:.16g}" for x in row/2) for row in COORDS]
    lines += ["end kpoints", "begin nnkpts", "3"]
    for ik, row in enumerate(COORDS):
        for axis in range(3):
            neighbor = row.copy()
            neighbor[axis] += 1
            shift = neighbor//2
            target = int((neighbor % 2) @ [1, 2, 4])
            lines.append(f"{ik+1} {target+1} " + " ".join(map(str, shift)))
    lines += ["end nnkpts", ""]
    return "\n".join(lines)


def reference(work, origin, flatten):
    snapshot = read_snapshot(work/"torus.topology")
    nk, ns, nao, nb = snapshot.coefficients.shape
    assert nk == 8 and ns == 2 and nb == 2*nao
    assert np.array_equal(snapshot.bands, np.arange(nb))
    assert np.max(abs(snapshot.kpoints-COORDS/2)) < 1e-12
    links = np.empty((nk, 3, nb, nb), complex)
    targets = np.empty((nk, 3), int)
    with (work/"torus.mmn").open() as stream:
        next(stream)
        assert list(map(int, next(stream).split())) == [nb, nk, 3]
        for ik, row in enumerate(COORDS):
            for axis in range(3):
                source, target, *shift = map(int, next(stream).split())
                neighbor = row.copy()
                neighbor[axis] += 1
                assert source == ik+1 and target == int((neighbor % 2) @ [1, 2, 4])+1
                assert shift == list(neighbor//2)
                values = np.array([list(map(float, next(stream).split())) for _ in range(nb*nb)])
                links[ik, axis] = (values[:, 0]+1j*values[:, 1]).reshape(nb, nb, order="F")
                targets[ik, axis] = target-1
        assert not stream.read().strip()
    n = nk*nb
    transform = np.empty((n, n), complex)
    for ik in range(nk):
        u, _, vh = np.linalg.svd(snapshot.coefficients[ik].reshape(nb, nb))
        frame = u@vh
        for ir, row in enumerate(COORDS):
            phase = np.exp(2j*np.pi*snapshot.kpoints[ik]@row)/np.sqrt(nk)
            for spin in range(2):
                rows = slice(spin*nk*nao+ir*nao, spin*nk*nao+(ir+1)*nao)
                transform[rows, ik*nb:(ik+1)*nb] = phase*frame[spin*nao:(spin+1)*nao]
    unitarity = float(np.max(abs(transform.conj().T@transform-np.eye(n))))
    assert unitarity < 1e-11
    cosine, sine = [], []
    for axis in range(3):
        exponent = np.zeros((n, n), complex)
        for ik in range(nk):
            exponent[ik*nb:(ik+1)*nb, targets[ik, axis]*nb:(targets[ik, axis]+1)*nb] = links[ik, axis]
        exponent = transform@exponent@transform.conj().T
        cosine.append((exponent+exponent.conj().T)/2)
        sine.append((exponent.conj().T-exponent)/(2j))
    shifted = snapshot.energies.ravel()+.1
    assert min(abs(shifted)) > 1e-8
    if flatten:
        shifted = np.sign(shifted)
    h = (transform*shifted)@transform.conj().T
    phase = np.pi*origin@np.linalg.inv(CELL)
    a = block(h, np.eye(n), cosine, sine, phase, 0., .5)
    jspin = np.kron(1j*PAULI[1], np.eye(n//2))
    c = np.kron(1j*PAULI[1], jspin)
    q = (np.eye(2*n)-1j*c)/np.sqrt(2.)
    real = q.conj().T@a@q
    residual = float(np.max(abs(real.imag)))
    assert residual < 1e-10
    sign = np.linalg.slogdet(real.real)[0]
    gap = float(svdvals(a)[-1])
    assert gap > 1e-8 and sign != 0
    return {"gap_hartree": gap, "z2": int((1-sign)//2), "real_structure_residual": residual,
            "fourier_unitarity": unitarity, "scalar_aos": nao, "full_spinor_dimension": n}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("work", type=Path)
    parser.add_argument("--version", choices=["ssmp", "psmp"], default="ssmp")
    parser.add_argument("--ranks", type=int, default=1)
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()
    args.work.mkdir(exist_ok=False)
    build = ROOT/("build-serial" if args.version == "ssmp" else "build-mpi")
    binary = build/"bin"/("cp2k."+args.version)
    tracked = [binary, build/"src/libcp2k.2026.2.dylib"]
    fingerprints = {str(p): digest(p) for p in tracked}
    source = (ROOT/"tests/QS/regtest-spectral-localizer-3d/torus-common.inc").read_text()
    export = """    &PRINT
      &WANNIER90
        KPOINTS_SOURCE NNKP
        NNKP_FILE torus.nnkp
        SEED_NAME torus
        SOC T
        TIME_REVERSAL T
        STATE_EXPORT T
      &END WANNIER90
    &END PRINT
"""
    source = source.replace("  &END DFT", export+"  &END DFT")
    env = os.environ | {"OPENBLAS_NUM_THREADS": "1", "VECLIB_MAXIMUM_THREADS": "1",
                        "OMP_NUM_THREADS": str(args.threads), "OMP_STACKSIZE": "128M",
                        "CP2K_DATA_DIR": str(ROOT/"data"),
                        "DYLD_LIBRARY_PATH": str(ROOT/"build-serial/openblas-thread-safe/lib")}
    results = []
    for name, method, flatten, symmetry, origin in [
        ("gpw", "GPW", False, False, ORIGIN),
        ("shifted", "GPW", False, False, ORIGIN+2*CELL.sum(axis=0)),
        ("gapw", "GAPW", False, False, ORIGIN),
        ("flattened", "GPW", True, True, ORIGIN),
    ]:
        work = args.work/name
        work.mkdir()
        text = source
        for key, value in {"AO_METHOD": method, "FLATTEN": "T" if flatten else "F",
                           "SCF_SYMMETRY": "T" if symmetry else "F",
                           "ORIGIN": " ".join(map(str, origin))}.items():
            text = text.replace("${"+key+"}", value)
        (work/"input.inp").write_text(text)
        (work/"torus.nnkp").write_text(nnkp())
        command = [str(binary), "-i", "input.inp", "-o", "output.out"]
        if args.version == "psmp":
            command = ["mpiexec", "--bind-to", "none", "-np", str(args.ranks), *command]
        started = time.monotonic()
        with (work/"stdout.log").open("x") as stream:
            result = subprocess.run(command, cwd=work, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=300)
        output = (work/"output.out").read_text()
        assert result.returncode == 0 and "PROGRAM ENDED AT" in output and "*** SCF run converged" in output, name
        native_gap = float(re.search(r"SPECTRAL_LOCALIZER\| Gap \[hartree\]:\s+([-+\d.E]+)", output)[1])
        native_z2 = int(re.search(r"SPECTRAL_LOCALIZER\| Z2 index:\s+(\d+)", output)[1])
        independent = reference(work, origin, flatten)
        delta = abs(independent["gap_hartree"]-native_gap)
        assert delta < 2e-8 and independent["z2"] == native_z2, (name, independent, native_gap, native_z2)
        record = {"case": name, "native_gap_hartree": native_gap, "native_z2": native_z2,
                  "independent": independent, "gap_difference_hartree": delta,
                  "elapsed_seconds": time.monotonic()-started,
                  "files": {p.name: digest(p) for p in work.iterdir() if p.is_file()}}
        results.append(record)
        print(json.dumps(record | {"files": "hashes retained in summary"}), flush=True)
        (args.work/"summary.json").write_text(json.dumps({"completed": False, "cases": results}, indent=2)+"\n")
    assert abs(results[0]["native_gap_hartree"]-results[1]["native_gap_hartree"]) < 1e-11
    assert fingerprints == {str(p): digest(p) for p in tracked}
    report = {"completed": True, "version": args.version, "ranks": args.ranks, "threads": args.threads,
              "cases": results, "binaries": fingerprints, "tolerance_hartree": 2e-8,
              "methods": {p.name: digest(p) for p in [Path(__file__), Path(__file__).with_name("gaussian_states.py"),
                           Path(__file__).with_name("periodic_3d_reference.py")]}}
    (args.work/"summary.json").write_text(json.dumps(report, indent=2)+"\n")


if __name__ == "__main__":
    main()
