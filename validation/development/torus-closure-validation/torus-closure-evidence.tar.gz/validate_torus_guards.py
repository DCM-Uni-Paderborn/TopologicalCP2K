"""Ensure unsupported 3D torus combinations fail before assigning an index."""

import json
import os
from pathlib import Path
import subprocess

root = Path("/Users/tkuehne/cp2k-spectral-localizer")
work = Path(__file__).resolve().parent/"periodic-3d-guards-final"
work.mkdir(exist_ok=False)
source = (work.parent/"native-torus-serial/gpw/input.inp").read_text()
env = os.environ | {"OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1",
    "OMP_STACKSIZE": "128M", "CP2K_DATA_DIR": str(root/"data"),
    "DYLD_LIBRARY_PATH": str(root/"build-serial/openblas-thread-safe/lib")}
cases = {
    "dimension": ("DIMENSION 3", "DIMENSION 4", "DIMENSION must be 2 or 3"),
    "plane": ("DIMENSION 3", "DIMENSION 3\n      PLANE XY", "PLANE is only valid for DIMENSION 2"),
    "chern": ("INVARIANT Z2", "INVARIANT CHERN", "DIMENSION 3 requires INVARIANT Z2"),
    "soc": ("      SOC T", "      SOC F", "requires SOC T and TIME_REVERSAL T"),
    "time-reversal": ("TIME_REVERSAL T", "TIME_REVERSAL F", "requires SOC T and TIME_REVERSAL T"),
    "mumps": ("SOLVER DENSE", "SOLVER MUMPS", "3D determinant path requires SOLVER DENSE"),
    "tacho": ("SOLVER DENSE", "SOLVER TACHO", "3D determinant path requires SOLVER DENSE"),
    "periodicity": ("PERIODIC XYZ", "PERIODIC XY", "requires CELL and POISSON PERIODIC XYZ"),
    "kappa": ("ETA [hartree] 0.5", "KAPPA 0.5", "Use ETA, not KAPPA"),
}
results = []
for name, (old, new, expected) in cases.items():
    directory = work/name
    directory.mkdir()
    if name in {"soc", "time-reversal"}:
        head, separator, tail = source.partition("&PROPERTIES")
        text = head+separator+tail.replace(old, new, 1)
    elif name == "periodicity":
        text = source.replace(old, new).replace("POISSON_SOLVER PERIODIC", "POISSON_SOLVER ANALYTIC")
        text = text.replace("2 2 2", "2 2 1").replace("B 1.2 6.0 0.0", "B 0.0 6.0 0.0")
        text = text.replace("C 0.8 0.4 6.0", "C 0.0 0.0 6.0")
    else:
        text = source.replace(old, new, 1)
    (directory/"input.inp").write_text(text)
    with (directory/"stdout.log").open("x") as stream:
        result = subprocess.run([str(root/"build-serial/bin/cp2k.ssmp"), "-i", "input.inp", "-o", "output.out"],
            cwd=directory, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=60)
    output = (directory/"output.out").read_text()
    assert result.returncode and expected in output and "SPECTRAL_LOCALIZER| Z2 index:" not in output, name
    results.append({"name": name, "returncode": result.returncode, "diagnostic": expected})
    print(name, "passed", flush=True)
(work/"summary.json").write_text(json.dumps({"completed": True, "cases": results}, indent=2)+"\n")
