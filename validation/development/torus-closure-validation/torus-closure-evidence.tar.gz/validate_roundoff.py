"""Closing tests for the bounded dense-AII skew projection correction."""

import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

root = Path("/Users/tkuehne/cp2k-spectral-localizer")
work = Path(__file__).resolve().parent/"roundoff-validation"
work.mkdir(exist_ok=False)
sources = [root/"src/spectral_localizer.F", root/"src/spectral_localizer_unittest.F"]
fingerprints = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
records = []
for mode, ranks in [("serial", 0), ("mpi", 2)]:
    suffix = "ssmp" if ranks == 0 else "psmp"
    prefix = [] if ranks == 0 else ["mpiexec", "--bind-to", "none", "-np", str(ranks)]
    env = os.environ | {"OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1", "OMP_STACKSIZE": "128M",
        "CP2K_DATA_DIR": str(root/"data"), "DYLD_LIBRARY_PATH": str(root/"build-serial/openblas-thread-safe/lib")}
    commands = [(name, prefix+[str(root/f"build-{mode}/bin/{name}.{suffix}")])
                for name in ["spectral_localizer_unittest", "spectral_localizer_3d_unittest"]]
    if ranks:
        commands.append(("sparse-unit", prefix+[str(root/"build-mpi/bin/spectral_localizer_sparse_unittest.psmp"), "5"]))
    commands.append(("regtests", [sys.executable, "-B", str(root/"tests/do_regtest.py"),
        "--mpiranks", str(max(1, ranks)), "--ompthreads", "1", "--maxtasks", "1", "--timeout", "180",
        "--skip_unittests", "--mpiexec", "mpiexec --bind-to none -np {N}",
        "--restrictdir", r"QS/regtest-spectral-localizer(|-3d|-mumps|-tacho)",
        "--workbasedir", str(work/mode), "--cp2kdatadir", str(root/"data"), str(root/f"build-{mode}/bin"), suffix]))
    for name, command in commands:
        log = work/f"{mode}-{name}.log"
        start = time.monotonic()
        with log.open("x") as stream:
            result = subprocess.run(command, cwd=work, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=1200)
        row = {"name": mode+"-"+name, "command": command, "returncode": result.returncode,
               "seconds": time.monotonic()-start, "log_sha256": hashlib.sha256(log.read_bytes()).hexdigest()}
        if name == "regtests":
            row["summary"] = re.findall(r"^Summary:.*$", log.read_text(), re.M)
            assert "Status: OK" in log.read_text()
        records.append(row)
        (work/"summary.json").write_text(json.dumps({"completed": False, "runs": records}, indent=2)+"\n")
        print(json.dumps(row), flush=True)
        assert result.returncode == 0
assert fingerprints == {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
(work/"summary.json").write_text(json.dumps({"completed": True, "runs": records,
    "sources": fingerprints}, indent=2)+"\n")
