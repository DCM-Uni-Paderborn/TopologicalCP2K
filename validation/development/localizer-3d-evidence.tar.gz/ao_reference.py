"""Run finite SOC controls and independently check 3D localizers from printed AO matrices."""

import argparse
import json
import os
from pathlib import Path
import re
import subprocess

import numpy as np
from scipy.linalg import eigh, lu_factor, svdvals

ROOT = Path(__file__).resolve().parents[1]
SIGMA = np.array([[[0, 1], [1, 0]], [[0, -1j], [1j, 0]], [[1, 0], [0, -1]]])
BOHR = 0.529177210903


def read_matrix(text, label, skew=False):
    records, columns = {}, []
    lines = text.split(label)[-1].splitlines()
    for line in lines:
        fields = line.split()
        if fields and all(part.isdigit() for part in fields):
            columns = [int(part) - 1 for part in fields]
        elif columns and fields and fields[0].isdigit():
            offset = 1 if skew else 4
            if len(fields) != offset + len(columns):
                continue
            row = int(fields[0]) - 1
            for col, value in zip(columns, fields[offset:]):
                records[row, col] = float(value)
        elif records and (line.strip().startswith("AO ") or line.strip().endswith(" MATRIX")):
            break
    n = max(max(pair) for pair in records) + 1
    result = np.full((n, n), np.nan)
    for pair, value in records.items():
        result[pair] = value
    if not np.isfinite(result).all():
        raise ValueError((label, "incomplete matrix", len(records), n))
    if np.max(abs(result - (-1 if skew else 1)*result.T)) > 1e-11:
        raise ValueError((label, "transpose symmetry"))
    return result


def reference(directory, flattened):
    matrices = {}
    hamiltonians = []
    labels = ["OVERLAP MATRIX", "KOHN-SHAM MATRIX"]
    labels += [f"AO POSITION {axis} [bohr]; coordinate origin; covariant AO matrix" for axis in "XYZ"]
    labels += [f"AO SOC {axis} [hartree]; real antisymmetric component; multiply by i" for axis in "XYZ"]
    for path in sorted(directory.glob("*.Log"), key=lambda p: tuple(map(int, re.findall(r"\d+", p.name)))):
        text = path.read_text()
        for label in labels:
            if "-SOC_" in path.name and not label.startswith("AO SOC"):
                continue
            if label in text:
                matrices[label] = read_matrix(text, label, label.startswith("AO SOC"))
                if label == "KOHN-SHAM MATRIX":
                    hamiltonians.append((path.name, matrices[label]))
    if set(labels) != matrices.keys():
        raise ValueError((directory, "missing AO matrices", matrices.keys()))
    s = matrices[labels[0]]
    # qs_scf_post_gpw refreshes H for the final AO print AFTER the localizer.
    # The immediately preceding SCF print is the actual localizer Hamiltonian.
    if len(hamiltonians) < 2:
        raise ValueError("SCF-step and post-SCF Hamiltonians both required")
    source_name, scalar_h = hamiltonians[-2]
    h = np.kron(np.eye(2), scalar_h)
    # Printed GTH components use H_ud=i Lx-Ly, H_du=i Lx+Ly.
    h = h + sum((-1 if j == 1 else 1)*np.kron(SIGMA[j], 1j*matrices[labels[5+j]]) for j in range(3))
    metric = np.kron(np.eye(2), s)
    coordinates = [np.kron(np.eye(2), matrices[labels[2+j]]) for j in range(3)]
    es, cs = eigh(metric)
    inverse = (cs/np.sqrt(es)) @ cs.conj().T
    hbar = inverse @ h @ inverse + 0.1*np.eye(len(h))
    if flattened:
        energies, orbitals = eigh(hbar)
        hbar = (orbitals*np.sign(energies)) @ orbitals.conj().T
    output = (directory/"cp2k.out").read_text()
    point = np.fromstring(re.findall(r"SPECTRAL_LOCALIZER\| Position \[bohr\]:\s*([^\n]+)", output)[-1], sep=" ")
    if np.max(abs(point*BOHR - [3.0, 2.9, 3.2])) > 1e-6:
        raise ValueError("Query frame mismatch")
    block = np.kron(np.eye(2), hbar)
    for j in range(3):
        xbar = inverse @ coordinates[j] @ inverse - point[j]*np.eye(len(h))
        block -= 0.1j*np.kron(SIGMA[j], xbar)
    gap = svdvals(block)[-1]
    lu, pivots = lu_factor(block)
    diagonals = np.diag(lu)
    phase = np.prod(diagonals/abs(diagonals)) * (-1)**np.count_nonzero(pivots != np.arange(len(pivots)))
    if abs(phase.imag) > 1e-10:
        raise ValueError((directory, "nonreal determinant", phase))
    native_gap = float(re.findall(r"SPECTRAL_LOCALIZER\| Gap \[hartree\]:\s+(\S+)", output)[-1])
    native_index = int(re.findall(r"SPECTRAL_LOCALIZER\| Z2 index:\s+(\d+)", output)[-1])
    index = int(phase.real < 0)
    if native_index != index or abs(gap-native_gap) > 2e-9:
        raise ValueError((directory, "native/oracle mismatch", native_index, index, native_gap, gap))
    return dict(nao=len(s), native_index=native_index, native_gap=native_gap, source_hamiltonian=source_name,
                post_scf_refresh_max=float(np.max(abs(scalar_h-hamiltonians[-1][1]))),
                oracle_gap=float(gap), difference=float(abs(gap-native_gap)),
                determinant_imaginary=float(abs(phase.imag)), metric_ratio=float(es[0]/es[-1]))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("work", type=Path)
    parser.add_argument("--ranks", type=int, default=0)
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    work = args.work.resolve()
    common = (ROOT/"tests/QS/regtest-spectral-localizer-3d/neon-common.inc").read_text()
    printing = """    &PRINT
      &AO_MATRICES ON
        OVERLAP T
        KOHN_SHAM_MATRIX T
        POSITION T
        SOC T
        NDIGITS 16
        FILENAME ao
      &END AO_MATRICES
    &END PRINT
"""
    common = common.replace("  &END DFT", printing + "  &END DFT")
    cases = [("gpw", "GPW", False), ("gapw", "GAPW", False), ("flattened", "GPW", True)]
    env = os.environ | dict(OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="2", OMP_STACKSIZE="128M",
                           CP2K_DATA_DIR=str(ROOT/"data"),
                           DYLD_LIBRARY_PATH=str(ROOT/"build-serial/openblas-thread-safe/lib"))
    records = {}
    for name, method, flattened in cases:
        directory = work/name
        if not args.check_only and not directory.exists():
            directory.mkdir(parents=True, exist_ok=False)
            text = common.replace("${AO_METHOD}", method).replace("${FLATTEN}", "T" if flattened else "F")
            text = text.replace("${GAP_THRESHOLD}", "1.0E-8")
            (directory/"input.inp").write_text(text)
            cmd = [str(ROOT/"build-serial/bin/cp2k.ssmp"), "-i", "input.inp", "-o", "cp2k.out"]
            if args.ranks:
                cmd = ["mpiexec", "-n", str(args.ranks), str(ROOT/"build-mpi/bin/cp2k.psmp"), *cmd[1:]]
            with (directory/"process.log").open("w") as log:
                subprocess.run(cmd, cwd=directory, env=env, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=300)
        output = (directory/"cp2k.out").read_text()
        if "SCF run converged" not in output or "PROGRAM ENDED AT" not in output:
            raise ValueError((directory, "not a converged complete calculation"))
        records[name] = reference(directory, flattened)
        print(name, json.dumps(records[name]), flush=True)
    (work/"comparison.json").write_text(json.dumps(records, indent=2)+"\n")


if __name__ == "__main__":
    main()
