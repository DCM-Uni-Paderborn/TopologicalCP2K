"""Reproduce the finite 3D localizer checks without changing reference values."""

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path('/Users/tkuehne/cp2k-spectral-localizer')
WORK = Path(__file__).resolve().parent
RESULTS = []


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def snapshot():
    paths = subprocess.check_output(
        ['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard'], cwd=ROOT
    ).decode().split('\0')
    return {p: digest(ROOT / p) for p in sorted(set(paths)) if p and (ROOT / p).is_file()}


def run(name, command, threads=1, cwd=WORK, expect_failure=False):
    log = WORK / (name + '.log')
    env = os.environ | {
        'OPENBLAS_NUM_THREADS': '1', 'OMP_NUM_THREADS': str(threads),
        'OMP_STACKSIZE': '128M', 'VECLIB_MAXIMUM_THREADS': '1',
        'CP2K_DATA_DIR': str(ROOT / 'data'),
        'DYLD_LIBRARY_PATH': str(ROOT / 'build-serial/openblas-thread-safe/lib'),
    }
    start = time.monotonic()
    with log.open('w') as stream:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=stream,
                                stderr=subprocess.STDOUT, timeout=1800)
    record = dict(name=name, command=list(map(str, command)), threads=threads,
                  seconds=time.monotonic()-start, returncode=result.returncode,
                  log=log.name, sha256=digest(log))
    RESULTS.append(record)
    print(name, result.returncode, f'{record["seconds"]:.2f}s', flush=True)
    if (result.returncode == 0) == expect_failure:
        raise RuntimeError(f'Unexpected status: {record}')
    return log.read_text()


def cp2k_command(mode, ranks, directory):
    binary = ROOT / f'build-{mode}/bin/cp2k.{"ssmp" if mode == "serial" else "psmp"}'
    command = [str(binary), '-i', 'input.inp', '-o', 'cp2k.out']
    return (['mpiexec', '--bind-to', 'none', '-np', str(ranks)] if ranks else []) + command


def main():
    before = snapshot()
    (WORK / 'source-before.json').write_text(json.dumps(before, indent=2)+'\n')
    modules = ['spectral_localizer_unittest', 'spectral_localizer_3d_unittest',
               'spectral_localizer_flatten_unittest', 'quadratic_pseudospectrum_unittest',
               'quadratic_dbcsr_unittest']
    for mode, ranks, threads in [('serial', 0, 1), ('serial', 0, 2), ('mpi', 1, 2), ('mpi', 2, 1)]:
        suffix = 'ssmp' if mode == 'serial' else 'psmp'
        prefix = ['mpiexec', '--bind-to', 'none', '-np', str(ranks)] if ranks else []
        for module in modules + (['spectral_localizer_sparse_unittest'] if ranks else []):
            command = prefix + [str(ROOT / f'build-{mode}/bin/{module}.{suffix}')]
            if module == 'spectral_localizer_sparse_unittest':
                command.append('5')
            run(f'{module}-{mode}-{ranks}r{threads}t', command, threads)
        directories = r'QS/regtest-(spectral-localizer(|-3d|-mumps|-tacho)|quadratic-pseudospectrum(|-mumps))'
        text = run(f'regtests-{mode}-{ranks}r{threads}t', [
            sys.executable, '-B', str(ROOT / 'tests/do_regtest.py'), '--mpiranks', str(max(1, ranks)),
            '--ompthreads', str(threads), '--maxtasks', '1', '--timeout', '180', '--skip_unittests',
            '--mpiexec', 'mpiexec --bind-to none -np {N}', '--restrictdir', directories,
            '--workbasedir', str(WORK / f'regtests-{mode}-{ranks}r{threads}t'),
            '--cp2kdatadir', str(ROOT / 'data'), str(ROOT / f'build-{mode}/bin'), suffix,
        ], threads)
        if 'Status: OK' not in text:
            raise RuntimeError('Regtest driver did not report success')
        RESULTS[-1]['summary'] = re.findall(r'^Summary:.*$', text, re.M)[-1]

    oracle_path = ROOT / 'build-serial/check_localizer_3d.py'
    spec = importlib.util.spec_from_file_location('localizer_reference', oracle_path)
    oracle = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(oracle)
    common = (ROOT / 'tests/QS/regtest-spectral-localizer-3d/neon-common.inc').read_text()
    printing = '''    &PRINT
      &AO_MATRICES ON
        OVERLAP T
        KOHN_SHAM_MATRIX T
        POSITION T
        SOC T
        NDIGITS 16
        FILENAME ao
      &END AO_MATRICES
    &END PRINT
'''
    common = common.replace('  &END DFT', printing + '  &END DFT')
    references = {}
    for mode, ranks, threads in [('serial', 0, 2), ('mpi', 2, 1)]:
        for name, method, flattened in [('gpw', 'GPW', False), ('gapw', 'GAPW', False),
                                         ('flattened', 'GPW', True)]:
            directory = WORK / f'oracle-{mode}' / name
            directory.mkdir(parents=True, exist_ok=False)
            text = common.replace('${AO_METHOD}', method).replace('${FLATTEN}', 'T' if flattened else 'F')
            text = text.replace('${GAP_THRESHOLD}', '1.0E-8')
            (directory / 'input.inp').write_text(text)
            run(f'oracle-{mode}-{name}', cp2k_command(mode, ranks, directory), threads, directory)
            output = (directory / 'cp2k.out').read_text()
            if 'SCF run converged' not in output or 'PROGRAM ENDED AT' not in output:
                raise RuntimeError('Incomplete SCF oracle input')
            references[f'{mode}-{name}'] = oracle.reference(directory, flattened)
    (WORK / 'oracle-results.json').write_text(json.dumps(references, indent=2)+'\n')

    guards = {
        'dimension': ('DIMENSION 3', 'DIMENSION 4', 'DIMENSION must be 2 or 3'),
        'periodic': ('DIMENSION 3', 'DIMENSION 3\n      FORMULATION PERIODIC', 'requires FORMULATION FINITE'),
        'plane': ('DIMENSION 3', 'DIMENSION 3\n      PLANE XZ', 'PLANE is only valid for DIMENSION 2'),
        'chern': ('INVARIANT Z2', 'INVARIANT CHERN', 'DIMENSION 3 requires INVARIANT Z2'),
        'soc': ('      SOC T\n      TIME_REVERSAL', '      SOC F\n      TIME_REVERSAL', 'requires SOC T and TIME_REVERSAL T'),
        'time-reversal': ('TIME_REVERSAL T', 'TIME_REVERSAL F', 'requires SOC T and TIME_REVERSAL T'),
        'mumps': ('DIMENSION 3', 'DIMENSION 3\n      SOLVER MUMPS', '3D determinant path requires SOLVER DENSE'),
        'tacho': ('DIMENSION 3', 'DIMENSION 3\n      SOLVER TACHO', '3D determinant path requires SOLVER DENSE'),
    }
    source = (WORK / 'oracle-serial/gpw/input.inp').read_text()
    for name, (old, new, expected) in guards.items():
        assert old in source
        directory = WORK / 'guards' / name
        directory.mkdir(parents=True, exist_ok=False)
        (directory / 'input.inp').write_text(source.replace(old, new))
        run(f'guard-{name}', cp2k_command('serial', 0, directory), 1, directory, expect_failure=True)
        output = (directory / 'cp2k.out').read_text()
        if expected not in output or 'SPECTRAL_LOCALIZER| Z2 index:' in output:
            raise RuntimeError(f'Wrong diagnostic for {name}')
        RESULTS[-1]['expected_diagnostic'] = expected

    after = snapshot()
    assert before == after, 'Source tree changed during validation'
    binaries = {str(p.relative_to(ROOT)): digest(p) for mode in ['serial', 'mpi']
                for p in (ROOT / f'build-{mode}/bin').glob('*')
                if p.is_file() and ('localizer' in p.name or 'quadratic' in p.name or p.name.startswith('cp2k.'))}
    (WORK / 'validation-result.json').write_text(json.dumps(dict(
        passed=True, runs=RESULTS, oracle=references, oracle_script_sha256=digest(oracle_path),
        source_paths_verified=len(after), binary_sha256=binaries,
        scope='Current local research tree; single-machine SSMP and MPI/OpenMP. Finite dense 3D AII, not periodic/sparse 3D.',
    ), indent=2)+'\n')
    print('All validation stages passed.', flush=True)


if __name__ == '__main__':
    try:
        main()
    except BaseException:
        (WORK / 'incomplete-runs.json').write_text(json.dumps(RESULTS, indent=2)+'\n')
        raise
