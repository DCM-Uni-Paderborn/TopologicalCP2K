"""Verify unpacked finite-3D evidence and replay its six independent AO matrix checks.

Usage: python verify_evidence.py PATH_TO_UNPACKED_EVIDENCE
Requires NumPy and SciPy, but no CP2K executable.
"""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

root = Path(sys.argv[1]).resolve()
manifest = json.loads((root / 'manifest.json').read_text())
for name, expected in manifest.items():
    path = root / name
    assert path.is_relative_to(root) and path.is_file(), name
    assert path.stat().st_size == expected['bytes'], name
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected['sha256'], name
record = json.loads((root / 'validation-result.json').read_text())
assert record['passed'] and len(record['runs']) == 40
assert len({item['name'] for item in record['runs']}) == 40
units = [r for r in record['runs'] if '_unittest-' in r['name']]
regtests = [r for r in record['runs'] if r['name'].startswith('regtests-')]
guards = [r for r in record['runs'] if r['name'].startswith('guard-')]
assert len(units) == 22 and len(regtests) == 4 and len(guards) == 8
for item in record['runs']:
    log = root / item['log']
    assert hashlib.sha256(log.read_bytes()).hexdigest() == item['sha256']
    assert (item['returncode'] != 0) == item['name'].startswith('guard-')
for item in regtests:
    text = (root / item['log']).read_text()
    assert 'Status: OK' in text and item['summary'] in text
for item in guards:
    text = (root / 'guards' / item['name'][6:] / 'cp2k.out').read_text()
    assert item['expected_diagnostic'] in text and 'SPECTRAL_LOCALIZER| Z2 index:' not in text
assert 'ERROR STOP 3D high-growth determinant sign' in (root / 'no-qr-unit.log').read_text()
for name in ['final-debug-unit.log', 'final-optimized-unit.log']:
    assert 'tests passed.' in (root / name).read_text()
spec = importlib.util.spec_from_file_location('ao_reference', root / 'ao_reference.py')
oracle = importlib.util.module_from_spec(spec)
spec.loader.exec_module(oracle)
replayed = {}
for mode in ['serial', 'mpi']:
    for name in ['gpw', 'gapw', 'flattened']:
        directory = root / f'oracle-{mode}' / name
        output = (directory / 'cp2k.out').read_text()
        assert 'SCF run converged' in output and 'PROGRAM ENDED AT' in output
        data = oracle.reference(directory, name == 'flattened')
        expected = record['oracle'][mode+'-'+name]
        assert data['native_index'] == expected['native_index']
        assert abs(data['oracle_gap']-expected['oracle_gap']) < 1e-12
        replayed[mode+'-'+name] = data
print(json.dumps(dict(verified_files=len(manifest), unit_runs=len(units),
                      regressions=[r['summary'] for r in regtests], rejected_inputs=len(guards),
                      independent_ao_replays=replayed), indent=2))
