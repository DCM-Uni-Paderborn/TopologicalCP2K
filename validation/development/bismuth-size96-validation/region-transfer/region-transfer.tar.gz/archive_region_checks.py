"""Retain the completed box-transfer analysis as a small linked supplement."""

import hashlib
import io
import json
from pathlib import Path
import tarfile


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


root = Path(__file__).resolve().parent
state = json.loads((root / "size-validation-state.json").read_text())
assert state["completed"] and all(s["returncode"] == 0 for s in state["steps"])
base = json.loads((root / "bismuth-size96-evidence/index.json").read_text())
for name, expected in state["method_fingerprints"].items():
    assert digest(root / name) == expected, name
    if name in base["files"]:
        assert base["files"][name] == expected, name
names = ["archive_region_checks.py", "size-validation-state.json", "post_material_workflow.py",
         "analyze_material_regions.py", "localizer_region.py", "size-comparison-plan.json"]
summary = {"base_archive_sha256": base["archive_sha256"], "boxes": [],
           "scope": "Completed fixed-H parameter-box analyses. The main archive replays the first box only."}
for i in range(3):
    name = f"flake96-regions/box-{i}.json"
    names.append(name)
    row = json.loads((root / name).read_text())
    assert len(row["checks"]) == 17
    assert row["plan_sha256"] == base["files"]["size-comparison-plan.json"]
    assert all(base["files"][method] == expected for method, expected in row["methods"].items())
    for item in ["run.json", "analysis.json", "bismuth.topology"]:
        assert row["input_hashes"][item] == base["files"]["flake96-spectrum/"+item]
    signs = {point["z2"] for point in row["checks"]}
    assert all(p["spectral_pairing_error_hartree"] < 1e-10 and
               p["middle_four_gap_error_hartree"] < 1e-10 for p in row["checks"])
    result = {"box": i, "status": row["status"], "z2": row["region_z2"]}
    if row["status"] == "resolved":
        assert signs == {row["region_z2"]} and row["bound"]["resolved"]
        assert not row["bound"]["unresolved"]
        result["minimum_gap_lower_bound_hartree"] = min(x["lower_bound"] for x in row["bound"]["covered"])
        assert result["minimum_gap_lower_bound_hartree"] > 0
        result["bound_evaluations"] = len(row["bound"]["evaluations"])
    else:
        assert row["status"] == "nonuniform" and signs == {0, 1} and row["bound"] is None
    summary["boxes"].append(result)
files = {name: digest(root / name) for name in names}
destination = root / "size96-region-transfer-evidence"
destination.mkdir(exist_ok=False)
archive_path = destination / "region-transfer.tar.gz"
manifest = json.dumps({"files": files, "summary": summary}, indent=2).encode()+b"\n"
with tarfile.open(archive_path, "x:gz") as archive:
    for name in names:
        archive.add(root / name, arcname=name, recursive=False)
    member = tarfile.TarInfo("manifest.json")
    member.size = len(manifest)
    archive.addfile(member, io.BytesIO(manifest))
assert files == {name: digest(root / name) for name in names}
part = {"name": archive_path.name, "bytes": archive_path.stat().st_size, "sha256": digest(archive_path)}
index = {"archive_sha256": part["sha256"], "archive_bytes": part["bytes"],
         "files": files, "summary": summary, "chunks": [part]}
(destination / "index.json").write_text(json.dumps(index, indent=2)+"\n")
print(json.dumps(summary, indent=2))
