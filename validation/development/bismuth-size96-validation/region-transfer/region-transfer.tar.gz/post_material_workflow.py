"""Run finite-size diagnostics only after the native/independent workflow passes."""

import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time


root = Path(__file__).resolve().parent
os.chdir(root)
state_path = root / "size-validation-state.json"
if state_path.exists():
    raise FileExistsError(state_path)
state = {"pid": os.getpid(), "started_epoch": time.time(), "completed": False, "steps": []}
files = ["compare_nested_material.py", "nested_subspace.py", "analyze_material_regions.py",
         "localizer_region.py", "size-comparison-plan.json", "post_material_workflow.py"]
fingerprints = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in files}
state["method_fingerprints"] = fingerprints


def save():
    temporary = state_path.with_suffix(".tmp")
    temporary.write_text(json.dumps(state, indent=2)+"\n")
    temporary.replace(state_path)


def run(name, arguments):
    assert fingerprints == {path: hashlib.sha256((root / path).read_bytes()).hexdigest() for path in files}
    command = [sys.executable, *arguments]
    step = {"name": name, "command": command, "started_epoch": time.time()}
    state["steps"].append(step)
    with (root / (name+".log")).open("x") as stream:
        child = subprocess.Popen(command, start_new_session=True, stdout=stream, stderr=subprocess.STDOUT,
                                 env=os.environ | {"OPENBLAS_NUM_THREADS": "4", "OMP_NUM_THREADS": "1"})
        step["pid"] = child.pid
        save()
        try:
            step["returncode"] = child.wait(timeout=10800)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=30)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
            step["returncode"] = child.returncode
            raise RuntimeError("Three-hour diagnostic time limit: "+name)
    step["finished_epoch"] = time.time()
    save()
    if step["returncode"]:
        raise RuntimeError("Failed stage: "+name)


try:
    save()
    while True:
        previous = json.loads((root / "workflow-state.json").read_text())
        if previous.get("error"):
            raise RuntimeError("Native workflow failed: "+previous["error"])
        if previous["completed"]:
            break
        process = Path("/proc") / str(previous["pid"]) / "cmdline"
        if not process.exists() or b"material_workflow.py" not in process.read_bytes():
            raise RuntimeError("Native workflow handle is no longer live")
        state["waiting_for_pid"] = previous["pid"]
        save()
        time.sleep(10)
    assert len(previous["steps"]) == 4 and all(item["returncode"] == 0 for item in previous["steps"])
    native = json.loads((root / "flake96-native/analysis.json").read_text())
    assert native["native_comparison"]["accepted"]
    state.pop("waiting_for_pid", None)
    run("nested-size-comparison", ["compare_nested_material.py", "reference48", "flake96-spectrum", "nested-size-comparison"])
    run("flake96-regions", ["analyze_material_regions.py", "flake96-spectrum", "flake96-regions"])
    state["completed"] = True
except Exception as error:
    state["error"] = repr(error)
    raise
finally:
    save()
