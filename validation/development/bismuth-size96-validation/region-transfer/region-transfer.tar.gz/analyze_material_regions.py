"""Test transfer of the three previously resolved 48-atom parameter boxes."""

import argparse
import hashlib
from itertools import product
import json
from pathlib import Path
import time

import numpy as np
from scipy.linalg import eigvalsh, svdvals

import analyze_bismuth_flakes as analysis
from check_bloch_localizer import aii_skew, skew_sign
from gaussian_states import read_snapshot
from localizer_region import cover_region, variation_bound


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("work", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    work = args.work.resolve()
    plan_path = root / "size-comparison-plan.json"
    plan = json.loads(plan_path.read_text())["box_transfer_tests"]
    args.output.mkdir(exist_ok=False)
    run = json.loads((work / "run.json").read_text())
    report = json.loads((work / "analysis.json").read_text())
    assert run["completed"] and run["scf_converged"] and run["returncode"] == 0
    assert digest(work / "bismuth.topology") == run["files"]["bismuth.topology"] == report["snapshot_sha256"]
    assert digest(work / "run.json") == report["run_sha256"]
    for name, expected in report["methods"].items():
        assert digest(root / name) == expected, name
    snapshot = read_snapshot(work / "bismuth.topology")
    with np.load(work / "independent-ao-moments.npz", allow_pickle=False) as cache:
        assert str(cache["snapshot_sha256"]) == report["snapshot_sha256"]
        h, xyz, diagnostics = analysis.operators(snapshot, cache["moments"])
    center = np.mean(snapshot.positions, axis=0)
    n = len(h)
    eye = np.eye(n)
    e0 = report["midpoint_hartree"]
    de = plan["energy_half_fraction_of_neutral_gap"]*report["electronic_gap_hartree"]
    dr = plan["position_half_width_angstrom_xy"]/analysis.BOHR_ANGSTROM
    z0 = xyz[0]-center[0]*eye-1j*(xyz[1]-center[1]*eye)
    rho = float(svdvals(z0)[0])
    trivial = np.diag(np.r_[np.ones(n), -np.ones(n)]).astype(complex)
    reference_sign = skew_sign(aii_skew(trivial)[0])

    def matrix(p):
        e, k, x, y = p
        mass = h-e*eye
        cross = k*(z0-((x-center[0])-1j*(y-center[1]))*eye)
        return np.block([[mass, cross], [cross.conj().T, -mass]])

    def gap(p):
        values = eigvalsh(matrix(p), subset_by_index=[n-2, n+1], driver="evr")
        return float(np.min(abs(values)))

    inputs = {name: digest(work / name) for name in ["run.json", "analysis.json", "bismuth.topology", "independent-ao-moments.npz"]}
    for index, interval in enumerate(plan["kappa_intervals_hartree_per_bohr"]):
        started = time.monotonic()
        lo, hi = np.r_[e0-de, interval[0], center[:2]-dr], np.r_[e0+de, interval[1], center[:2]+dr]
        anchor = (lo+hi)/2
        checks = []
        for point in [tuple(anchor), *sorted(set(product(*zip(lo, hi))))]:
            localizer = matrix(point)
            values = eigvalsh(localizer, driver="evd")
            exact_gap = float(np.min(abs(values)))
            pairing = float(np.max(abs(values+values[::-1])))
            middle_error = abs(gap(point)-exact_gap)
            if max(pairing, middle_error) > 1e-10:
                raise ValueError("Independent gap/pairing audit failed")
            skew, residual = aii_skew(localizer)
            z2 = (1-skew_sign(skew)*reference_sign)//2 if exact_gap > 1e-9 else None
            checks.append({"parameters": list(point), "gap_hartree": exact_gap, "z2": z2,
                           "spectral_pairing_error_hartree": pairing,
                           "middle_four_gap_error_hartree": middle_error, "skew_residual": residual})
            print(json.dumps({"box": index, "audit": checks[-1]}), flush=True)
        signs = {row["z2"] for row in checks if row["z2"] is not None}
        bounds = None
        if len(signs) > 1:
            status = "nonuniform"
        elif checks[0]["z2"] is None:
            status = "unresolved_anchor"
        else:
            bounds = cover_region(lo, hi, rho, center[:2], gap,
                                  margin=plan["numerical_gap_margin_hartree"],
                                  max_nodes=plan["maximum_subdivision_evaluations"])
            status = "resolved" if bounds["resolved"] else "unresolved_budget_or_resolution"
            if status == "resolved" and any(row["z2"] != checks[0]["z2"] for row in checks):
                raise ValueError("Covered region has inconsistent independently sampled indices")
        result = {"status": status, "lower": lo.tolist(), "upper": hi.tolist(),
                  "parameter_order": ["energy_hartree", "kappa_hartree_per_bohr", "x_bohr", "y_bohr"],
                  "anchor_z2": checks[0]["z2"],
                  "region_z2": checks[0]["z2"] if status == "resolved" else None,
                  "position_norm_bohr": rho, "checks": checks, "bound": bounds,
                  "whole_box_variation_bound_hartree": variation_bound(lo, hi, rho, center[:2])[0],
                  "diagnostics": diagnostics, "input_hashes": inputs,
                  "plan_sha256": digest(plan_path), "elapsed_seconds": time.monotonic()-started,
                  "methods": {name: digest(root / name) for name in ["analyze_material_regions.py", "localizer_region.py", "check_bloch_localizer.py"]},
                  "interpretation": "Fixed-H numerical Weyl bound, not interval arithmetic or material convergence"}
        assert inputs == {name: digest(work / name) for name in inputs}
        with (args.output / f"box-{index}.json").open("x") as stream:
            stream.write(json.dumps(result, indent=2, allow_nan=False)+"\n")
        print(json.dumps({"box": index, "status": status, "region_z2": result["region_z2"],
                          "elapsed_seconds": result["elapsed_seconds"]}), flush=True)


if __name__ == "__main__":
    main()
