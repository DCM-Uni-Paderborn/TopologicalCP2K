"""Research comparison of the stanene Wilson reference and periodic AO localizer."""

import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]


def mesh_text(size):
    import numpy as np

    cell = np.array([[4.674, 0, 0], [2.337, 4.047802737288466, 0], [0, 0, 20]])
    reciprocal = 2*np.pi*np.linalg.inv(cell).T
    lines = ["begin real_lattice"]
    lines += [" ".join(f"{x:.16g}" for x in row) for row in cell]
    lines += ["end real_lattice", "begin recip_lattice"]
    lines += [" ".join(f"{x:.16g}" for x in row) for row in reciprocal]
    lines += ["end recip_lattice", "begin kpoints", str(size*size)]
    lines += [f"{ix/size:.16g} {iy/size:.16g} 0" for iy in range(size) for ix in range(size)]
    lines += ["end kpoints", "begin nnkpts", "2"]
    for iy in range(size):
        for ix in range(size):
            source = 1+ix+size*iy
            lines.append(f"{source} {1+(ix+1)%size+size*iy} {int(ix==size-1)} 0 0")
            lines.append(f"{source} {1+ix+size*((iy+1)%size)} 0 {int(iy==size-1)} 0")
    return "\n".join(lines+["end nnkpts", ""])


def input_text(args):
    nao = {"DZVP": 26, "TZVP": 34}[args.basis]
    analysis = ""
    properties = ""
    if args.mode == "reference":
        analysis = f"""    &PRINT
      &WANNIER90
        KPOINTS_SOURCE WILSON
        SEED_NAME stanene
        SOC T
        Z2 T
        TIME_REVERSAL T
        REQUIRE_GLOBAL_GAP T
        EXCLUDE_BANDS {' '.join(str(i) for i in range(9, 2*nao+1))}
        WILSON_MESH 12 13
        WILSON_MAX_REFINEMENT 4
        WILSON_TOL 1.0E-3
      &END
    &END
"""
    elif args.mode == "bloch":
        analysis = """    &PRINT
      &WANNIER90
        KPOINTS_SOURCE NNKP
        NNKP_FILE mesh.nnkp
        SEED_NAME stanene
        SOC T
        TIME_REVERSAL T
        STATE_EXPORT T
      &END
    &END
"""
    elif args.mode == "localizer":
        properties = f"""  &PROPERTIES
    &SPECTRAL_LOCALIZER
      FORMULATION PERIODIC
      INVARIANT Z2
      SOC T
      TIME_REVERSAL T
      SOLVER {args.solver}
      MP_GRID {args.size} {args.size} 1
      MAX_AO {nao * args.size**2}
      PLANE XY
      POSITION [angstrom] {' '.join(map(str, args.position))}
      ENERGY [hartree] {' '.join(map(str, args.energy))}
      ETA [hartree] {' '.join(map(str, args.eta))}
      SPECTRAL_FLATTENING {'T' if args.flatten else 'F'}
      FLATTENING_SCALE [hartree] {args.flatten_scale}
      EPS_ELECTRONIC_GAP [hartree] {args.electronic_gap}
    &END
  &END
"""
    return f"""! Two-dimensional stanene control; not a converged materials prediction.
! Geometry from doi:10.1038/srep18879; all {nao} scalar AOs retained for SOC.
&GLOBAL
  PROJECT stanene
  PRINT_LEVEL LOW
  RUN_TYPE ENERGY
&END
&FORCE_EVAL
  METHOD QUICKSTEP
  &DFT
    BASIS_SET_FILE_NAME BASIS_MOLOPT_UZH
    POTENTIAL_FILE_NAME GTH_SOC_POTENTIALS
    &KPOINTS
      SCHEME MONKHORST-PACK {args.scf_mesh} {args.scf_mesh} 1
      FULL_GRID T
      SYMMETRY F
      WAVEFUNCTIONS COMPLEX
    &END
    &POISSON
      PERIODIC XY
      POISSON_SOLVER ANALYTIC
    &END
    &MGRID
      CUTOFF {args.cutoff}
      REL_CUTOFF 40
    &END
    &QS
      EPS_DEFAULT 1e-12
      EPS_PGF_ORB 1e-14
      EPS_PPNL 1e-14
      METHOD GPW
    &END
    &SCF
      ADDED_MOS -1
      EPS_SCF 1e-9
      MAX_SCF 150
      SCF_GUESS ATOMIC
      &DIAGONALIZATION
      &END
      &MIXING
        ALPHA 0.15
        METHOD BROYDEN_MIXING
      &END
      &PRINT
        &RESTART OFF
        &END
        &RESTART_HISTORY OFF
        &END
      &END
    &END
    &XC
      &XC_FUNCTIONAL PBE
      &END
    &END
{analysis}  &END
  &SUBSYS
    &CELL
      A 4.674 0 0
      B 2.337 4.047802737288466 0
      C 0 0 20
      PERIODIC XY
    &END
    &COORD
      SCALED
      Sn 0.3333333333333333 0.3333333333333333 0.5213
      Sn 0.6666666666666667 0.6666666666666667 0.4787
    &END
    &KIND Sn
      BASIS_SET {args.basis}-MOLOPT-GGA-GTH-q4
      POTENTIAL GTH-PBE-q4
    &END
  &END
{properties}&END
"""


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("--mode", choices=["reference", "localizer", "bloch"], default="reference")
    parser.add_argument("--size", type=int, default=2)
    parser.add_argument("--scf-mesh", type=int, default=8)
    parser.add_argument("--cutoff", type=int, default=200)
    parser.add_argument("--basis", choices=["DZVP", "TZVP"], default="DZVP")
    parser.add_argument("--position", type=float, nargs=3, default=[0.0, 0.0, 0.0])
    parser.add_argument("--solver", choices=["DENSE", "TACHO"], default="DENSE")
    parser.add_argument("--energy", type=float, nargs="+", default=[0.0])
    parser.add_argument("--eta", type=float, nargs="+", default=[0.1, 0.3, 1.0, 3.0])
    parser.add_argument("--ranks", type=int, default=2)
    parser.add_argument("--flatten", action="store_true")
    parser.add_argument("--flatten-scale", type=float, default=1.0)
    parser.add_argument("--electronic-gap", type=float, default=1e-8)
    parser.add_argument("--replay", action="store_true")
    args = parser.parse_args()
    work = args.output.resolve()
    if not args.replay:
        work.mkdir(parents=True, exist_ok=False)
        (work / "input.inp").write_text(input_text(args))
        if args.mode == "bloch":
            (work / "mesh.nnkp").write_text(mesh_text(args.size))
        command = [str(ROOT / "build-serial/bin/cp2k.ssmp")]
        if args.ranks:
            command = ["mpiexec", "-n", str(args.ranks), str(ROOT / "build-mpi/bin/cp2k.psmp")]
        command += ["-i", "input.inp", "-o", "output.out"]
        env = dict(os.environ, CP2K_DATA_DIR=str(ROOT / "data"), OPENBLAS_NUM_THREADS="1",
                   OMP_NUM_THREADS="2", OMP_STACKSIZE="64M")
        started = time.monotonic()
        with (work / "stdout.log").open("w") as stream:
            process = subprocess.run(command, cwd=work, env=env, stdout=stream, stderr=subprocess.STDOUT)
        metadata = {"command": command, "returncode": process.returncode,
                    "elapsed_seconds": time.monotonic() - started,
                    "source_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()}
        (work / "run.json").write_text(json.dumps(metadata, indent=2) + "\n")
    text = (work / "output.out").read_text()
    result = {"completed": "PROGRAM ENDED AT" in text,
              "scf_converged": "*** SCF run converged" in text,
              "diagnostics": [line.strip() for line in text.splitlines()
                              if re.search(r"(SPECTRAL_LOCALIZER|TOPOLOGY|WILSON)\|", line)]}
    (work / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2), flush=True)
    if not result["completed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
