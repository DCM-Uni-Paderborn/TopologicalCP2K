"""Check native finite flattening against exported AO matrices and explicit spectral signs."""

import json
import os
from pathlib import Path
import re
import subprocess

import numpy as np
from scipy.linalg import eigh, eigvalsh

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "build-mpi/flatten-adapter-validation"


def expanded(path):
    values = dict(re.findall(r"@SET (\S+) (.+)", path.read_text()))
    name = re.search(r"@INCLUDE (.+)", path.read_text())[1]
    text = (path.parent / name).read_text()
    for key, value in values.items():
        text = text.replace("${" + key + "}", value)
    assert "${" not in text
    return text


def run(name, text, failure=None):
    work = WORK / name
    if work.exists():
        assert (work / "input.inp").read_text() == text
        out = (work / "output.out").read_text()
        assert not failure and "PROGRAM ENDED AT" in out
        return out
    work.mkdir(parents=True, exist_ok=False)
    (work / "input.inp").write_text(text)
    env = dict(os.environ, CP2K_DATA_DIR=str(ROOT / "data"), OPENBLAS_NUM_THREADS="1",
               OMP_NUM_THREADS="2", OMP_STACKSIZE="64M")
    with (work / "stdout.log").open("w") as stream:
        proc = subprocess.run(["mpiexec", "-n", "2", str(ROOT / "build-mpi/bin/cp2k.psmp"),
                               "-i", "input.inp", "-o", "output.out"], cwd=work, env=env,
                              stdout=stream, stderr=subprocess.STDOUT)
    out = (work / "output.out").read_text()
    if failure:
        assert proc.returncode and failure in out, (name, out[-4000:])
        assert "SPECTRAL_LOCALIZER| Gap [hartree]:" not in out
    else:
        assert proc.returncode == 0 and "PROGRAM ENDED AT" in out, (name, out[-4000:])
    return out


def matrix(text, label, n):
    lines = text.splitlines()
    start = max(i for i, line in enumerate(lines) if line.strip() == label or
                (label.startswith("AO POSITION ") and line.startswith(label)))
    result = np.full((n, n), np.nan)
    columns = None
    for line in lines[start+1:]:
        words = line.split()
        if words and all(w.isdigit() for w in words):
            columns = [int(w)-1 for w in words]
        elif len(words) > 4 and words[0].isdigit() and words[1].isdigit() and words[2] == "H":
            assert columns is not None
            result[int(words[0])-1, columns] = [float(v) for v in words[4:]]
            if not np.isnan(result).any():
                return result
    raise ValueError(label)


def reference(text):
    n = int(re.search(r"Localizer dimension:\s*(\d+)", text)[1])//2
    h = matrix(text, "KOHN-SHAM MATRIX", n)
    s = matrix(text, "OVERLAP MATRIX", n)
    r = [matrix(text, "AO POSITION "+axis, n) for axis in "XY"]
    w, c = eigh(h, s)
    queries = re.findall(r"Position \[bohr\]:\s*([^\n]+)\n\s*SPECTRAL_LOCALIZER\| Energy \[hartree\]:\s*(\S+)"
                         r"\n\s*SPECTRAL_LOCALIZER\| Kappa \[hartree/bohr\]:\s*(\S+)", text)
    native = list(map(float, re.findall(r"SPECTRAL_LOCALIZER\| Gap \[hartree\]:\s*(\S+)", text)))
    assert len(queries) == len(native) == 8
    rows = []
    for (position, energy, kappa), gap in zip(queries, native):
        point = np.array(list(map(float, position.split())))
        energy, kappa = float(energy), float(kappa)
        flat = (s@c*np.sign(w-energy)[None, :])@(c.T@s)
        cross = kappa*(r[0]-point[0]*s-1j*(r[1]-point[1]*s))
        l = np.block([[flat, cross], [cross.conj().T, -flat]])
        metric = np.kron(np.eye(2), s)
        expected = min(abs(eigvalsh(l, metric)))
        assert abs(gap-expected) < 1e-9, (gap, expected)
        rows.append({"energy": energy, "position": point.tolist(), "kappa": kappa,
                     "native_gap": gap, "reference_gap": float(expected), "difference": float(abs(gap-expected))})
    assert len(re.findall(r"Flattening query \[hartree\]", text)) == 2
    return rows


def main():
    cases = [("gpw", "regtest-spectral-localizer/h2-flattened-gpw.inp"),
             ("gapw", "regtest-spectral-localizer/h2-flattened-gapw.inp"),
             ("ae", "regtest-spectral-localizer/h2-flattened-ae.inp"),
             ("mumps", "regtest-spectral-localizer-mumps/h2-flattened.inp")]
    report = {}
    for name, path in cases:
        text = expanded(ROOT / "tests/QS" / path)
        output = run(name, text)
        report[name] = reference(output)
        print(name, report[name][-1], flush=True)
    base = expanded(ROOT / "tests/QS/regtest-spectral-localizer/h2-flattened-gpw.inp")
    for name, addition, message in (
            ("closed-gap", "EPS_ELECTRONIC_GAP 100", "electronic gap unresolved"),
            ("bad-metric", "EPS_METRIC 0.1", "invalid original AO metric"),
            ("bad-scale", "FLATTENING_SCALE -1", "invalid scale or tolerance")):
        run(name, base.replace("SPECTRAL_FLATTENING T", "SPECTRAL_FLATTENING T\n      "+addition), message)
        report[name] = "rejected before reporting any localizer index"
        print(name, "PASS", flush=True)
    (WORK / "summary.json").write_text(json.dumps(report, indent=2)+"\n")


if __name__ == "__main__":
    main()
