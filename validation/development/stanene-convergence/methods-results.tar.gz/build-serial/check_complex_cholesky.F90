! Standalone reproduction of the large complex OpenBLAS Cholesky failure.
program check_complex_cholesky
  use iso_fortran_env, only: real64
  implicit none
  integer, parameter :: n = 6656
  complex(real64), allocatable :: a(:, :)
  integer :: i, info
  allocate(a(n,n))
  a = cmplx(0.0_real64, 0.0_real64, real64)
  do i=1,n
    a(i,i) = cmplx(1.0_real64, 0.0_real64, real64)
  end do
  call zpotrf('U', n, a, n, info)
  if (info /= 0) stop 1
  do i=1,n
    if (abs(a(i,i)-1.0_real64) > 1e-14_real64) stop 2
  end do
  print *, 'Complex Cholesky identity, order', n, ': PASS'
end program check_complex_cholesky
