"""Compare the sparse full-band representation against retained dense references."""

import argparse
import json
from pathlib import Path
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    cases = [("mesh3", "build-mpi/stanene-bloch-localizer/mesh3", -0.1592)]
    cases += [(f"mesh{n}", f"build-mpi/stanene-flattening/mesh{n}", -0.1592) for n in (6, 8, 9)]
    cases += [("mesh6-tzvp", "build-mpi/stanene-flattening/mesh6-tzvp", -0.16050731)]
    comparisons = []
    for label, directory, energy in cases:
        work = root / directory
        original = json.loads((work / "flattened-scan.json").read_text())
        queries = [row for row in original["queries"] if row["flatten"] == 1]
        etas = sorted({row["eta"] for row in queries})
        command = [sys.executable, str(root / "build-serial/check_sparse_bloch_localizer.py"), str(work),
                   "--library", str(root / "build-mpi/src/libcp2k.dylib"), "--energy", str(energy),
                   "--eta", *map(str, etas), "--output", "sparse-final-scan.json"]
        if label == "mesh3":
            command += ["--dense-check"]
        with (work / "sparse-final-scan.log").open("x") as output:
            subprocess.run(command, check=True, stdout=output, stderr=subprocess.STDOUT)
        sparse = json.loads((work / "sparse-final-scan.json").read_text())
        assert len(queries) == len(sparse["queries"])
        for old, new in zip(sorted(queries, key=lambda row: row["eta"]), sparse["queries"], strict=True):
            difference = abs(old["gap"] - new["gap"])
            assert difference < 1e-9, (label, old, new)
            if new["nu"] is not None:
                assert new["nu"] == old["nu"], (label, old, new)
            if "dense_nu" in new:
                assert new["dense_nu"] == old["nu"]
            comparisons.append({"case": label, "eta": new["eta"], "gap_difference": difference,
                                "reference_nu": old["nu"], "sparse_nu": new["nu"]})
        print(label, "compared", len(queries), "queries", flush=True)
    args.output.write_text(json.dumps(comparisons, indent=2) + "\n")


if __name__ == "__main__":
    main()
