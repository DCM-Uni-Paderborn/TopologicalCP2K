"""Run the new periodic quadratic inputs in isolated, retained work directories."""
import argparse
import json
import os
import re
import shutil
import subprocess
import time
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("binary", type=Path)
    parser.add_argument("work", type=Path)
    parser.add_argument("--ranks", type=int, default=1)
    parser.add_argument("--iterative", action="store_true")
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    root = Path.cwd()
    source = root / "tests/QS/regtest-quadratic-pseudospectrum"
    command = [str(args.binary.resolve())]
    if args.ranks > 1:
        command = ["mpiexec", "-n", str(args.ranks)] + command
    env = {**os.environ, "OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "2", "OMP_STACKSIZE": "64M",
           "CP2K_DATA_DIR": str(root / "data")}
    results = []
    for path in sorted(source.glob("periodic-*.inp")):
        work = args.work / path.stem
        text = path.read_text()
        if args.iterative:
            assert text.count("@SET SOLVER DENSE") == 1
            text = text.replace("@SET SOLVER DENSE", "@SET SOLVER ITERATIVE")
        if work.exists():
            assert args.resume and (work / path.name).read_text() == text
            assert (work / "periodic-common.inc").read_bytes() == (source / "periodic-common.inc").read_bytes()
            output = (work / "result.out").read_text()
            assert "PROGRAM ENDED AT" in output
            elapsed = None
        else:
            work.mkdir(parents=True, exist_ok=False)
            shutil.copy2(source / "periodic-common.inc", work)
            (work / path.name).write_text(text)
            start = time.monotonic()
            with (work / "run.log").open("w") as log:
                run = subprocess.run(command + ["-i", path.name, "-o", "result.out"], cwd=work, env=env,
                                     stdout=log, stderr=subprocess.STDOUT, timeout=300)
            elapsed = time.monotonic() - start
            output = (work / "result.out").read_text()
            if run.returncode != 0:
                raise RuntimeError(f"{path.name} failed with {run.returncode}: {output[-3000:]}")
        gap = [float(v) for v in re.findall(r"QUADRATIC_PSEUDOSPECTRUM\| Gap \[hartree\]:\s+(\S+)", output)]
        energy = [float(v) for v in re.findall(r"QUADRATIC_PSEUDOSPECTRUM\| Energy residual \[hartree\]:\s+(\S+)", output)]
        ritz = [float(v) for v in re.findall(r"QUADRATIC_PSEUDOSPECTRUM\| Eigenpair residual \[hartree\^2\]:\s+(\S+)", output)]
        assert len(gap) == len(energy) == len(ritz) == 2 and max(ritz) < 1e-10
        total, = re.findall(r"ENERGY\| Total FORCE_EVAL \( QS \) energy \[hartree\]\s+(\S+)", output)
        results.append(dict(test=path.stem, gaps=gap, energy_residuals=energy, ritz_residuals=ritz,
                            scf_energy=float(total), elapsed_seconds=elapsed, directory=str(work)))
        print(json.dumps(results[-1]), flush=True)
    (args.work / "summary.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
