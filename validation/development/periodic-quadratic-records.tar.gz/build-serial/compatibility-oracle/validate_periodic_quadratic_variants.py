"""Retain independent periodic-coordinate, mesh, and rejection checks."""
import json
import os
from pathlib import Path
import re
import subprocess

import numpy as np

root = Path.cwd()
source = root / "tests/QS/regtest-quadratic-pseudospectrum"
work = root / "build-serial/periodic-quadratic-variants-checked"
env = {**os.environ, "OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "2",
       "OMP_STACKSIZE": "64M", "CP2K_DATA_DIR": str(root / "data")}
binary = root / "build-serial/bin/cp2k.ssmp"
results = []


def run(name, wrapper, common, expected=None):
    case = work / name
    case.mkdir(parents=True, exist_ok=False)
    (case / "input.inp").write_text(wrapper)
    (case / "periodic-common.inc").write_text(common)
    with (case / "run.log").open("w") as log:
        proc = subprocess.run([str(binary), "-i", "input.inp", "-o", "result.out"],
                              cwd=case, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=300)
    output = (case / "result.out").read_text()
    if expected is not None:
        assert proc.returncode != 0 and expected in output, (name, output[-2500:])
        results.append(dict(test=name, rejected=True, message=expected))
        return None
    assert proc.returncode == 0 and "PROGRAM ENDED AT" in output, (name, output[-2500:])
    gaps = np.array([float(v) for v in re.findall(r"\| Gap \[hartree\]:\s+(\S+)", output)])
    assert gaps.size == 2 and np.isfinite(gaps).all()
    results.append(dict(test=name, gaps=gaps.tolist()))
    return gaps


common = (source / "periodic-common.inc").read_text()
base = (source / "periodic-helium.inp").read_text()
chain = (source / "periodic-chain.inp").read_text()
reference = json.loads((root / "build-serial/periodic-quadratic-smokes/summary.json").read_text())
references = {r["test"]: np.array(r["gaps"]) for r in reference}
for axis, grid in [("X", "2 1 1"), ("Z", "1 1 2")]:
    wrapper = chain.replace("@SET PERIODIC Y", f"@SET PERIODIC {axis}")
    wrapper = wrapper.replace("1 2 1", grid)
    # Rotate the query with the periodic axis: retain its original y displacement.
    query = "2.0 1.875 2.625" if axis == "X" else "1.875 2.625 2.0"
    wrapper = wrapper.replace("1.875 2.0 2.625", query)
    gaps = run(f"chain-{axis.lower()}", wrapper, common)
    assert max(abs(gaps - references["periodic-chain"])) < 1e-10

gapw = (source / "periodic-gapw.inp").read_text()
wrapper = gapw.replace("@SET PERIODIC XY", "@SET PERIODIC YZ").replace("2 1 1", "1 2 1")
wrapper = wrapper.replace("1.875 2.0 2.625", "2.625 1.875 2.0")
gaps = run("gapw-yz", wrapper, common)
assert max(abs(gaps - references["periodic-gapw"])) < 1e-10

for scheme in ["MACDONALD 2 2 1 0 0 0", "GENERAL\n        KPOINT 0 0 0 1\n        KPOINT 0.5 0 0 1\n"
               "        KPOINT 0 0.5 0 1\n        KPOINT 0.5 0.5 0 1"]:
    name = scheme.split()[0].lower()
    modified = common.replace("SCHEME MONKHORST-PACK ${SCF_GRID}", "SCHEME " + scheme)
    if name == "general":
        modified = modified.replace("        GAMMA_CENTERED T\n", "")
    gaps = run(name, base, modified)
    assert max(abs(gaps - references["periodic-helium"])) < 1e-10

gaps = run("explicit-gamma-supercell", (source / "periodic-supercell.inp").read_text(), common)
assert max(abs(gaps - references["periodic-helium"])) < 2e-9
assert max(abs(gaps - references["periodic-supercell"])) < 1e-10

cell = np.array([[4.5, 0, 0], [0.6, 4.4, 0], [0.3, 0.2, 4.6]])
position = cell.sum(axis=0) / 2
query = np.array([1.975, 2.25, 2.85])
rotation = np.array([[0.6, -0.8, 0], [0.8, 0.6, 0], [0, 0, 1]])
assert np.max(abs(rotation @ rotation.T - np.eye(3))) < 1e-15
skew_results = []
for name, rot in [("skew", np.eye(3)), ("skew-rotated", rotation)]:
    lines = [f"{label} " + " ".join(f"{v:.12f}" for v in row @ rot.T)
             for label, row in zip("ABC", cell)]
    modified = common.replace("A 4.5 0.0 0.0\n      B 0.0 4.5 0.0\n      C 0.0 0.0 4.5", "\n      ".join(lines))
    modified = modified.replace("${ELEMENT} 2.25 2.25 2.25", "${ELEMENT} " +
                                " ".join(f"{v:.12f}" for v in position @ rot.T))
    wrapper = base.replace("1.875 2.0 2.625", " ".join(f"{v:.12f}" for v in query @ rot.T))
    skew_results.append(run(name, wrapper, modified))
assert max(abs(skew_results[0] - skew_results[1])) < 1e-8

run("guard-open-grid", chain.replace("@SET GRID 1 2 1", "@SET GRID 2 2 1"), common,
    "Quadratic MP_GRID must be one in open directions.")
run("guard-finite-grid", base, common.replace("FORMULATION PERIODIC", "FORMULATION FINITE"),
    "Quadratic MP_GRID requires FORMULATION PERIODIC.")
run("guard-torus-size", base, common.replace("NSTATES 2", "NSTATES 2\n      MAX_AO 5"),
    "Quadratic full AO torus exceeds MAX_AO.")
run("guard-periodicity", chain, common.replace("PERIODIC ${PERIODIC}", "PERIODIC XYZ", 1),
    "Quadratic torus needs matching, nonempty CELL/POISSON PERIODIC.")
(work / "summary.json").write_text(json.dumps(results, indent=2) + "\n")
print(json.dumps(results, indent=2))
