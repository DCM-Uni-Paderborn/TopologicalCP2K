"""Native Hall on/off controls with identical SCF and property grids."""

import argparse
import json
import os
from pathlib import Path
import re
import subprocess


parser = argparse.ArgumentParser()
parser.add_argument('--source', type=Path, required=True)
parser.add_argument('--binary', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
root, binary, output = args.source.resolve(), args.binary.resolve(), args.output.resolve()
output.mkdir(parents=True, exist_ok=True)
template = (root / 'tests/QS/regtest-kubo-hall/hall-common.inc').read_text()
environment = os.environ.copy()
environment['CP2K_DATA_DIR'] = str(root / 'data')
results = {}


def calculate(name, setup, hall=True, scalar=False, embedded=False):
    content = template.replace('HALL_RESPONSE T', 'HALL_RESPONSE ' + ('T' if hall else 'F'))
    if scalar:
        content = content.replace('SOC T', 'SOC F')
    if embedded:
        setup['HALL_CURRENT'] = 'ATOM_EMBEDDING'
    content = '\n'.join('@SET ' + key + ' ' + value for key, value in setup.items()) + '\n' + content
    directory = output / name
    directory.mkdir(exist_ok=True)
    (directory / 'test.inp').write_text(content)
    with (directory / 'test.out').open('w') as stream:
        run = subprocess.run([str(binary), 'test.inp'], cwd=directory, env=environment,
                             stdout=stream, stderr=subprocess.STDOUT, timeout=120)
    text = (directory / 'test.out').read_text()
    if embedded:
        assert run.returncode != 0
        assert 'Kubo HALL_RESPONSE requires CURRENT_OPERATOR PROJECTED_AO or BLOCH.' in text
        return {'guard_rejected': True}
    assert run.returncode == 0 and 'PROGRAM ENDED AT' in text, name
    sigma = float(re.search(r'KUBO_TRANSPORT\| sigma_iso\[.*?\]\s+(\S+)', text)[1])
    if hall:
        maximum = float(re.search(r'KUBO_TRANSPORT\| hall_max\s+(\S+)', text)[1])
        assert maximum < 1.e-9, (name, maximum)
    else:
        maximum = None
        assert 'KUBO_TRANSPORT| hall_' not in text
    header = next(i for i, line in enumerate(text.splitlines()) if 'sigma_xx[' in line)
    tensor = [float(x) for x in text.splitlines()[header + 1].split()][5:]
    assert len(tensor) == 9
    return {'sigma_iso': sigma, 'hall_max': maximum, 'tensor': tensor}


setup = dict(HALL_QS='GPW', HALL_GRID='3 3 3', HALL_PERIODIC='XYZ',
             HALL_POISSON='PERIODIC', HALL_BLOCH='T', HALL_CURRENT='BLOCH',
             HALL_SYMMETRY='F', HALL_BACKEND='K290')
for name, scalar in [('bloch-soc3', False), ('bloch-scalar3', True)]:
    off = calculate(name + '-off', setup.copy(), hall=False, scalar=scalar)
    on = calculate(name + '-on', setup.copy(), scalar=scalar)
    error = max(abs(a - b) for a, b in zip(off['tensor'], on['tensor']))
    assert abs(off['sigma_iso'] - on['sigma_iso']) < 1.e-12
    assert error < 1.e-9
    results[name] = {'on': on, 'off': off, 'max_tensor_difference': error}
setup.update(HALL_PERIODIC='NONE', HALL_POISSON='MT', HALL_BLOCH='F',
             HALL_CURRENT='PROJECTED_AO')
off = calculate('projected-off', setup.copy(), hall=False)
on = calculate('projected-on', setup.copy())
error = max(abs(a - b) for a, b in zip(off['tensor'], on['tensor']))
assert abs(off['sigma_iso'] - on['sigma_iso']) < 1.e-12
assert error < 1.e-9
results['projected-soc'] = {'on': on, 'off': off, 'max_tensor_difference': error}
results['embedded'] = calculate('embedded-rejected', setup.copy(), embedded=True)
(output / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
