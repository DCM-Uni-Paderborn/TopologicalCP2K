"""Find a compact exact rank-deficient congruence missed by A*x probes."""
import ctypes
import json
from pathlib import Path
import sys

import numpy as np
from scipy import linalg, sparse

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from check_sparse_bloch_localizer import tacho_sign_once

root = Path(__file__).resolve().parents[2]
library = ctypes.CDLL(str(root / "build-mpi/src/libcp2k.2026.2.dylib"))
for n in (8, 12, 16, 24, 32):
    for seed in range(1, 51):
        lower = np.eye(n)
        for j in range(n):
            for i in range(j + 1, min(n, j + 5)):
                lower[i, j] = ((17 * (i + 1) + 13 * (j + 1) + seed) % 5 - 2) / 8
        blocks = np.zeros((n, n))
        for i in range(0, n - 2, 2):
            blocks[i, i + 1] = (-1.0) ** (i // 2)
        blocks -= blocks.T.copy()
        matrix = lower @ blocks @ lower.T
        sign, residual, fill = tacho_sign_once(sparse.csr_matrix(matrix), library)
        if sign is not None:
            report = dict(order=n, seed=seed, matrix=matrix.tolist(),
                          singular_values=linalg.svdvals(matrix).tolist(),
                          sign_before=sign, residual_before=residual)
            output = Path(__file__).with_name("singular-probe-fixture.json")
            with output.open("x") as handle:
                json.dump(report, handle, indent=2)
            print(json.dumps(report), flush=True)
            raise SystemExit(0)
raise SystemExit("No distinguishing fixture found")
