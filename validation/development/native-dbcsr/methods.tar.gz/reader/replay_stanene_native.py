"""Compare native DBCSR Pfaffians on unchanged complete-band stanene torus exports."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile

import numpy as np
from scipy import sparse


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("paper", type=Path)
    parser.add_argument("helper", type=Path)
    parser.add_argument("reader", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--case", default="mesh3")
    parser.add_argument("--ranks", type=int, nargs="+", default=[1, 2, 4])
    parser.add_argument("--eta", type=float, nargs="+")
    args = parser.parse_args()
    root = args.paper.resolve() / "validation/development"
    index = json.loads((root / "stanene-convergence/index.json").read_text())
    case = next(c for c in index["cases"] if c["label"] == args.case)
    if case["new_export"]:
        raise ValueError("Use a dense-referenced case from the original archive")
    archive = root / "stanene-flattening.tar.gz"
    assert digest(archive) == index["previous_reference_sha256"]
    work = args.output.resolve()
    work.mkdir(exist_ok=False)
    with tarfile.open(archive) as source:
        members = [m for m in source.getmembers() if m.name.startswith(case["directory"] + "/")]
        source.extractall(work, members=members, filter="data")
    material = work / case["directory"]
    sys.path.insert(0, str(args.helper.resolve().parent))
    from check_sparse_bloch_localizer import prepare, sparse_skew
    snapshot, frames, q, cosines, sines, diagnostics = prepare(material)
    dense_reference = json.loads((material / "flattened-scan.json").read_text())
    queries = [r for r in dense_reference["queries"] if r["flatten"] == 1]
    if args.eta:
        queries = [r for r in queries if r["eta"] in args.eta]
    shifted = snapshot.energies - case["energy"]
    assert np.min(abs(shifted)) > 1e-8
    nk, nb = shifted.shape
    assert nb == 2 * snapshot.coefficients.shape[2]
    h = sparse.block_diag([frames[k] @ np.diag(np.sign(shifted[k])) @ frames[k].conj().T
                           for k in range(nk)], format="csr")
    h = (q.conj().T @ h @ q).tocsr()
    n = h.shape[0]
    reference, _ = sparse_skew(sparse.diags(np.r_[np.ones(n), -np.ones(n)], format="csr"))
    results = []
    env = dict(os.environ, OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1")
    for label, matrix, expected in [("reference", reference, None)] + [
        (str(r["eta"]), sparse_skew(sparse.bmat([
            [h-r["eta"]*(2*sparse.eye(n)-cosines[0]-cosines[1]), r["eta"]*(sines[0]-1j*sines[1])],
            [r["eta"]*(sines[0]+1j*sines[1]), -h+r["eta"]*(2*sparse.eye(n)-cosines[0]-cosines[1])],
        ], format="csr"))[0], r["nu"]) for r in queries
    ]:
        coo = matrix.tocoo()
        binary = work / (label + ".bin")
        with binary.open("xb") as stream:
            np.array([matrix.shape[0], coo.nnz], dtype=np.int32).tofile(stream)
            np.array(coo.row+1, dtype=np.int32).tofile(stream)
            np.array(coo.col+1, dtype=np.int32).tofile(stream)
            np.array(coo.data, dtype=np.float64).tofile(stream)
        for ranks in args.ranks:
            command = [str(args.reader.resolve()), str(binary)]
            if ranks > 1:
                command = ["/opt/homebrew/bin/mpiexec", "-n", str(ranks), *command]
            print(f"BEGIN {args.case} eta={label} ranks={ranks} order={matrix.shape[0]}", flush=True)
            run = subprocess.run(command, text=True, capture_output=True, env=env, check=True)
            (work / f"{label}-mpi{ranks}.log").write_text(run.stdout + run.stderr)
            report = json.loads(next(line for line in run.stdout.splitlines() if line.startswith('{"status"')))
            report.update(case=args.case, eta=label, ranks=ranks, expected_nu=expected,
                          order=matrix.shape[0], nnz=coo.nnz)
            assert report["status"] == 0 and report["sign"] in (-1, 1), report
            assert report["residual"] <= 1e-10
            if label == "reference":
                ref_sign = report["sign"]
                if ranks == args.ranks[0]:
                    reference_sign = ref_sign
                assert ref_sign == reference_sign
            else:
                report["nu"] = (1-report["sign"]*reference_sign)//2
                assert report["nu"] == expected, report
            results.append(report)
            (work / "summary.json").write_text(json.dumps(dict(diagnostics=diagnostics, results=results), indent=2)+"\n")
            print(json.dumps(report), flush=True)
        binary.unlink()
    provenance = dict(archive_sha256=digest(archive), helper_sha256=digest(args.helper),
                      reader_sha256=digest(args.reader), driver_sha256=digest(Path(__file__)),
                      inputs={p.name: digest(p) for p in material.glob("stanene.*")})
    (work / "provenance.json").write_text(json.dumps(provenance, indent=2)+"\n")


if __name__ == "__main__":
    main()
