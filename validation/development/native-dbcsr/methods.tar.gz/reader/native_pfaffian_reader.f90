program native_pfaffian_reader
   use cp_dbcsr_api, only: dbcsr_init_lib, dbcsr_finalize_lib
   use cp_log_handling, only: cp_logger_type, cp_logger_create, cp_logger_release, &
                             cp_add_default_logger, cp_rm_default_logger
   use kinds, only: dp, int_8
   use localizer_sparse_pfaffian, only: sparse_pfaffian_sign
   use machine, only: default_output_unit
   use message_passing, only: mp_para_env_type, mp_world_init, mp_world_finalize
   implicit none
   type(mp_para_env_type), pointer :: para_env
   type(cp_logger_type), pointer :: logger
   character(4096) :: filename
   integer :: io, unit, order, count, status, sign
   integer, allocatable :: rows(:), cols(:)
   integer(int_8) :: fill, peak, start, finish, rate
   real(dp), allocatable :: values(:)
   real(dp) :: residual, elapsed

   allocate(para_env)
   call mp_world_init(para_env)
   io = -1
   if (para_env%is_source()) io = default_output_unit
   call cp_logger_create(logger, para_env=para_env, default_global_unit_nr=io, &
                         close_global_unit_on_dealloc=.false.)
   call cp_add_default_logger(logger)
   call dbcsr_init_lib(para_env%get_handle(), io)
   call get_command_argument(1, filename)
   order = 0
   count = 0
   if (para_env%is_source()) then
      open(newunit=unit, file=trim(filename), access='stream', form='unformatted', status='old')
      read(unit) order, count
      allocate(rows(count), cols(count), values(count))
      read(unit) rows, cols, values
      close(unit)
   else
      allocate(rows(0), cols(0), values(0))
   end if
   call para_env%bcast(order)
   call para_env%bcast(count)
   call system_clock(start, rate)
   call sparse_pfaffian_sign(order, rows, cols, values, 1.e-10_dp, sign, residual, fill, status, &
                             max_memory_bytes=256_int_8*1024**2, peak_memory_bytes=peak, para_env=para_env)
   call system_clock(finish)
   elapsed = real(finish-start, dp)/real(rate, dp)
   call para_env%max(elapsed)
   if (para_env%is_source()) then
      write(*, '(A,I0,A,I0,A,ES24.16,A,I0,A,I0,A,ES24.16,A)') &
         '{"status":', status, ',"sign":', sign, ',"residual":', residual, &
         ',"fill":', fill, ',"peak_numerical_bytes":', peak, ',"seconds":', elapsed, '}'
   end if
   call dbcsr_finalize_lib()
   call cp_rm_default_logger()
   call cp_logger_release(logger)
   deallocate(para_env)
   call mp_world_finalize()
end program native_pfaffian_reader
