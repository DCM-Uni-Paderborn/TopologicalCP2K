/* CP2K research extension: serial delayed skew pivots using Tacho symbolic data.
 * SPDX-License-Identifier: GPL-2.0-or-later
 */
#ifndef TACHO_SKLDL_DELAYED_RESEARCH_HPP
#define TACHO_SKLDL_DELAYED_RESEARCH_HPP

#include "Tacho_Blas_External.hpp"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <limits>
#include <map>
#include <numeric>
#include <set>
#include <stdexcept>
#include <vector>

namespace Tacho {

// This host-only prototype extends the skew path, not the general LDL solver.
class DelayedSkewResearch {
  struct Panel {
    std::vector<int> ids;
    std::vector<double> lower, pivots;
    int eliminated = 0;
  };
  struct Update {
    std::vector<int> ids;
    std::vector<double> values;
    int delayed = 0;
  };
  int order_;
  double tolerance_, threshold_;
  long long live_ = 0;
  static constexpr long long budget_ = 650000000;
  std::vector<Panel> panels_;
  std::vector<int> elimination_;
  int sign_ = 1;

  void allocate(long long count) {
    if (count < 0 || count > budget_ - live_)
      throw std::runtime_error("Delayed-skew research memory budget exceeded");
    live_ += count;
    peak_entries = std::max(peak_entries, live_);
  }
  void release(long long count) { live_ -= count; }

  static void exchange(std::vector<double> &a, std::vector<int> &ids,
                       int n, int i, int j) {
    if (i == j) return;
    for (int k = 0; k < n; ++k) std::swap(a[i + size_t(k)*n], a[j + size_t(k)*n]);
    for (int k = 0; k < n; ++k) std::swap(a[k + size_t(i)*n], a[k + size_t(j)*n]);
    std::swap(ids[i], ids[j]);
  }

public:
  long long panel_entries = 0, peak_entries = 0, delayed_passes = 0;
  int max_front = 0, front_count = 0;
  double minimum_pivot = std::numeric_limits<double>::infinity();

  DelayedSkewResearch(int n, double tolerance, double threshold = 0.01)
      : order_(n), tolerance_(tolerance), threshold_(threshold) {}

  template <typename SolverType>
  bool factor(const std::vector<std::map<int, double>> &rows, const SolverType &symbolic) {
    const auto order = symbolic.getPermutationVector();
    const auto bounds = symbolic.getSupernodes();
    const auto parents = symbolic.researchTreeParent();
    const auto ptr = symbolic.researchPanelPtr();
    const auto indices = symbolic.researchPanelIndices();
    const int ns = symbolic.getNumSupernodes();
    std::vector<int> inverse(order_);
    for (int i = 0; i < order_; ++i) inverse[order(i)] = i;
    std::vector<std::vector<int>> children(ns);
    for (int s = 0; s < ns; ++s) {
      if (parents(s) >= 0) {
        if (parents(s) <= s || parents(s) >= ns)
          throw std::runtime_error("Expected postordered Tacho supernodes");
        children[parents(s)].push_back(s);
      }
    }
    std::vector<Update> updates(ns);
    std::vector<int> local(order_, -1);
    for (int s = 0; s < ns; ++s) {
      ++front_count;
      std::set<int> eligible, border;
      for (int i = bounds(s); i < bounds(s + 1); ++i) eligible.insert(i);
      for (int child : children[s])
        for (int i = 0; i < updates[child].delayed; ++i)
          eligible.insert(updates[child].ids[i]);
      for (auto k = ptr(s); k < ptr(s + 1); ++k)
        if (!eligible.count(indices(k))) border.insert(indices(k));
      for (int child : children[s])
        for (int i : updates[child].ids)
          if (!eligible.count(i)) border.insert(i);
      if (parents(s) < 0 && !border.empty())
        throw std::runtime_error("Root contains unowned separator variables");
      Panel panel;
      panel.ids.assign(eligible.begin(), eligible.end());
      panel.ids.insert(panel.ids.end(), border.begin(), border.end());
      const int n = panel.ids.size(), initial_eligible = eligible.size();
      max_front = std::max(max_front, n);
      const long long square = static_cast<long long>(n) * n;
      allocate(square);
      std::vector<double> a(square, 0.0);
      for (int i = 0; i < n; ++i) local[panel.ids[i]] = i;
      // Own each original upper entry exactly once, at its earlier endpoint.
      for (int i = bounds(s); i < bounds(s + 1); ++i) {
        for (const auto &[column, value] : rows[order(i)]) {
          const int j = inverse[column];
          if (j <= i) continue;
          const int row = local[i], col = local[j];
          if (row < 0 || col < 0)
            throw std::runtime_error("Original entry missing from symbolic front");
          a[row + size_t(col)*n] += value;
          a[col + size_t(row)*n] -= value;
        }
      }
      for (int child : children[s]) {
        auto &update = updates[child];
        const int nu = update.ids.size();
        for (int j = 0; j < nu; ++j)
          for (int i = 0; i < nu; ++i) {
            const int row = local[update.ids[i]], col = local[update.ids[j]];
            if (row < 0 || col < 0) throw std::runtime_error("Missing child variable");
            a[row + size_t(col)*n] += update.values[i + size_t(j)*nu];
          }
        release(update.values.size());
        update = Update{};
      }
      for (int i : panel.ids) local[i] = -1;
      constexpr int block_size = 64;
      std::vector<double> original_columns(size_t(n) * block_size), first(n), second(n);
      int active = initial_eligible, k = 0, panel_start = 0;
      auto swap_pending = [&](int i, int j) {
        exchange(a, panel.ids, n, i, j);
        for (int t = 0; t < k - panel_start; ++t)
          std::swap(original_columns[i + size_t(t)*n], original_columns[j + size_t(t)*n]);
      };
      auto updated_column = [&](int column, std::vector<double> &values) {
        for (int i = k; i < n; ++i) values[i] = a[i + size_t(column)*n];
        const int pending = k - panel_start;
        if (pending)
          Blas<double>::gemv('N', n - k, pending, -1.0, original_columns.data() + k, n,
                             a.data() + column + size_t(panel_start)*n, n, 1.0, values.data() + k, 1);
        values[column] = 0.0;
      };
      auto flush = [&]() {
        const int pending = k - panel_start, remaining = n - k;
        if (pending && remaining) {
          Blas<double>::gemm('N', 'T', remaining, remaining, pending, -1.0,
                             original_columns.data() + k, n, a.data() + k + size_t(panel_start)*n, n,
                             1.0, a.data() + k + size_t(k)*n, n);
          for (int j = k; j < n; ++j) {
            a[j + size_t(j)*n] = 0.0;
            for (int i = j + 1; i < n; ++i) a[j + size_t(i)*n] = -a[i + size_t(j)*n];
          }
        }
        panel_start = k;
      };
      while (k + 1 < active) {
        updated_column(k, first);
        int partner = k + 1;
        for (int j = k + 2; j < active; ++j)
          if (std::abs(first[j]) > std::abs(first[partner])) partner = j;
        updated_column(partner, second);
        const double candidate = std::abs(first[partner]);
        double column_max = 0.0;
        for (int i = k; i < n; ++i) {
          const double x = first[i], y = second[i];
          if (!std::isfinite(x) || !std::isfinite(y)) return false;
          column_max = std::max({column_max, std::abs(x), std::abs(y)});
        }
        // Include the separator in the threshold test. A good local pivot can
        // otherwise have arbitrarily large multipliers outside this supernode.
        if (candidate <= tolerance_ || candidate < threshold_*column_max) {
          if (parents(s) < 0) {
            if (candidate <= tolerance_) return false;
            // Rook search at the root: no ancestor can accept a delayed row.
            swap_pending(k, partner);
            continue;
          }
          swap_pending(k, active - 1);
          --active;
          continue;
        }
        swap_pending(k + 1, partner);
        std::swap(first[k + 1], first[partner]);
        std::swap(second[k + 1], second[partner]);
        const double pivot = -first[k + 1];
        minimum_pivot = std::min(minimum_pivot, std::abs(pivot));
        sign_ *= pivot > 0 ? 1 : -1;
        panel.pivots.push_back(pivot);
        const int start = k + 2, remaining = n - start;
        for (int i = 0; i < remaining; ++i) {
          const double x = first[start + i], y = second[start + i];
          original_columns[start + i + size_t(k - panel_start)*n] = x;
          original_columns[start + i + size_t(k - panel_start + 1)*n] = y;
          a[start + i + size_t(k)*n] = y / pivot;
          a[start + i + size_t(k + 1)*n] = -x / pivot;
        }
        a[k + size_t(k)*n] = a[k + 1 + size_t(k + 1)*n] = 1.0;
        a[k + 1 + size_t(k)*n] = a[k + size_t(k + 1)*n] = 0.0;
        k += 2;
        if (k - panel_start == block_size) flush();
      }
      flush();
      panel.eliminated = k;
      const int rest = n - k, delayed = initial_eligible - k;
      if (parents(s) < 0 && rest) return false;
      delayed_passes += delayed;
      std::fprintf(stderr, "DELAYED front=%d total=%d eligible=%d accepted=%d delayed=%d remaining=%d\n",
                   s, n, initial_eligible, k, delayed, rest);
      for (int i = 0; i < k; ++i) elimination_.push_back(order(panel.ids[i]));
      auto &update = updates[s];
      update.ids.assign(panel.ids.begin() + k, panel.ids.end());
      update.delayed = delayed;
      if (k == 0) {
        update.values = std::move(a);
      } else if (rest == 0) {
        panel.lower = std::move(a);
        panel_entries += square;
        panels_.push_back(std::move(panel));
      } else {
        const long long lower_size = static_cast<long long>(n)*k;
        const long long update_size = static_cast<long long>(rest)*rest;
        allocate(lower_size + update_size);
        panel.lower.assign(a.begin(), a.begin() + lower_size);
        update.values.resize(update_size);
        for (int j = 0; j < rest; ++j)
          for (int i = 0; i < rest; ++i)
            update.values[i + size_t(j)*rest] = a[k + i + size_t(k + j)*n];
        release(square);
        panel_entries += lower_size;
        panels_.push_back(std::move(panel));
      }
    }
    if (elimination_.size() != size_t(order_)) return false;
    std::vector<bool> visited(order_, false);
    for (int i = 0; i < order_; ++i) {
      if (visited[i]) continue;
      visited[i] = true;
      for (int j = elimination_[i]; j != i; j = elimination_[j]) {
        visited[j] = true;
        sign_ = -sign_;
      }
    }
    return true;
  }

  int sign() const { return sign_; }

  template <typename SolverType>
  double reconstructionError(const std::vector<std::map<int, double>> &rows,
                             const SolverType &symbolic) const {
    const auto order = symbolic.getPermutationVector();
    const int n = order_;
    std::vector<int> position(n);
    for (int i = 0; i < n; ++i) position[elimination_[i]] = i;
    std::vector<double> lower(size_t(n)*n, 0.0), product(size_t(n)*n, 0.0), reconstructed(size_t(n)*n);
    for (const auto &panel : panels_) {
      const int width = panel.ids.size();
      for (int j = 0; j < panel.eliminated; ++j) {
        const int column = position[order(panel.ids[j])];
        for (int i = j; i < width; ++i) {
          const int row = position[order(panel.ids[i])];
          if (row < column) throw std::runtime_error("Factor not lower triangular");
          lower[row + size_t(column)*n] = panel.lower[i + size_t(j)*width];
        }
      }
    }
    int start = 0;
    for (const auto &panel : panels_) {
      for (int j = 0; j < panel.eliminated; j += 2)
        for (int i = 0; i < n; ++i) {
          product[i + size_t(start + j)*n] = -panel.pivots[j / 2] * lower[i + size_t(start + j + 1)*n];
          product[i + size_t(start + j + 1)*n] = panel.pivots[j / 2] * lower[i + size_t(start + j)*n];
        }
      start += panel.eliminated;
    }
    Blas<double>::gemm('N', 'T', n, n, n, 1.0, product.data(), n, lower.data(), n,
                       0.0, reconstructed.data(), n);
    double error = 0.0, norm = 0.0;
    for (int j = 0; j < n; ++j)
      for (int i = 0; i < n; ++i) {
        const auto &row = rows[elimination_[i]];
        const auto it = row.find(elimination_[j]);
        const double value = it == row.end() ? 0.0 : it->second;
        const double r = reconstructed[i + size_t(j)*n] - value;
        if (!std::isfinite(r)) return std::numeric_limits<double>::infinity();
        error += r*r;
        norm += value*value;
      }
    return std::sqrt(error / norm);
  }

  template <typename SolverType>
  std::vector<double> solve(const std::vector<double> &rhs, const SolverType &symbolic, int nrhs) const {
    const auto order = symbolic.getPermutationVector();
    std::vector<double> x(rhs.size());
    for (int p = 0; p < nrhs; ++p)
      for (int i = 0; i < order_; ++i) x[i + size_t(p)*order_] = rhs[order(i) + size_t(p)*order_];
    for (const auto &panel : panels_) {
      const int n = panel.ids.size(), k = panel.eliminated, rest = n - k;
      std::vector<double> front(size_t(k) * nrhs);
      for (int p = 0; p < nrhs; ++p)
        for (int i = 0; i < k; ++i) front[i + size_t(p)*k] = x[panel.ids[i] + size_t(p)*order_];
      Blas<double>::trsm('L', 'L', 'N', 'U', k, nrhs, 1.0, panel.lower.data(), n, front.data(), k);
      if (rest) {
        std::vector<double> changed(size_t(rest) * nrhs);
        Blas<double>::gemm('N', 'N', rest, nrhs, k, 1.0, panel.lower.data() + k, n,
                           front.data(), k, 0.0, changed.data(), rest);
        for (int p = 0; p < nrhs; ++p)
          for (int i = 0; i < rest; ++i) x[panel.ids[k + i] + size_t(p)*order_] -= changed[i + size_t(p)*rest];
      }
      for (int p = 0; p < nrhs; ++p)
        for (int i = 0; i < k; i += 2) {
          x[panel.ids[i] + size_t(p)*order_] = -front[i + 1 + size_t(p)*k] / panel.pivots[i / 2];
          x[panel.ids[i + 1] + size_t(p)*order_] = front[i + size_t(p)*k] / panel.pivots[i / 2];
        }
    }
    for (auto it = panels_.rbegin(); it != panels_.rend(); ++it) {
      const auto &panel = *it;
      const int n = panel.ids.size(), k = panel.eliminated, rest = n - k;
      std::vector<double> front(size_t(k)*nrhs), tail(size_t(rest)*nrhs);
      for (int p = 0; p < nrhs; ++p) {
        for (int i = 0; i < k; ++i) front[i + size_t(p)*k] = x[panel.ids[i] + size_t(p)*order_];
        for (int i = 0; i < rest; ++i) tail[i + size_t(p)*rest] = x[panel.ids[k + i] + size_t(p)*order_];
      }
      if (rest) Blas<double>::gemm('T', 'N', k, nrhs, rest, -1.0, panel.lower.data() + k, n,
                                  tail.data(), rest, 1.0, front.data(), k);
      Blas<double>::trsm('L', 'L', 'T', 'U', k, nrhs, 1.0, panel.lower.data(), n, front.data(), k);
      for (int p = 0; p < nrhs; ++p)
        for (int i = 0; i < k; ++i) x[panel.ids[i] + size_t(p)*order_] = front[i + size_t(p)*k];
    }
    std::vector<double> solution(rhs.size());
    for (int p = 0; p < nrhs; ++p)
      for (int i = 0; i < order_; ++i) solution[order(i) + size_t(p)*order_] = x[i + size_t(p)*order_];
    return solution;
  }
};
}
#endif
