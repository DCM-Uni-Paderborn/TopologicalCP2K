#ifndef __TACHO_CONFIG_H__
#define __TACHO_CONFIG_H__

/* Define if want to build with size_type (int)  enabled */
#define TACHO_USE_INT_INT

/* Define if want to build with size_type (size_t)  enabled */
/* #undef TACHO_USE_INT_SIZE_T */

/* Define if want to build with MKL enabled */
/* #undef TACHO_HAVE_MKL */

/* Define if want to build with LAPACK enabled */
#define TACHO_HAVE_LAPACK

/* Define if want to build with BLAS enabled */
#define TACHO_HAVE_BLAS

/* Define if want to build with CuSparse enabled */
/* #undef TACHO_HAVE_CUSPARSE */

/* Define if want to build with METIS enabled */
/* #undef TACHO_HAVE_METIS */

/* Define if want to build with CHOLMOD enabled */
/* #undef TACHO_HAVE_SUITESPARSE */

/* Define if want to build with TrilinosSS enabled */
#define TACHO_HAVE_TRILINOS_SS

/* Define if want to build with VTune enabled */
/* #undef TACHO_HAVE_VTUNE */

/* Define if want to build Matlab interface */
/* #undef TACHO_HAVE_MATLAB */

/* Define if you want to build superludist */
/* #undef TACHO_HAVE_SUPERLUDIST */

#ifndef F77_BLAS_MANGLE
# define F77_BLAS_MANGLE(name,NAME) name ## _
#endif

#endif
