/* CP2K research extension: public Tacho symbolic-analysis adapter.
 * SPDX-License-Identifier: GPL-2.0-or-later
 */
#ifndef TACHO_SKLDL_SYMBOLIC_RESEARCH_HPP
#define TACHO_SKLDL_SYMBOLIC_RESEARCH_HPP

#include <Tacho_GraphTools_Metis.hpp>
#include <Tacho_SymbolicTools.hpp>

namespace Tacho {
class SkewSymbolicResearch {
  SymbolicTools symbolic_;

public:
  template <typename PointerArray, typename IndexArray>
  SkewSymbolicResearch(int n, const PointerArray &ptr, const IndexArray &columns) {
    Graph graph(n, ptr(n), ptr, columns);
    GraphTools_Metis ordering(graph);
#if defined(TACHO_HAVE_METIS)
    ordering.setOption(METIS_OPTION_CCORDER, 1);
#endif
    ordering.reorder(0);
    symbolic_ = SymbolicTools(n, ptr, columns, ordering.PermVector(), ordering.InvPermVector());
    symbolic_.symbolicFactorize(0);
  }
  auto getPermutationVector() const { return symbolic_.PermVector(); }
  auto getSupernodes() const { return symbolic_.Supernodes(); }
  auto getNumSupernodes() const { return symbolic_.NumSupernodes(); }
  auto researchTreeParent() const { return symbolic_.SupernodesTreeParent(); }
  auto researchPanelPtr() const { return symbolic_.gidSuperPanelPtr(); }
  auto researchPanelIndices() const { return symbolic_.gidSuperPanelColIdx(); }
};
}
#endif
