"""Resource-monitored native Bi size controls on the frozen research source."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time

import bismuth_reference as reference


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("name")
    parser.add_argument("--size", type=int, required=True)
    parser.add_argument("--temperature", type=float, default=300.0)
    parser.add_argument("--restart", type=Path)
    parser.add_argument("--ranks", type=int, default=2)
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--memory-gib", type=float, default=48.0)
    parser.add_argument("--min-available-gib", type=float, default=8.0)
    parser.add_argument("--wall-seconds", type=float, default=14400)
    parser.add_argument("--energy", type=float)
    parser.add_argument("--kappa", type=float, nargs="+", default=[0.0015, 0.002, 0.003])
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    binary = root / "build-mpi/bin/cp2k.psmp"
    library = root / "build-mpi/src/libcp2k.so.2026.2"
    if not binary.is_file() or not library.is_file():
        raise RuntimeError("The frozen native build is incomplete")
    source_hash = digest(root / "source.tar.gz")
    if source_hash != "13286f5dacc4f69265d333f0dd55ac4bc8ffbfbeb2937b6231ccb681056b466e":
        raise RuntimeError("Unexpected source archive")
    options = argparse.Namespace(
        size=args.size, vacuum=20.0, temperature=args.temperature,
        cutoff=400, scf_mesh=8, basis="DZVP", trim_undercoordinated=True,
        mode="spectrum" if args.energy is None else "localizer",
        export_spectrum=True, ao_matrices=False, checkpoint=True,
        restart=args.restart, energy=None if args.energy is None else [args.energy],
        kappa=args.kappa, offset=[0.0], solver="DENSE",
    )
    expected = reference.inputs(options)
    work = root / args.name
    if work.parent != root or not args.name or args.name.startswith("."):
        raise ValueError("A simple new run-directory name is required")
    work.mkdir(exist_ok=False)
    for name, contents in expected.items():
        (work / name).write_text(contents)
    if args.restart:
        shutil.copyfile(args.restart.resolve(), work / "initial.wfn")
    for script in (Path(__file__), Path(reference.__file__)):
        shutil.copyfile(script, work / script.name)
    env = os.environ | {
        "CP2K_DATA_DIR": str(root / "source/data"),
        "OMP_NUM_THREADS": str(args.threads), "OPENBLAS_NUM_THREADS": "1",
        "OMP_STACKSIZE": "64M",
    }
    command = ["mpiexec", "--bind-to", "none", "-n", str(args.ranks),
               str(binary), "-i", "input.inp", "-o", "output.out"]
    tracked = [binary, library, root / "source/data/BASIS_MOLOPT_UZH",
               root / "source/data/GTH_SOC_POTENTIALS"]
    fingerprints = {str(path.relative_to(root)): digest(path) for path in tracked}
    link_info = subprocess.check_output(["ldd", str(library)], text=True)
    (work / "linked-libraries.txt").write_text(link_info)
    linked = {}
    for line in link_info.splitlines():
        match = re.search(r"=> (/[^ ]+)", line)
        if match:
            linked[match[1]] = digest(match[1])
    (work / "host.txt").write_text(subprocess.check_output(["uname", "-a"], text=True))
    memory = {"samples": 0, "failed_samples": 0,
              "sampled_peak_process_tree_rss_kib": 0,
              "minimum_host_available_kib": None,
              "scope": "One-second process-tree RSS sum, shared pages may be counted repeatedly"}
    interrupted = None
    start = time.monotonic()
    with (work / "stdout.log").open("x") as stream:
        process = subprocess.Popen(command, cwd=work, env=env, stdout=stream,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        (work / "process.json").write_text(json.dumps(
            {"driver_pid": os.getpid(), "child_pid": process.pid, "command": command}, indent=2))
        while process.poll() is None:
            observation = subprocess.run(["ps", "-eo", "pid=,ppid=,rss="], capture_output=True, text=True)
            if observation.returncode == 0:
                rss, _, count = reference.process_tree_rss(observation.stdout, process.pid)
                if count:
                    memory["samples"] += 1
                    memory["sampled_peak_process_tree_rss_kib"] = max(
                        rss, memory["sampled_peak_process_tree_rss_kib"])
                if rss > args.memory_gib * 1024**2:
                    interrupted = "Process-tree RSS resource limit"
            else:
                memory["failed_samples"] += 1
            available = int(re.search(r"^MemAvailable:\s+(\d+)",
                            Path("/proc/meminfo").read_text(), re.M).group(1))
            previous = memory["minimum_host_available_kib"]
            memory["minimum_host_available_kib"] = available if previous is None else min(previous, available)
            if available < args.min_available_gib * 1024**2:
                interrupted = "Host available-memory reserve"
            if time.monotonic() - start > args.wall_seconds:
                interrupted = "Wall-time resource limit"
            if shutil.disk_usage(root).free < 2 * 1024**3:
                interrupted = "Disk-space resource limit"
            if interrupted:
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
                break
            try:
                process.wait(timeout=1)
            except subprocess.TimeoutExpired:
                pass
    output = (work / "output.out").read_text() if (work / "output.out").exists() else ""
    after = {str(path.relative_to(root)): digest(path) for path in tracked}
    record = {
        "options": vars(options) | {"restart": str(args.restart)},
        "configuration": vars(args) | {"restart": str(args.restart)},
        "command": command, "elapsed_seconds": time.monotonic() - start,
        "runtime_environment": {key: env.get(key) for key in (
            "OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "OPENBLAS_CORETYPE",
            "OMP_STACKSIZE", "LD_LIBRARY_PATH", "LD_PRELOAD")},
        "returncode": process.returncode, "interrupted_reason": interrupted,
        "completed": "PROGRAM ENDED AT" in output,
        "scf_converged": "*** SCF run converged" in output,
        "memory": memory, "source_archive_sha256": source_hash,
        "source_commit": "c4fa12b8bd2001b390a92fdfcd12e56a25ba999f",
        "build_fingerprints": fingerprints, "linked_library_sha256": linked,
        "build_unchanged": fingerprints == after,
        "energy": re.findall(r"ENERGY\|.*?([-\d.]+)\s*$", output, re.M),
        "files": {path.name: digest(path) for path in sorted(work.iterdir()) if path.is_file()},
    }
    (work / "run.json").write_text(json.dumps(record, indent=2, allow_nan=False) + "\n")
    print(json.dumps({k: record[k] for k in ("completed", "scf_converged", "returncode",
                     "interrupted_reason", "elapsed_seconds", "energy", "memory")}, indent=2), flush=True)
    if not (record["completed"] and record["scf_converged"] and record["build_unchanged"]
            and process.returncode == 0 and interrupted is None):
        sys.exit(1)


if __name__ == "__main__":
    main()
