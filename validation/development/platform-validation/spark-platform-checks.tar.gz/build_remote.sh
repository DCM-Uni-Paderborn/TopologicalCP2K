#!/bin/bash
set -euo pipefail
cd "$HOME/cp2k-topology-material-20261001"
if test ! -e source; then
  mkdir source
  tar -xzf source.tar.gz -C source
fi
toolchain="$HOME/cp2k-gpu-work/cp2k-toolchain-gpu"
cmake -S source -B build-mpi -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_C_COMPILER=/usr/bin/gcc \
  -DCMAKE_CXX_COMPILER=/usr/bin/g++ \
  -DCMAKE_Fortran_COMPILER=/usr/bin/gfortran \
  -DCP2K_USE_MPI=ON -DCP2K_USE_MPI_F08=OFF \
  -DCP2K_USE_DBCSR_CONFIG=ON \
  -DDBCSR_DIR="$HOME/work/dbcsr-arm/install/lib/cmake/dbcsr" \
  -DCP2K_USE_FFTW3=ON -DCP2K_USE_LIBINT2=ON \
  -DLibint2_DIR="$toolchain/libint-v2.13.1-cp2k-lmax-5/lib/cmake/libint2" \
  -DEIGEN3_INCLUDE_DIR="$HOME/opt/eigen-5.0.1/include/eigen3" \
  -DCP2K_USE_LIBXC=ON -DLibxc_DIR="$toolchain/libxc-7.0.0/lib/cmake/Libxc" \
  -DCP2K_USE_SPGLIB=ON -DSpglib_DIR="$toolchain/spglib-2.7.0/lib/cmake/Spglib" \
  -DCP2K_BLAS_VENDOR=OpenBLAS -DCP2K_SCALAPACK_VENDOR=GENERIC \
  > configure.log 2>&1
cmake --build build-mpi --parallel 6 > build.log 2>&1
env OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1 \
  build-mpi/bin/spectral_localizer_unittest.psmp > localizer-unit.log 2>&1
env OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1 \
  build-mpi/bin/spectral_localizer_3d_unittest.psmp > localizer-3d-unit.log 2>&1
sha256sum source.tar.gz build-mpi/bin/cp2k.psmp build-mpi/src/libcp2k.so* > build-sha256.txt
