"""Preserve completed native qualification and platform controls, not builds."""

import argparse
import hashlib
import io
import json
from pathlib import Path
import platform
import re
import tarfile


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("host", choices=["spark", "terok"])
args = parser.parse_args()
root = Path(__file__).resolve().parent
qualification = json.loads((root / "native-qualification-verified/passed.json").read_text())
assert len(qualification["runs"]) == 10
assert all(row["returncode"] == 0 for row in qualification["runs"])
for name, expected in qualification["fingerprints"].items():
    assert digest(root / name) == expected, name
regtests = (root / "regtests.log").read_text()
assert "Status: OK" in regtests
counts = {kind: int(re.search(r"Number of\s+"+kind+r"\s+tests\s+(\d+)", regtests).group(1))
          for kind in ["FAILED", "WRONG", "CORRECT"]}
assert counts == {"FAILED": 0, "WRONG": 0, "CORRECT": 81}
names = ["qualify_build.py", "regtests.log", "configure.log", "build-mpi/CMakeCache.txt",
         "archive_platform_checks.py", "native-qualification-verified/passed.json",
         "native-qualification-verified/source-hashes.json"]
for row in qualification["runs"]:
    assert digest(root / row["log"]) == row["sha256"]
    names.append(row["log"])
for run in ["reference48", "reference48-armv8"]:
    if (root / run / "run.json").is_file():
        record = json.loads((root / run / "run.json").read_text())
        for filename in ["input.inp", "gamma.nnkp", "output.out", "stdout.log",
                         "host.txt", "linked-libraries.txt", "run_material.py", "bismuth_reference.py"]:
            path = root / run / filename
            if path.is_file():
                assert digest(path) == record["files"][filename]
                names.append(str(path.relative_to(root)))
        names.append(run + "/run.json")
summary = {
    "host": args.host, "architecture": platform.machine(),
    "source_archive_sha256": qualification["fingerprints"]["source.tar.gz"],
    "source_files_verified": qualification["source_files_verified"],
    "unit_executions": 10, "regression_checks": counts,
    "openblas_coretype": qualification["openblas_coretype"],
    "scope": "Single-host serial/MPI qualification. Not multi-node scaling or size convergence.",
}
if args.host == "spark":
    names.extend(["probe_blas.py", "blas-auto-verified.json", "blas-armv8-verified.json",
                  "blas-auto-verified.log", "blas-armv8-verified.log", "build_remote.sh",
                  "localizer-unit.log", "localizer-3d-unit.log", "unit-armv8.log",
                  "unit-3d-armv8.log", "geometry-registration.json", "check_geometry.py"])
    broken = json.loads((root / "blas-auto-verified.json").read_text())
    working = json.loads((root / "blas-armv8-verified.json").read_text())
    assert broken["exact_dotc"]["actual"] == [46.0, -8.0]
    assert working["exact_dotc"]["actual"] == [70.0, -8.0]
    assert working["requested_core"] == "ARMV8"
    assert max(row[key] for row in working["results"] for key in row if key.endswith("error")) < 1e-10
    summary["blas_negative_control"] = {
        "library_config": broken["config"], "expected_dotc": [70.0, -8.0],
        "automatic_sve_dotc": broken["exact_dotc"]["actual"],
        "scoped_armv8_dotc": working["exact_dotc"]["actual"],
        "global_environment_changed": False,
    }
else:
    names.extend(["build_terok.sh", "compare_platform.py", "analyze_bismuth_flakes.py",
                  "gaussian_states.py", "check_bloch_localizer.py",
                  "reference48/platform-comparison.json", "reference48/platform-matched-restart.json",
                  "reference48-restarted.json", "reference48-restarted.topology",
                  "reference48.json", "reference48.eig", "reference48/bismuth.topology"])
    comparison = json.loads((root / "reference48/platform-matched-restart.json").read_text())
    assert comparison["accepted"]
    assert digest(root / "reference48/bismuth.topology") == comparison["new_export_sha256"]
    assert digest(root / "reference48-restarted.topology") == comparison["reference_export_sha256"]
    summary["same_restart_platform_comparison"] = comparison
    summary["retained_rejected_control"] = (
        "The first comparison used an earlier SCF checkpoint and was rejected at unchanged tolerance. "
        "The accepted comparison explicitly verifies identical initial restart hashes.")
paths = [root / name for name in sorted(set(names))]
before = {str(path.relative_to(root)): digest(path) for path in paths}
manifest = json.dumps({"summary": summary, "files": before}, indent=2).encode()+b"\n"
destination = root / (args.host+"-platform-checks.tar.gz")
with tarfile.open(destination, "x:gz") as archive:
    for path in paths:
        assert path.is_file() and not path.is_symlink(), path
        archive.add(path, arcname=str(path.relative_to(root)), recursive=False)
    info = tarfile.TarInfo("manifest.json")
    info.size = len(manifest)
    archive.addfile(info, io.BytesIO(manifest))
assert before == {str(path.relative_to(root)): digest(path) for path in paths}
index = {"archive": destination.name, "sha256": digest(destination),
         "bytes": destination.stat().st_size, "summary": summary}
with destination.with_suffix(".index.json").open("x") as stream:
    stream.write(json.dumps(index, indent=2)+"\n")
print(json.dumps(index, indent=2))
