"""Record native serial/MPI unit results before the larger material calculations."""

import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile
import time


root = Path(__file__).resolve().parent
modules = ["spectral_localizer_unittest", "spectral_localizer_3d_unittest",
           "spectral_localizer_flatten_unittest", "quadratic_pseudospectrum_unittest",
           "quadratic_dbcsr_unittest"]
output = root / "native-qualification-verified"
output.mkdir(exist_ok=False)
records = []
for ranks, threads in [(1, 2), (4, 1)]:
    for name in modules:
        command = ["mpiexec", "--bind-to", "none", "-n", str(ranks),
                   str(root / "build-mpi/bin" / (name + ".psmp"))]
        env = os.environ | {"OMP_NUM_THREADS": str(threads), "OPENBLAS_NUM_THREADS": "1"}
        path = output / f"{name}-{ranks}r{threads}t.log"
        started = time.monotonic()
        with path.open("x") as stream:
            run = subprocess.run(command, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=300)
        record = {"command": command, "ranks": ranks, "threads": threads,
                  "returncode": run.returncode, "elapsed_seconds": time.monotonic()-started,
                  "log": str(path.relative_to(root)), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
        records.append(record)
        print(name, ranks, threads, run.returncode, flush=True)
        if run.returncode:
            (output / "failed.json").write_text(json.dumps(records, indent=2)+"\n")
            raise SystemExit("Native unit qualification failed")
# POSIX owner/group IDs and umasks differ between the two hosts. Compare file
# bytes, executable bits and symlink targets, not ownership or writable bits.
source_hashes = {}
with tarfile.open(root / "source.tar.gz", "r:gz") as archive:
    for member in archive:
        relative = Path(member.name)
        assert not relative.is_absolute() and ".." not in relative.parts
        path = root / "source" / relative
        if member.isfile():
            with archive.extractfile(member) as stream:
                expected = hashlib.file_digest(stream, "sha256").hexdigest()
            with path.open("rb") as stream:
                actual = hashlib.file_digest(stream, "sha256").hexdigest()
            assert expected == actual, member.name
            assert member.mode & 0o111 == path.stat().st_mode & 0o111, member.name
            source_hashes[member.name] = actual
        elif member.issym():
            assert path.is_symlink() and os.readlink(path) == member.linkname, member.name
        elif member.isdir():
            assert path.is_dir(), member.name
        else:
            raise ValueError("Unsupported archive member: " + member.name)
(output / "source-hashes.json").write_text(json.dumps(source_hashes, indent=2)+"\n")
files = [root / "build-mpi/bin/cp2k.psmp", root / "build-mpi/src/libcp2k.so.2026.2",
         root / "source.tar.gz", root / "build-mpi/CMakeCache.txt"]
hashes = {}
for path in files:
    with path.open("rb") as stream:
        hashes[str(path.relative_to(root))] = hashlib.file_digest(stream, "sha256").hexdigest()
(output / "passed.json").write_text(json.dumps({"runs": records, "fingerprints": hashes,
    "openblas_coretype": os.environ.get("OPENBLAS_CORETYPE"),
    "source_files_verified": len(source_hashes),
    "scope": "Single-host 1-rank/2-thread and 4-rank/1-thread tests, not multi-node scaling"}, indent=2)+"\n")
