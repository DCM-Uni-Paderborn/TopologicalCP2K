"""Compare complex BLAS kernels with scalar Python arithmetic, without CP2K."""

import ctypes as ct
import json
import math
import os
from pathlib import Path
import random
import sys


lib = ct.CDLL(sys.argv[1])
for name in ("openblas_get_config", "openblas_get_corename"):
    getattr(lib, name).restype = ct.c_char_p
lib.cblas_zscal.argtypes = [ct.c_int, ct.c_void_p, ct.c_void_p, ct.c_int]
lib.cblas_zdotc_sub.argtypes = [ct.c_int, ct.c_void_p, ct.c_int, ct.c_void_p, ct.c_int, ct.c_void_p]
lib.cblas_dznrm2.argtypes = [ct.c_int, ct.c_void_p, ct.c_int]
lib.cblas_dznrm2.restype = ct.c_double
lib.cblas_zgemv.argtypes = [ct.c_int, ct.c_int, ct.c_int, ct.c_int, ct.c_void_p,
                          ct.c_void_p, ct.c_int, ct.c_void_p, ct.c_int,
                          ct.c_void_p, ct.c_void_p, ct.c_int]
for name in ("cblas_zscal", "cblas_zdotc_sub", "cblas_zgemv"):
    getattr(lib, name).restype = None


def array(values):
    return (ct.c_double * (2*len(values)))(*[component for z in values for component in (z.real, z.imag)])


def unpack(values):
    return [complex(values[2*i], values[2*i+1]) for i in range(len(values)//2)]


rng = random.Random(716)
rows = []
for n in [3, 7, 15, 16, 17, 31, 32, 33, 63, 64, 65, 97, 128, 129, 256]:
    x = [complex(rng.uniform(-1, 1), rng.uniform(-1, 1)) for _ in range(n)]
    y = [complex(rng.uniform(-1, 1), rng.uniform(-1, 1)) for _ in range(n)]
    alpha = complex(0.3, -0.7)
    scaled = array(x)
    lib.cblas_zscal(n, array([alpha]), scaled, 1)
    dot = array([0j])
    lib.cblas_zdotc_sub(n, array(x), 1, array(y), 1, dot)
    norm = lib.cblas_dznrm2(n, array(x), 1)
    # Column-major matrix, formed and multiplied using scalar arithmetic.
    matrix = [complex(rng.uniform(-1, 1), rng.uniform(-1, 1)) for _ in range(n*n)]
    actual = array([0j]*n)
    lib.cblas_zgemv(102, 111, n, n, array([1+0j]), array(matrix), n,
                   array(x), 1, array([0j]), actual, 1)
    expected = [sum(matrix[j*n+i]*x[j] for j in range(n)) for i in range(n)]
    rows.append({
        "n": n,
        "zscal_error": max(abs(a-alpha*b) for a, b in zip(unpack(scaled), x)),
        "zdotc_error": abs(unpack(dot)[0] - sum(a.conjugate()*b for a, b in zip(x, y))),
        "dznrm2_error": abs(norm - math.sqrt(sum(abs(a)**2 for a in x))),
        "zgemv_error": max(abs(a-b) for a, b in zip(unpack(actual), expected)),
    })
exact_x, exact_y = [1+2j, 3+4j], [5+6j, 7+8j]
exact_result = array([0j])
lib.cblas_zdotc_sub(2, array(exact_x), 1, array(exact_y), 1, exact_result)
actual_exact = unpack(exact_result)[0]
result = {"config": lib.openblas_get_config().decode(), "core": lib.openblas_get_corename().decode(),
          "requested_core": os.environ.get("OPENBLAS_CORETYPE"), "results": rows,
          "exact_dotc": {"expected": [70.0, -8.0],
                         "actual": [actual_exact.real, actual_exact.imag]}}
Path(sys.argv[2]).write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
if abs(actual_exact-(70-8j)) > 1e-12 or any(max(row[k] for k in row if k.endswith("error")) > 1e-10 for row in rows):
    raise SystemExit(1)
