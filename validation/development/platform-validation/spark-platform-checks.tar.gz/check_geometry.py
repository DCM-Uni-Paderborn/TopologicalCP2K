"""Check which finite patches retain the same crystal registration at the center."""

import json
from pathlib import Path

import numpy as np
from scipy.spatial.distance import cdist

from bismuth_reference import geometry


def centered(size):
    _, points = geometry(size, 20.0, trim=True)
    points = np.asarray(points)
    return points - points.mean(axis=0)


reference = centered(5)
reports = {}
for size in [6, 7]:
    points = centered(size)
    distances = cdist(reference, points)
    matches = distances.argmin(axis=1)
    nearest = distances[np.arange(len(reference)), matches]
    reports[str(size)] = {
        "reference_atoms": len(reference), "atoms": len(points),
        "maximum_nearest_atom_distance_angstrom": float(nearest.max()),
        "matched_atoms": int(np.count_nonzero(nearest < 1e-10)),
        "unique_matches": len(set(matches.tolist())),
    }
assert reports["7"]["matched_atoms"] == len(reference)
assert reports["7"]["unique_matches"] == len(reference)
assert reports["6"]["matched_atoms"] == 0
Path(__file__).with_name("geometry-registration.json").write_text(json.dumps(reports, indent=2) + "\n")
print(json.dumps(reports, indent=2))
