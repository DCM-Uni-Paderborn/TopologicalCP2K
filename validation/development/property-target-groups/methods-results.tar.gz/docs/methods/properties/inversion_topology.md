# Native inversion representations and symmetry indicators

CP2K can evaluate inversion representations directly from Gaussian-basis Bloch states, including
second-variational spin-orbit coupling (SOC). The analysis does not require Z2Pack, Wannier90
execution, or maximally localized Wannier functions. The input resides in `DFT/PRINT/WANNIER90`,
alongside the native Wilson-loop analysis and overlap export.

The topological indicators described first cover the **inversion subgroup**, with spinful
time-reversal symmetry. The optional analysis described later also computes general unitary
little-group irreps, antiunitary corepresentations and band compatibility relations on explicit
reciprocal-space segments. `ATOMIC_SIGNATURES` additionally compares these band signatures with
native site-induced reference columns. It is not an automatic elementary-band-representation (EBR)
catalogue or topological classifier for all space groups.

## Input

After a converged complex-k-point GPW calculation, request:

```text
&WANNIER90
  KPOINTS_SOURCE TRIM
  SOC T
  TIME_REVERSAL T
  INVERSION_TQC T
  TQC_DIMENSION 3
  PARITY_ORIGIN 0.0 0.0 0.0
  ! EXCLUDE_BANDS must exclude all unoccupied spinor bands.
&END WANNIER90
```

`KPOINTS_SOURCE TRIM` generates the eight time-reversal-invariant momenta (TRIM) in three
dimensions. `TQC_DIMENSION 2` instead generates the four TRIM of the fractional `kz=0` plane. The
SCF potential is held fixed during the additional diagonalizations. A slab still uses a
three-dimensionally periodic cell.

`PARITY_ORIGIN` is the inversion center in fractional direct-lattice coordinates in the input cell
setting. It is not inferred from the structure. For example, inversion about `(1/2,1/2,1/2)` has
translation `(1,1,1)` relative to inversion about the origin. These operations can have different
individual parities at zone-boundary TRIM, so the setting must accompany reported symmetry data.

`INVERSION_TQC` requires an even number of occupied spinor states, selected as the lowest
consecutive bands. The number must equal the electron count. Compute excluded bands as well so that
a selected/excluded spectral separation can be checked. Converge the scalar-state basis used for
second-variational SOC. `TIME_REVERSAL T` asserts physical time-reversal symmetry of the
Hamiltonian. The code additionally checks its action on the selected subspace at each TRIM.

`PARITY T` without `INVERSION_TQC` is also available for isolated scalar or spinor subspaces. It
reports even and odd inversion-irrep multiplicities, counting individual states rather than Kramers
pairs. The `TRIM` point source implicitly enables this diagnostic. Alternatively, `NNKP` or `WILSON`
point sources can be used, provided they include the required TRIM. The `TRIM` source itself does
not define Wilson loops and cannot be combined with `WILSON_LOOP T`.

`PARITY_TOLERANCE` defaults to `1e-6`. It controls dimensionless representation residuals and the
atom-mapping distance in Bohr. `PARITY_ENERGY_TOL` defaults to `1e-6` Hartree and controls projected
symmetry/eigenvalue commutators. `WILSON_GAP_TOL` sets the minimum selected/excluded separation at
sampled points. Fractional occupations or a metallic occupied manifold do not define the insulating
classification described here.

## Metric-aware inversion representations

For a basis orbital of angular momentum $l$ on atom $a$, let

$$2\mathbf c-\mathbf r_a=\mathbf r_b+\mathbf L$$

with fractional coordinates and integer lattice translation $\mathbf L$. Inversion maps that orbital
to the same Gaussian function on atom $b$ with multiplier
$(-1)^l\exp(2\pi i\mathbf k\cdot\mathbf L)$. Atom mapping requires identical CP2K atomic kinds and a
unique inversion partner. Spatial inversion does not rotate spin. The resulting sparse
coefficient-space operator is $P$.

For selected Bloch coefficients $C$ with $C^\dagger S C=I$, the representation is

$$D(P)=C^\dagger S P C.$$

For spinors, $S$ is repeated on the two spin blocks. CP2K checks metric covariance, subspace
normalization, Hermiticity and unitarity of $D(P)$, and commutation with the selected eigenvalues.
This treats arbitrary mixtures within degenerate eigenspaces without assigning a parity to a
gauge-dependent individual vector. A native character-decomposition kernel yields the even and odd
multiplicities from $\chi(E)$ and $\chi(P)$. That kernel also accepts a complete unitary character
table supplied per group element. A separate native kernel can now generate unitary projective
character tables from little-group products and factors, as described below. The optional
`LITTLE_GROUP_IRREPS` path connects these tables to the Gaussian band coefficients; neither path
provides a general space-group EBR classification.

For spinful time reversal, the sewing matrix of $\Theta=i\sigma_y K$ is checked for unitarity, skew
symmetry and consistency with the eigenvalues. Each parity multiplicity must be even before
converting from states to Kramers pairs.

The shared `subspace_sewing` kernel constructs $B=C_t^\dagger S_t C_{\rm image}$ and checks both
frame norms, unitarity and the explicit metric residual of $C_{\rm image}-C_tB$. Inversion and its
spinful time-reversal check now use this same kernel. There is no polar projection that could
conceal a nonclosed subspace. The separate `transform_sewing_link` kernel maps connections as
$M_t=B_1 M_s B_2^\dagger$ for unitary symmetry, or $M_t=B_1\overline{M_s}B_2^\dagger$ for
antiunitary symmetry. Tests include complex degenerate gauges, a lattice phase, Kramers skew sewing
and $\Theta^2=-1$.

The kernels alone do not generate space-group spinor operations. The native property path described
below supplies those operations and reconstructs eigenframes while retaining the complete directed
link graph. It does not supply a general TQC classification or reduce the link integrals themselves.

## Independent property symmetry

`WANNIER90%SYMMETRY T` optionally reduces the scalar and second-variational SOC diagonalizations for
`KPOINTS_SOURCE NNKP`, `WILSON`, `TRIM` and `SYMMETRY`. This is independent of the SCF mesh:

```text
&WANNIER90
  KPOINTS_SOURCE WILSON
  SOC T
  SYMMETRY T
  SYMMETRY_BACKEND SPGLIB
  EPS_SYMMETRY 1.0E-6
  EPS_SYMMETRY_OPERATORS 1.0E-8
&END WANNIER90
```

Symmetry is off by default; `SYMMETRY_BACKEND` defaults to `K290` and also accepts `SPGLIB` in a
build with that library. A restricted SCF is required. The property point set need not be closed
under the crystal point group: a Wilson half-plane generally is not. The internal property-only
orbit mode relates points present in the requested set, without adding missing integration points.
The ordinary `KPOINTS%SCHEME GENERAL` closure requirement is unchanged. Repeated reciprocal images
are deduplicated for diagonalization only, not in the Wilson graph.

At each representative the scalar eigenproblem is solved once. The cell-Fourier-gauge AO action
includes the atom permutation, real-spherical basis rotation and the image phase
$\exp(-2\pi i\mathbf k_t\cdot\mathbf L_A)$. Complex conjugation is included for an antiunitary
operation. Every reconstructed scalar frame is checked against the actual target $S(\mathbf k)$ and
$H(\mathbf k)$, including both $HC-SC\varepsilon$ and its MO projection. The latter checks energy
errors that can be amplified by an ill-conditioned AO basis. There is no target Ritz diagonalization
or silent full-mesh fallback. A symmetry-broken frozen potential therefore cannot be accepted just
because the nuclear geometry has the requested symmetry.

SOC is diagonalized only at the same representatives. Since the scalar target gauge was generated
with a known AO action, its second-variational spinor coefficients can be transformed with the
corresponding conjugate SU(2) representation and physical time reversal. CP2K uses the conjugate
spin representation because its SOC assembly convention is $(\sigma_x,-\sigma_y,\sigma_z)$. The
complete reconstructed SOC eigenframe is checked for normalization and its target Hamiltonian
residual before selecting exported bands. A scalar SOC window ending inside a degenerate manifold is
rejected; increase `WANNIER90%ADDED_MOS`. The size of this window must still be converged for
physical results.

All ordered cross-k AO overlaps, band weights, Wilson directions and reciprocal boundary shifts
remain those of the full requested calculation. Thus arbitrary unitary gauges inside degenerate
spaces cancel between adjacent links; equality of individual MO coefficients or raw `.mmn` entries
is neither required nor expected. `SYMMETRY_MAX_MEMORY_MB` bounds the additional replicated scalar
and SOC orbit work arrays, not the existing distributed MO storage, full-graph SOC results or
library workspace. Independent scalar representative eigenproblems and complete SOC orbits are
distributed over k-point MPI groups. `SYMMETRY_PARALLEL_GROUP_SIZE -1` (the default) maximizes the
number of equal-sized groups without leaving a group empty; representative counts may differ between
groups. Set it to `0` to use all ranks in a single group, or to a positive divisor of the total MPI
rank count. Each group reconstructs its scalar symmetry partners and validates them using bounded
H/S operator snapshots. No dense copy of every real-space H/S image is needed on this path. One
validated frame per group and round is transferred to the full-graph MO storage; idle groups still
join the transfer sequence. This bounds temporary frame storage independently of orbit size. If H/S
snapshots cannot use the requested layout or exceed their 64 MiB per-rank budget, the previous
collective validation remains available within `SYMMETRY_MAX_MEMORY_MB`, with an explicit message.
Both paths use the same metric, AO-scaled and projected-Hamiltonian residual checks. SOC uses
bounded real-space operator snapshots on the same groups. Each group assembles the three SOC
components, diagonalizes its representatives, reconstructs their symmetry partners and checks every
target Hamiltonian. Only one complete representative spinor frame is retained at a time. The
imaginary real-space SOC convention is included before conjugating mirrored Fourier blocks. If the
operator snapshots exceed their 64 MiB per-rank budget or cannot use the requested layout, SOC
assembly reverts to the collective orbit path with an explicit message. This changes only the
distribution, not the symmetry plan or the strict physical checks; it does not rediagonalize the
full mesh. Directed link construction still uses the full MPI environment. Independent property-link
work and multi-node scaling remain separate tasks.

## Indicators and atomic signatures

Let $n^-_\kappa$ be the number of odd occupied Kramers pairs at TRIM $\kappa\in\{0,1\}^d$, where
$\mathbf k=\kappa/2$ and the first reciprocal coordinate is the fastest-changing bit. The Fu--Kane
parity index is

$$\nu=\sum_\kappa n^-_\kappa\pmod 2.$$

In three dimensions this is the strong index. The weak index $\nu_i$ is the same sum restricted to
$\kappa_i=1$. CP2K defines its inversion indicator as

$$z_4=\sum_\kappa n^-_\kappa\pmod 4.$$

The sign convention is stated explicitly because other conventions exchange $z_4=1$ and $z_4=3$. In
two dimensions only the plane $\mathbb Z_2$ index is reported. A bulk insulating gap and physical
time-reversal symmetry are prerequisites for interpreting these as insulating topological indices.

The inversion-subgroup EBR catalogue is generated analytically. One local Kramers pair of parity
$s=\pm1$ at an inversion center $\mathbf a/2$ has character $s(-1)^{\mathbf a\cdot\kappa}$. For $N$
occupied Kramers pairs, define $t_\kappa=N-2n^-_\kappa$. Its discrete Fourier coefficients are

$$d_\mathbf a=2^{-d}\sum_\kappa
  (-1)^{\mathbf a\cdot\kappa}t_\kappa.$$

The signature belongs to the **integer lattice of atomic signatures** if all $d_\mathbf a$ are
integers and $N-\sum_\mathbf a d_\mathbf a$ is even. It admits a **nonnegative atomic
decomposition** if additionally $N\geq\sum_\mathbf a|d_\mathbf a|$. These tests use exact integer
arithmetic. A nonnegative decomposition is printed as even/odd local Kramers-pair counts at each
center relative to `PARITY_ORIGIN`. A general inversion-related pair of sites has a signature
already represented by the sum of even and odd centered EBRs, so it adds no new signature generator.

An atomic-compatible signature is not a proof of trivial topology. An integer but not nonnegative
decomposition is an EBR-signature obstruction; calling it fragile requires excluding stable topology
invisible to these symmetry data. A nonzero stable indicator is likewise conditional on band
isolation and the assumed symmetries. TRIM checks alone do not demonstrate a gap throughout the
Brillouin zone. Wilson loops provide complementary information.

## Tests and implementation boundaries

`topology_symmetry_unittest` tests character decomposition including a two-dimensional irrep,
metric-aware scalar/spinor inversion, degenerate-state gauge changes, rejection of broken inversion
and time reversal, all individual inversion-center EBRs, strong and inversion-$z_4$ examples, and a
signed-only signature. It independently enumerates all rank-two atomic sums and compares the solver
for all 81 two-dimensional and 6,561 three-dimensional candidate parity signatures, including
indicator/atomic-lattice consistency.

`QS/regtest-topology/neon-tqc.inp` and `neon-tqc-plane.inp` exercise the complete SCF-to-parity/EBR
path with SOC in three and two dimensions and with different inversion origins. They are
atomic-limit regression tests, not tests of a topologically nontrivial material.

`stanene-tqc.inp` uses the fixed buckled-stanene benchmark geometry and SOC basis to obtain the
nontrivial plane parity index, complementing Wilson-loop validation. Its lightweight SCF mesh is
`4 4 1`; the parity analysis still samples all four TRIM. Unused SCF restart output is disabled. The
archived `8 8 1` benchmark remains a separate validation record, and both meshes give odd-pair
counts `(1,2,2,2)` and plane index 1. These end-to-end tests have been run with two MPI ranks and
two OpenMP threads per rank. Stanene was also checked with one rank and one thread. The existing
single-rank, multiple-thread local k-point diagonalization path can produce non-normalized states
with the tested GNU 16/OpenBLAS 0.3.33/DBCSR 2.10.0 build. The new metric checks reject those
states. Use one OpenMP thread per rank for single-rank runs until that independent threading issue
is resolved; this extension does not claim to fix it.

The inversion input path does not yet perform general space-group band classification. The optional
analysis below supplies AO little-group sewing matrices and local unitary irrep multiplicities.
Identification in a common standard setting, a complete Brillouin-zone compatibility graph, magnetic
space-group detection and a complete space-group EBR catalogue remain separate requirements.
Explicit segment restrictions are available as described below; they do not generate that global
graph.

### Shared spinor algebra

`topology_symmetry` also provides a Cartesian O(3)-to-SU(2) lift. Improper operations act on spin
through their axial rotation, `det(R)*R`; orbital inversion parity belongs to the separate AO
action. The representative spin matrices retain a double-group factor system: they must not be
treated as an ordinary single-valued representation of the spatial group.

The frame transformation composes an already supplied atom/AO/Bloch action with the spin matrix and,
for antiunitary maps, physical time reversal $i\sigma_y K$. A product validator checks unitarity and
$B_g B_h^{(*)}=\omega(g,h)B_{gh}$, with conjugation when $g$ is antiunitary. Supplied factors can
include both nonsymmorphic Bloch phases and double-group signs.

Tests cover all 48 cubic polar operations through independent Pauli-vector covariance, their
double-group multiplication factors, a non-real nonsymmorphic phase, and $\Theta^2=-1$. Together
with metric-aware sewing and endpoint-link transformations these are reusable numerical kernels.
These kernels alone do not generate space-group AO actions. The independent property reconstruction
path above combines them with the existing k-point operations. Wilson links remain explicit. The
Kubo path additionally validates current covariance; see
[spectral_localizer.md](spectral_localizer.md#property-eigenframe-symmetry).

### Little-group products and projective characters

`topology_little_group` selects operations that preserve a supplied fractional reciprocal vector
modulo a reciprocal lattice vector. Direct-space operations use the column-lattice convention
$\mathbf r\mapsto W\mathbf r+\tau$. For an operation with antiunitary flag $a_g$, the test is
$(-1)^{a_g}W_g^{-T}\mathbf k=\mathbf k\pmod{\mathbb Z^3}$. Products are computed modulo integer
translations of the supplied cell, retaining centering translations as distinct elements. The
representative of the identity must be the identity rotation with zero translation.

For $g h=T_{L_{g,h}}(gh)$, with $L_{g,h}=\tau_g+W_g\tau_h-\tau_{gh}$ an integer cell translation,
the factor is

$$\omega(g,h)=z(g,h)\exp[-2\pi i\mathbf k\cdot L_{g,h}].$$

The scalar factor has $z=1$. For spinors, $z=\pm1$ follows from the physical SU(2) lift and, for
antiunitary operations, $i\sigma_y K$. Thus physical time reversal squares to $-1$, while an
antiferromagnetic half translation additionally retains its Bloch phase. Associativity is checked
using the twisted cocycle condition

$$\omega(g,h)\omega(gh,j)
=\omega(h,j)^{*^{a_g}}\omega(g,hj).$$

Changing coset representatives multiplies the factors by a coboundary. The calculation retains this
gauge; it does not discard complex nonsymmorphic phases or force spin matrices into an ordinary
single-valued spatial representation.

For a **unitary** multiplication table and factor system, `projective_characters` generates a
complete character table directly from the twisted regular representation. Left multiplication acts
as $L_g|h\rangle=\omega(g,h)|gh\rangle$. Right multiplication $R_g|h\rangle=\omega(h,g)|hg\rangle$
commutes with every $L_h$. A deterministic Hermitian combination of the right actions splits the
regular space into invariant irreducible copies using the existing LAPACK eigensolver. Accidental
unresolved coincidences trigger another combination; failure to obtain a complete table returns an
error, never partial irreps.

Every accepted table passes invariant-subspace closure, character orthogonality, irreducible-copy
multiplicities, $\sum_\alpha d_\alpha^2=|G|$, and reconstruction of the regular character.
Characters use the exact supplied operation order and factor gauge; irrep column order has no
physical meaning. Conventional-cell centering sectors may include folded translations and are not
silently identified with primitive-cell EBR labels. Magnetic factor systems can be validated, but
their antiunitary elements must not be passed to the unitary character generator as if they were
ordinary group elements.

Analytic tests include a screw with complex Bloch phase, centering, magnetic half translations,
physical time reversal, representative/origin gauge changes, ordinary $D_2$ and its two-dimensional
spinor representation. With SPGLIB available, the default unit test covers 14 selected Hall
settings. `topology_symmetry_unittest --all-settings` covers all 530 settings of the 230 space
groups at six sampled k-points: Gamma, two half-grid boundary points, a third-grid point, a
quarter-grid point and a generic point. Scalar/spinor factors are tested for the ordinary groups and
their grey time-reversal extensions. Character generation is tested only for the unitary groups.
These are algebra tests, **not** material-level validation or a complete 230-space-group TQC
classification. The native kernels do not depend on SPGLIB; only database-driven tests do.

An independent local comparison used Spgrep 0.7.0 to decompose the regular representations for all
6,360 scalar/spinor cases with the same supplied factors. After matching irrep columns, the largest
character difference was $1.78\times10^{-14}$. Spgrep is a validation reference, not a CP2K runtime
dependency; agreement on supplied factors does not independently validate the space-group
identification or the eventual AO band representations.

### Gaussian band representations

The optional [LITTLE_GROUP_IRREPS](#CP2K_INPUT.FORCE_EVAL.DFT.PRINT.WANNIER90.LITTLE_GROUP_IRREPS)
keyword analyzes the selected bands at explicit `NNKP`, `WILSON` or `TRIM` points. It requires a
SPGLIB-enabled build, Gaussian basis sets and a three-dimensionally periodic cell. This is an
analysis of explicitly diagonalized property points, not a new SCF or Wilson-loop symmetry reduction
mode. In particular, it does not infer a topological classification from an isolated point's irreps.

The symmetry search uses the actual input cell and atomic **kind** labels. All space-group
operations are retained, including different centering translations with the same rotation. The
reduced list used for k-point quadrature is not an adequate replacement for this list. For

$$W_g r_A+\tau_g=r_{A'}+L_{A,g},$$

the scalar coefficient action has the nonzero atom block

$$U_g(\mathbf k)_{A',A}=
e^{-2\pi i\mathbf k\cdot L_{A,g}}D_A(AW_gA^{-1}).$$

Here the columns of $A$ are the cell vectors and $D_A$ uses CP2K's existing contracted Gaussian
angular rotation. Atomic representatives and Bloch phases use the same cell Fourier gauge as the
Hamiltonian. Improper rotations keep the orbital parity. SOC adds the conjugate physical SU(2)
matrix appropriate to CP2K's spin convention. `TIME_REVERSAL T` also adds the grey-group operations
and checks their antiunitary multiplication laws; it requires a restricted SCF. When antiunitary
operations preserve the property point, their local corepresentation types and multiplicities are
also classified as described below. No magnetic-space-group detection or conventional labels are
implemented.

Each operation must preserve the AO metric, the norm and span of the selected bands, and commute
with their eigenvalues. The resulting sewing matrices must obey the full projective multiplication
law, including the nonsymmorphic and spin factors. Unitary irrep multiplicities then follow from
their characters. No polar projection or gauge fitting is used to hide a failed closure check. The
selected bands must be separated from computed excluded bands; with SOC, the scalar space used for
second variation must also be converged and contain complete symmetry multiplets.
`WANNIER90/ADDED_MOS` controls that additional scalar space. Merely selecting complete final Kramers
pairs does not repair a truncated scalar multiplet.

`LITTLE_GROUP_EPS_GEOMETRY` is the atom/search tolerance in Bohr; `LITTLE_GROUP_TOLERANCE` checks
the dimensionless metric, frame and algebra residuals; `LITTLE_GROUP_ENERGY_TOL` bounds the
eigenvalue commutator in Hartree. Symmetry breaking by a poorly converged SCF, insufficient
integration grid or incomplete SOC scalar space must be investigated before relaxing these checks.
The dense reference implementation replicates its matrices on each rank.
`LITTLE_GROUP_MAX_MEMORY_MB` limits a conservative estimate of additional storage, based on the full
space-group size before little-group selection; it excludes the pre-existing SCF/export matrices and
external library workspaces. It is not a sparse/distributed band-representation solver.

`SEED_NAME.little_group` contains a block per k-point:

- `KPOINT` and `SIZES`: fractional reciprocal coordinate, unitary and antiunitary operation counts,
  number of unitary irreps, and number of selected bands.
- `OPERATION`: operation index, antiunitary flag, row-major integer direct-space rotation, and
  fractional translation.
- `PRODUCT`: two operation indices, their product index, and the complex projective factor.
- `BAND_CHARACTER`: trace of the selected-band sewing matrix for each unitary operation.
- `IRREP` and `CHARACTER`: local irrep index, dimension and multiplicity, followed by its character
  for every unitary element. Complex numbers are real/imaginary pairs.
- `COREP_SIZES`, `COREP` and `COREP_RESTRICTION`: optional antiunitary classification and unitary
  restrictions, as described below.
- `END_KPOINT`: completion of that point's validated decomposition.

Irrep indices are **local**, not Bilbao labels, and their order has no physical meaning. The
characters and explicit operations must be used when comparing different calculations. Centering
sectors in nonprimitive cells are retained, not silently relabeled as primitive-cell irreps.

`QS/regtest-little-group` checks the scalar $s+p$ and SOC $s_{1/2}+p_{1/2}+p_{3/2}$ occupied Ne
multiplets. It also tests two occupied He bands at $k_z=1/4$ with a half-cell translation, an
equivalent sheared cell, and a twofold screw. The latter operations square to a translation with
phase $-i$, rather than to the identity. A Ne/SOC screw test combines that phase with the spin minus
sign, giving $+i$. The He screw is also tested with all-electron GAPW and a UZH TZVPP basis with
contracted s/p/d functions. These small Gaussian calculations exercise the real AO-to-band path in
addition to the all-setting algebra tests; they are not material-level validation of every space
group or a complete TQC implementation. An independent comparison of the Ne Gamma-point band
characters against the analytic occupied $s+p$ representation and its spinful product gave a maximum
difference of $7.2\times10^{-15}$ in serial and two-rank MPI runs. Negative local tests cut a
degenerate scalar multiplet or truncate the scalar SOC space; both abort before accepting irrep
multiplicities. The sheared-cell smoke uses a tighter integration grid and SCF threshold, rather
than relaxing the representation tolerance.

### Antiunitary corepresentations

With `LITTLE_GROUP_IRREPS T` and `TIME_REVERSAL T`, no additional input switch is needed. At a point
whose little group contains antiunitary operations, CP2K classifies its irreducible
corepresentations. A combined operation such as inversion times time reversal may preserve a generic
k-point even when time reversal alone does not. At points without an antiunitary stabilizer, only
the unitary table is reported. The existing restricted-SCF, subspace and sewing-product checks
remain mandatory.

Write the little group as $M=H\cup aH$, with $H$ unitary and $a$ antiunitary. For a unitary irrep
$\alpha$, CP2K evaluates the Wigner test and its conjugate character in the actual factor gauge:

$$w_\alpha=\frac{1}{|H|}\sum_{b\in aH}\omega(b,b)\chi_\alpha(b^2),$$

$$\chi_\alpha^a(h)=
\frac{\omega(h,a)}{\omega(a,a^{-1}ha)}\chi_\alpha(a^{-1}ha)^*.$$

The indicator must be real and within tolerance of $+1$, $-1$ or $0$. These cases respectively
retain $\alpha$, require two copies of $\alpha$, or pair $\alpha$ with an inequivalent conjugate
irrep. Thus a type $-1$ unitary multiplicity must be even, while type $0$ partners must have equal
multiplicities. The resulting integer restriction matrix converts between unitary and
corepresentation band counts. The formulation follows the projective antiunitary conventions in the
[Spgrep formulation notes](https://spglib.github.io/spgrep/formulation/irreps/corep.html); CP2K
implements the character and integer-count operations natively.

These signs are representation types, **not topological indices** or eigenvalues of an antiunitary
operator. In particular, type $+1$ does not rule out Kramers degeneracy: a multidimensional unitary
spin irrep may already contain the required pair. Conversely, at a generic centrosymmetric SOC point
with only the identity in $H$, the type $-1$ restriction supplies the two-dimensional pair. Spin
signs and nonsymmorphic phases both enter $\omega(b,b)$ and must not be omitted.

`COREP_SIZES` gives the number of local irreducible corepresentations. Each `COREP` record contains
its index, dimension, Wigner indicator and selected-band multiplicity. `COREP_RESTRICTION` contains
the corepresentation index, unitary irrep index and multiplicity in that restriction. The complete
table includes corepresentations absent from the selected bands. No gauge-dependent trace is
assigned to an antiunitary matrix. CP2K does not rotate the eigenvectors to a canonical
corepresentation basis; it classifies the already validated physical band sewing matrices. Character
pairing, integer counts and spinor phases are not repaired when checks fail.

The native kernel accepts any validated finite antiunitary factor system. The electronic-structure
input currently generates the nonmagnetic grey extension of the spatial symmetry group; this is not
a magnetic-space-group search or support for arbitrary noncollinear magnetic ground states. Nor does
it construct a complete Brillouin-zone compatibility graph or a general EBR classification.

Analytic tests include a scalar/spinful magnetic half translation at Gamma and the zone boundary, an
already complete quaternion spin doublet, a complex $C_3$ partner pair, complex twisted gauge
changes, reordered operations/irreps, and rejection of odd or unpaired counts. The 530-Hall-setting
suite tests 5,324 antiunitary little-group tables; the remaining sampled grey-group cases have no
antiunitary stabilizer. Ne Gaussian tests exercise all three types: scalar and SOC multiplets at
Gamma, inversion/time-reversal pairs at a generic point, and paired screw sectors with SOC.

An additional local algebra sweep used SPGLIB 2.7's magnetic database in its supplied setting for
each of the 1,651 UNI numbers, at the same six k-points with scalar and spinful factors. All 19,812
factor systems passed; 14,088 had an antiunitary stabilizer and yielded a corepresentation table.
The other 5,724 cases contained only unitary little-group operations. This tests supplied magnetic
group algebra, not magnetic electronic-structure calculations or all alternative cell settings.

For the 10,154 primitive-cell tables supported by the independent Spgrep 0.7.0 comparison, Wigner
types, dimensions and unitary restrictions agreed, with a largest character residual of
$7.11\times10^{-15}$. This comparison uses the same supplied factors and therefore does not
independently validate symmetry detection. It also does not certify Spgrep's explicit antiunitary
matrices: a separate product check in that supplied-factor comparison did not pass for all such
matrices. None are imported into CP2K. The physical CP2K sewing matrices are tested directly against
the full semilinear product law before their corepresentation counts are accepted.

### Band compatibility along explicit segments

Enable
[LITTLE_GROUP_COMPATIBILITY](#CP2K_INPUT.FORCE_EVAL.DFT.PRINT.WANNIER90.LITTLE_GROUP_COMPATIBILITY)
to compare selected-band representations along the directed links of `KPOINTS_SOURCE NNKP` or
`WILSON`; `SYMMETRY` enables it automatically for its generated paths. This implies
`LITTLE_GROUP_IRREPS` and inherits its Gaussian-basis, SPGLIB, cell, subspace-isolation and
covariance requirements. `TRIM` alone is insufficient because it does not define segments. The
analysis does not change SCF weights or Wilson connection matrices.

For a link from $\mathbf k_a$ to the target image $\mathbf k_b+\mathbf G$, define
$\mathbf d=\mathbf k_b+\mathbf G-\mathbf k_a$. The segment subgroup contains the endpoint operations
satisfying $\sigma_g W_g^T\mathbf d=\mathbf d$, with $\sigma_g=+1$ for unitary and $-1$ for
antiunitary operations, exactly within the fractional-coordinate tolerance, **not** merely modulo a
reciprocal vector. Intersecting the two endpoint little groups is not enough: an operation may
preserve both endpoints but not their connecting line. Distinct centering translations are retained.
Operations at the two endpoints are matched by their antiunitary flag, rotation and translation
modulo integer direct-cell translations.

Before restricting the representations, remove their continuously varying translational phase:

$$\eta_g(\mathbf k)=e^{2\pi i\mathbf k\cdot\tau_g},\qquad
\bar\chi_g(\mathbf k)=\eta_g(\mathbf k)\chi_g(\mathbf k),$$

$$\bar\omega(g,h)=\eta_g\eta_h^{\sigma_g}\eta_{gh}^*\omega(g,h).$$

Here $\eta_h^{-1}=\eta_h^*$ because the phases have unit modulus. The complex conjugation for an
antiunitary first factor is essential; applying the ordinary unitary rephasing would generally
produce different endpoint factors even on a symmetry-preserving line.

The two endpoints must give the same rephased factor on the segment subgroup. Its projective
character table defines a common gauge for the restrictions. If $B_a$ and $B_b$ are the resulting
integer branching matrices and $m_a,m_b$ the endpoint irrep multiplicities, the necessary
compatibility condition is $B_a m_a=B_b m_b$. This compares representation subspaces, not individual
eigenvector phases or an arbitrary ordering of irrep columns.

If an endpoint has antiunitary symmetry, its complete corepresentations are restricted through their
unitary characters. If the line also has an antiunitary coset, the Wigner table of the common line
factor determines its irreducible corepresentations. Writing the endpoint and line unitary
restriction matrices as $R_a$ and $R_\ell$, the integer corepresentation branching $C_a$ satisfies
$R_\ell C_a=B_a R_a$. Pairing and doubling constraints are checked exactly, not rounded. If the line
has no antiunitary symmetry, $B_a R_a$ gives the branching into its ordinary projective irreps. Thus
endpoint Kramers partners remain paired in the connectivity data even if time reversal does not fix
the interior. For a spinful glide, opposite partners at Gamma can become same-branch pairs at a zone
boundary, enforcing a four-band connection rather than an isolated two-band pair.

For validated endpoint corepresentations, equality of line unitary counts is equivalent to equality
of line corepresentation counts. The additional output resolves the allowed endpoint-to-line
pairing; it is not an independent topological invariant or a test of the spectrum between samples.

The destination phase uses $\mathbf k_b+\mathbf G$, although the band data are stored at
$\mathbf k_b$. Discarding $\mathbf G$ would lose nonsymmorphic monodromy. For example, the two
eigenvalue branches of a twofold screw exchange after one reciprocal period along its axis. A single
branch can be isolated at a sampled point but cannot form a closed isolated band over that loop.
Integer changes of operation representatives cancel between their characters and the rephasing; they
must not change the compatibility result.

After the point records, `SEED_NAME.little_group` contains:

- `EDGE`: source point, target point and its three reciprocal-image integers. Point indices are
  one-based in the explicit NNKP or generated Wilson/SYMMETRY order; zero-length links are omitted.
- `LINE_MEMBER`: line-operation index and its operation indices at the two endpoints.
- `LINE_CHARACTER`: line irrep and operation indices, followed by real/imaginary character parts.
- `LEFT_RESTRICTION` and `RIGHT_RESTRICTION`: endpoint irrep, line irrep and branching multiplicity.
- `LINE_MULTIPLICITY`: line irrep and the two selected-band counts, including zero counts.
- `LINE_ANTIUNITARY_MEMBER`: antiunitary line-member index and its operation indices at both
  endpoints.
- `LINE_COREP`: line corepresentation index, dimension, Wigner type, and left/right selected counts.
- `LINE_COREP_RESTRICTION`: line corepresentation, unitary line irrep, and restriction multiplicity.
- `LEFT_COREP_RESTRICTION` and `RIGHT_COREP_RESTRICTION`: endpoint corepresentation index, line
  representation index and branching multiplicity. The line index refers to `LINE_COREP` when that
  table is present and to `LINE_CHARACTER` otherwise. Endpoint indices match the point's `COREP`
  records. These records are absent for an endpoint without antiunitary symmetry.
- `END_EDGE`: completion of the comparison.

The summary reports the number of checked and incompatible directed segments and the number with an
antiunitary line stabilizer. Incompatible counts are a physical diagnostic to investigate band
selection, symmetry and gap closures, not a reason to modify the characters or abort a valid algebra
calculation. Failed factors or noninteger restrictions do abort. Compatible endpoint counts do
**not** prove a gap along the segment, a trivial band structure or an atomic-band decomposition.
Only the requested or generated segments are examined; a complete equivariant connectivity
classification and EBR elementarity remain separate tasks.

Only operations, factors, characters and multiplicities are retained between points, not the AO
actions or band sewing matrices. The retained data contribute to `LITTLE_GROUP_MAX_MEMORY_MB`, in
addition to the temporary point and edge workspaces. This remains a dense replicated reference
implementation.

Analytic unit tests check scalar/spinful screw branches, reciprocal monodromy, integer changes of
coset representatives, arbitrary irrep ordering, incompatible factors and endpoint symmetries that
do not fix the line. A $C_{4v}$ doublet must split into one even and one odd mirror branch;
replacing these by two copies of one branch is incompatible despite the equal rank. The all-setting
test adds 12,720 ordinary/grey segment comparisons over all 530 Hall settings, including 4,462 with
antiunitary line stabilizers, using complete generic-site band orbits and both scalar and
physical-spin multiplicities. The database tests check algebra, not a material survey. Gaussian
regtests close a full reciprocal loop for scalar He/GPW, He/GAPW and Ne/SOC, including a shifted
target image. A separate one-band He test must report the screw monodromy obstruction. An automatic
Wilson-surface test exercises the generated links and their repeated refinement.

Antiunitary tests additionally cover shifted-origin PT pairs at generic points, time reversal
present only at endpoints, magnetic-glide Kramers planes, rejected odd endpoint multiplicities, and
the two-band obstruction versus four-band compatibility of a spinful glide/hourglass model.

## Site-induced atomic band characters

The native `topology_band_representations` module constructs atomic band characters from a supplied
site and a complete group modulo integer translations. This is the reference-data layer for the
sampled atomic-band comparison described below, not a complete EBR classifier. It preserves the
supplied cell and operation convention, including centering translations.

`atomic_band_construct` builds the site's full orbit and stabilizer. For a unitary stabilizer, the
columns correspond to local projective irreps. For an antiunitary stabilizer they instead correspond
to complete onsite corepresentations, with the required partner pairing or doubling. The site
operations are adjusted by integer translations to fix the seed exactly, so their local factor is
the spin factor at Gamma, not a k-dependent nonsymmorphic factor.

`atomic_band_characters` evaluates those same columns at arbitrary reciprocal points. Only orbit
sites fixed modulo integer translations contribute to a unitary character. Writing the orbit
representative as $t_j$, the displacement as $L_{gj}=W_gq_j+\tau_g-q_j$, and the exact site
operation as $h_j=t_j^{-1}\{I|-L_{gj}\}g t_j$, its contribution is

$$e^{-2\pi i\mathbf k\cdot L_{gj}}\,
\frac{z(g,t_j)}{z(t_j,h_j)}\,{}^{a_{t_j}}\chi(h_j).$$

Here $z$ is the spin factor and an antiunitary $t_j$ conjugates the local character. This
conjugation is needed even for a unitary target operation. The API returns original input operation
indices with every character row. `atomic_band_site_data` exposes the orbit positions and onsite
unitary characters, allowing physical orbital content to be matched without assigning arbitrary
eigenvector labels. Invalid geometry or a nonclosed group leaves an empty result.

The band rank is the number of orbit sites times the local dimension. An induced band need not be
elementary, and equivalent characters at sampled points do not establish equivalent Bloch bundles.
The separate geometry kernel below supplies Wyckoff representatives. Elementarity,
conventional-to-primitive conversion and a complete atomic-band catalogue remain separate
requirements for general TQC classification.

`topology_band_unittest --all-settings` covers all 530 Hall settings, three supplied positions, six
k points, scalar/spinful factors, and ordinary/grey groups. Every induced column is decomposed into
native little-group irreps, checked against antiunitary pairing, and restricted along six directed
connections including a reciprocal-image loop. Independently computed Cartesian s/p/d orbital
traces, multiplied by physical spin traces, match the corresponding induced sums. Analytic cases
include the eight inversion centers, nonsymmorphic screw orbits, quaternion doublets, antiunitary
orbit representatives, and interleaved operation ordering. These checks validate the induction
kernel; they neither enumerate all Wyckoff positions nor classify materials.

## Generated Wyckoff families

`topology_wyckoff:wyckoff_families` generates the site-symmetry families of the supplied group,
including unoccupied positions. It does not infer candidate sites from the actual atoms or a
coordinate grid. The input is the same complete group modulo cell translations used for site
induction, with an arbitrary cell, origin, operation ordering and integer coset convention.

For each spatial operation it solves $(W-I)x=-\tau\pmod{\mathbb Z^3}$ and retains all connected
components and nonempty intersections. Integer row-lattice saturation distinguishes, for example,
the two components of $2x=0\pmod1$. A family closure is stored as $Bx=c\pmod{\mathbb Z^r}$, with
primitive integer normals and dimension $3-r$. Integer right-hand sides are bounded using the unit
cube, not a guessed coordinate denominator. Particular solutions outside that cube are equivalent on
the torus. Space-group-equivalent families are identified only after intersection closure.

Each family has a generic representative verified against its complete stabilizer, an orbit
multiplicity, and indices of all higher-symmetry families in its closure. These specialization
relations identify maximal site groups. They do **not** prove that every induced representation from
such a site is elementary. Output has no standard Wyckoff letters. Numerical instability or an
arithmetic/work limit returns an error and no partial catalogue. Antiunitary operations act on
coordinates through their spatial parts but remain distinguished in the reported stabilizers.

`topology_wyckoff_unittest --all-settings` constructs 3,467 families over all 530 ordinary Hall
settings. Independent spinful induction checks each orbit multiplicity and site stabilizer. External
validation matches every family bijectively to SPGLIB's tabulated `Wyckoff.csv` affine coordinates
and checks 5,648 directed specialization relations. The production kernel does not read that table.
Combined arbitrary origin, nonorthogonal unimodular cell, integer coset and operation-order changes
preserve the family and specialization graph. Analytic tests also check grey groups, a magnetic half
translation, screw axes with no fixed sites, and rejected nonclosed input groups. This is a
geometric and representation validation, not a magnetic material survey or a completed EBR
classifier.

## Atomic signature matrices on explicit reciprocal sets

The native `topology_atomic_signatures` module combines generated Wyckoff families, onsite induction
and the little-group tables into one integer matrix for supplied reciprocal points. This is a
reference-construction API used by `ATOMIC_SIGNATURES`, not a classification claim.
`atomic_signature_construct` retains every site and its onsite irrep/corepresentation as a separate
column. It includes nonmaximal sites and does not merge columns that happen to coincide at the
sampled points. Equivalent sampled symmetry data need not imply equivalent band bundles.

The separate `character_class` diagnostic compares complete **unitary character functions** on every
symmetry-invariant reciprocal torus, not just the supplied points. For a direct-space integer
rotation $W$, the torus is $K_W=\{k:(W^T-I)k\in\mathbb Z^3\}$ and its character lattice is
$\mathbb Z^3/(W-I)\mathbb Z^3$. The checked Smith factorization $U(W-I)V=D$ collects the finite
Bloch terms by the keys $UL$, reduced modulo the nonzero Smith divisors; zero-divisor rows remain
free integer coordinates. Comparing these collected coefficients includes disconnected torsion
components. Coefficients are compared at the declared tolerance after scaling by band dimension; the
lattice operations themselves use checked integer arithmetic.

`ATOMIC_CHARACTER_CLASS column representative` uses the first matching global column as a local
class identifier. `ATOMIC_CHARACTER_CLASS_RESIDUAL` reports the largest accepted coefficient
residual. Identifiers are not canonical labels. Antiunitary orbit representatives conjugate local
characters as in induction, but antiunitary operators have no basis-independent trace and are not
assigned Fourier characters. Overlapping nontransitive tolerance neighborhoods are rejected. This
diagnostic does **not** merge columns, change the sampled membership problem or supply
site-intertwining/homotopy witnesses. Even complete character equality is not a proof of
Bloch-bundle equivalence, connectivity or topological triviality.

Rows are grouped by the supplied k-point order. A point with an antiunitary little-group coset uses
full corepresentation multiplicities; other points use unitary irrep multiplicities. `row_begin` and
`row_dimension` define each block, while `column_site`, `column_local` and `band_dimension` retain
provenance and physical band rank. Every column has the same rank in all blocks after multiplication
by the row dimensions. At an antiunitary point, partner pairing and doubling are checked before any
counts are accepted. These are not counts of Kramers pairs unless the particular corepresentations
actually have that dimension.

`atomic_signature_decompose` maps an incoming unitary character vector, in any row order, to the
same point-specific signature basis. Operation indices refer to the original full list used by the
constructor. The spin/Bloch gauge must be identical. Missing or duplicated operations, noninteger
character decomposition, or violated antiunitary pairing return an error and invalid counts. This
does not replace the physical AO/subspace/Hamiltonian covariance checks required when the vector
comes from electronic-structure data. The stored `little_group_data_type` contains zero
selected-band counts: it supplies tables for subduction, not observed bands.

The matrix is a potentially redundant atomic signature matrix for the **explicit reciprocal
sample**. Neither a complete set of Brillouin-zone strata nor representation elementarity is
inferred. Conventional-cell translation sectors remain explicit. The integer kernel below tests
membership and nonnegative decomposition in this supplied matrix. Elementarity and physical
topological classification remain separate tasks.

The catalogue retains a compact onsite snapshot for every site, copied from the same construction
that produced its signature columns. The Gaussian detail file includes `ATOMIC_ONSITE_SIZES` (site,
full and unitary operation counts, local column count, spinful flag), `ATOMIC_ONSITE_OPERATION`
(site, local operation, original full-group operation, antiunitary flag, row-major Cartesian
rotation and the three lattice shifts), `ATOMIC_ONSITE_SPIN` (site, operation, column-major complex
spin matrix), `ATOMIC_ONSITE_PRODUCT_ROW` (site, left operation and signed product indices for all
right operations), and `ATOMIC_ONSITE_CHARACTER` (site, local column, local unitary operation and
complex character). Complex entries are written as real/imaginary pairs. The existing
`ATOMIC_SIGNATURE_COLUMN` records connect these local columns to the induced band columns.
`ATOMIC_REFERENCE_SPIN` additionally stores the physical spin lift of every original full-group
operation in column-major order, including those without a fixed site. The lifts come from the same
factor-system construction, not a second independently signed quaternion conversion. They describe
the spin-1/2 action even for a scalar catalogue, where the spinful flag is zero and these matrices
must not be applied to scalar orbital characters; scalar onsite factors are one. The signed product
index encodes both the absolute product-operation index and the exactly real factor $+1$ or $-1$.
The writer checks this property before using the compact format; no character or factor is rounded
to reduce the output size.

The shift is defined by $W_gq+\tau_g=q+L_g$, with the seed reduced modulo the input lattice. Onsite
characters refer to the operation fixing $q$ exactly; its factor contains spin and antiunitary
phases, not the Bloch phase of the original translation representative. Induction must restore the
lattice phase $\exp(-2\pi i k\cdot L_g)$ and transport the onsite representation to the other orbit
sites. The retained spin lifts include physical time reversal for spinful antiunitary operations.
These records preserve the convention needed for independent induction and external label matching;
they do not assign canonical site/EBR labels from a dimension or a sampled band signature. No
reference database is required at runtime. The additional retained arrays are included in the memory
estimate.

`topology_atomic_unittest --all-settings` constructs matrices for all 530 Hall settings, scalar and
spinful factors, ordinary and grey groups, and six supplied reciprocal points. It checks all column
ranks, directed segment subductions and a reciprocal-image loop, plus additivity and permuted
character-row reconstruction. Analytic tests recover the sixteen inversion-center signatures and the
generic-site signature, with and without Kramers pairing. Integer changes of coset representatives
give the required Bloch rephasing, not arbitrary column changes. The regular CI sample includes
primitive, centered, screw and complex-C3 cases and remains bounded.

## Real-space induction and composite witnesses

`ATOMIC_SIGNATURES` also constructs representation-level witnesses for every generated Wyckoff
specialization. `topology_site_relations` places an image of the destination in the source's lifted
affine closure using an integer-lattice solve. Every source stabilizer must fix the entire straight
displacement, not just its endpoints modulo lattice translations. Finite site-group induction then
gives a nonnegative integer matrix $B$ such that

$$
\operatorname{BR}_{q,\alpha}
\simeq \bigoplus_\beta B_{\beta\alpha}\operatorname{BR}_{q',\beta}.
$$

The construction retains physical spin factors and onsite antiunitary corepresentations. Their
unitary character norms need not be one; the decomposition checks both the full character and
dimension. Destination orbit images retain the canonical seed's representation-column labels. This
is an induction/homotopy witness, not an identification based on equal sampled k characters.

Singleton induction relations are composed into equivalence classes, preferring maximal-site
representatives. A multi-summand relation proves that its source class is composite. Recursive
expansion terminates because every nonzero summand has strictly smaller positive band dimension. The
nonnegative expansion $E$ is checked against the independently generated signature matrix: $AE=A$,
with conserved physical dimensions. Original columns and signatures are retained.

The detailed output contains `SITE_INDUCTION_EDGE` (source/destination, operation, integer lift and
endpoint), `SITE_INDUCTION_ENTRY` (local branching multiplicities), `SITE_INDUCTION_COLUMN`
(equivalent representative and decomposition provenance), and `SITE_INDUCTION_EXPANSION` (global
nonzero expansion entries). An absent composite witness is not automatically a certificate of EBR
elementarity, complete reciprocal connectivity, or triviality of the selected Gaussian bands.

The native `topology_site_unittest --all-settings` validates 22,592 specialization edges for all 530
Hall settings in ordinary/grey scalar/spinful variants, including 180,736 reciprocal character
checks. Additional analytic cases cover lifted paths, changed cell/origin/coset conventions and
malformed witnesses. The bounded CI subset includes the spinless time-reversal exception at an $S_4$
site in space group 84. Development comparisons reproduce the space-group coverage of the exception
tables of Cano et al. and the maximal-site generator counts in all 2,120 variants against the Bilbao
EBR tables archived by Crystalline.jl. Count agreement is not a canonical-irrep-by-irrep
identification.

### Independent affine-reference matching

`wyckoff_match_affine` matches a supplied complete reference catalogue to the generated site
families. For a reference $q=q_0+D\alpha$ and a generated closure $Bq=c$ modulo integers, it checks
the rank of $D$, the exact integer identity $B W_g D=0$, the fractional offset $B(W_gq_0+\tau_g)-c$,
and the orbit multiplicity. The result must be a bijection. This compares the whole family: an
origin lying on a higher-symmetry subset cannot substitute for its free tangent space. Duplicate
entries, missing matches and malformed inputs return no partial mapping.

The reference must already use the supplied cell and origin convention. Labels remain metadata; the
routine does not infer standard letters from a generic coordinate or assign canonical onsite irrep
names. `topology_site_unittest --reference=FILE` accepts an independent numeric fixture for
development comparisons, without using the SPGLIB operation database in this reference path. The
fixture starts with a group count. Each group supplies its identifier, full operation count and
family count, then rotations/translations and label/multiplicity/origin/direction records.
Three-by-three matrices use Fortran column order. No reference table is installed at runtime.

The independently archived generators and affine positions for all 230 space groups give 1,731
families, or 6,924 matches across ordinary/grey scalar/spinful variants. Combined cell shear, origin
shifts, integer coset changes and reversed operation order preserve the named specialization graphs.
The dimensions of all 10,398 unreduced maximal-site generators match the reference EBR dimension
multisets **separately at every Wyckoff position**, with the conventional-cell centering factor
removed for comparison. This is stronger than matching total counts, but does not identify distinct
equal-dimensional onsite irreps or establish full EBR character equivalence.

## Exact integer decomposition of supplied signatures

`topology_integer_lattice` accepts integer matrices independently of their representation-theory
origin. `integer_lattice_factor` constructs the Smith form $UAV=D$ using checked 64-bit Euclidean
row and column operations. The transformations are unimodular, diagonal entries are positive in
divisibility order, and the full certificate is multiplied out before acceptance. Rectangular and
rank-deficient matrices are allowed. `integer_lattice_certificate` exposes the transforms, diagonal
and rank without mutable access to the factorization.

For a signature vector $b$, `integer_lattice_solve` tests whether $Ub$ is divisible by the nonzero
diagonal entries and zero in the remaining rows. It returns a signed integer witness $x$ and
verifies $Ax=b$. Nonmembership is an exact result only when the status is zero. Coefficient growth
or a work limit is an **unresolved** result, never a topological obstruction. No floating-point rank
threshold, linear-program relaxation or coefficient rounding is used for these decisions.

`nonnegative_integer_solve` separately tests $Ax=b$ with $x\geq0$ for nonnegative $A,b$. It searches
bounded integer coefficients, using componentwise bounds, suffix gcds and zero-support pruning. Zero
columns can be assigned zero. A returned witness is checked again. Only a completed search can prove
that no nonnegative decomposition exists; exhaustion of the caller's mandatory node budget returns
status 1, explicitly undecided. The search can be exponential and is not a large-catalogue
integer-optimization backend.

Both decisions refer only to the supplied signature matrix. Signed membership does not imply
nonnegative membership, and nonnegative membership does not by itself establish a topologically
trivial Bloch bundle. In particular, Smith divisors of rows at an incomplete reciprocal sample are
not automatically the space group's symmetry-indicator group. Complete reciprocal strata,
compatibility constraints, band isolation, and the interpretation/equivalence of atomic columns
remain distinct requirements. The integer kernel is independent of physical band validation; the
Gaussian integration below supplies the latter separately.

`topology_integer_unittest` independently checks Smith invariants against gcds of every minor and
unimodularity for 384 small matrices of ranks zero through four. All 6,642 two-pair inversion
patterns at four/eight TRIM agree with the analytic Fourier criterion, including signed-only cases.
A further 18,225 small nonnegative systems agree with exhaustive coefficient enumeration. Invalid
input, arithmetic growth and exhausted budgets are tested separately. `topology_atomic_unittest`
additionally factors the actual generated catalogues and reconstructs signed targets, every atomic
column, and a three-column sum; the all-setting run covers 2,120 matrices and 33,199 nonnegative
witnesses.

## Comparing actual Gaussian-band signatures

### Joint compatibility lattice

With compatibility analysis enabled, `ATOMIC_SIGNATURES` also assembles all supplied directed-edge
branching equations into one integer matrix $C$. Endpoint coordinates are the same unitary-irrep or
full-corepresentation multiplicities as in the atomic matrix $A$. Corepresentation restrictions are
included before assembling the unitary line equations; valid line corepresentation counts are
uniquely determined by their unitary restrictions. A self-edge with a reciprocal shift contributes
both endpoint restrictions to the **same** columns, retaining screw/glide monodromy. Sign-equivalent
duplicate rows are removed, not rationally independent integer constraints.

`topology_star_transport` additionally identifies symmetry-related supplied points. For an operation
$s$ taking $k_a$ to $k_b+G$, let $h_a=s^{-1}hs$ and $L=\tau_h+W_h\tau_s-\tau_s-W_s\tau_{h_a}$. The
transported unitary character is

$$
\chi_b(h)=\frac{z(h,s)}{z(s,h_a)}e^{-2\pi i k_b\cdot L}
\begin{cases}\chi_a(h_a),&s\text{ unitary},\\
\chi_a(h_a)^*,&s\text{ antiunitary}.\end{cases}
$$

Here $z$ is the Gamma spin factor, including physical time-reversal squaring. The implementation
checks conjugation of the complete product table and the twisted factor law, not only character
inner products. The resulting unitary-irrep map must be a permutation. Antiunitary corepresentation
coordinates are reconstructed from their unitary restrictions and must also map bijectively,
preserving dimensions. Independently changed endpoint lattice representatives retain their Bloch
phases. A spanning set of star equations $M_s n_a-n_b=0$ joins the directed-edge constraints in $C$;
reciprocal winding of an edge is still a separate constraint.

`topology_compatibility_lattice` computes a saturated integer kernel $K$ of $C$ using the unimodular
right transform of its Smith form. It then solves $A=KY$ exactly and factors $Y$:

$$
\mathcal B_G=\ker_{\mathbb Z} C,\qquad
\mathcal X_G=\mathcal B_G/\operatorname{im}_{\mathbb Z} A
            \simeq \mathbb Z^{q-r}\oplus\bigoplus_{i=1}^{r}\mathbb Z_{d_i}.
$$

Here $G$ denotes the supplied graph, $q$ its compatible signature rank and $r$ the rank of $Y$. A
divisor $d_i=1$ is trivial; stored zeros denote free integer factors. For a compatible target
$b=Kz$, the Smith row transform $U_Yz$ supplies residues modulo $d_i$ and signed free coordinates.
All coordinates vanish exactly when $b$ has a **signed** atomic decomposition. An incompatible
target has no quotient class. This separates compatibility failure from a nonzero compatible class;
neither arithmetic nor memory exhaustion is interpreted as either result.

The detailed output adds `COMPATIBILITY_CONSTRAINT`, `COMPATIBILITY_KERNEL`,
`COMPATIBILITY_ATOMIC_COORDINATE`, `COMPATIBILITY_QUOTIENT_MAP`, `COMPATIBILITY_QUOTIENT_FACTOR`
and, for compatible targets, `COMPATIBILITY_QUOTIENT_CLASS` records. Indices refer to the
atomic-signature row basis printed in the same file. Matrix records contain nonzero entries; sizes
are explicit. They permit independent checks of $CK=0$, $KY=A$, kernel saturation and quotient
residues. A zero constraint row represents a graph with no nonzero equations. `COMPATIBILITY_STAR`
records give source/destination point, the original full-group operation index, and the three
reciprocal-shift integers. `Sampled star identifications` counts these spanning links.

This is **not automatically the full space-group symmetry-indicator group**. Star-arm
identifications between the supplied points are included, but missing points or global compatibility
constraints can still leave free factors. Even a finite quotient does not certify missing
reciprocal-stratum coverage, EBR completeness or BZ-wide band isolation. No free factor is labelled
a physical topological invariant. Signed/nonnegative atomic membership and the physical validation
described below remain separate.

Integer tests recover the inversion quotients $\mathbb Z_2$ and $\mathbb Z_2^3\times\mathbb Z_4$
from explicit four/eight-point parity columns and equal-rank constraints, and compare every two-pair
signature with direct signed membership. Native graph tests check all induced atomic columns,
reversed edges, reciprocal winding, antiunitary restrictions, incompatible reference columns and
memory limits. Gaussian tests additionally check GPW/GAPW, SOC, sheared cells, partial graphs with
free factors and the incompatible one-band screw loop. Star tests check inverse maps, all
alternative operations between each retained pair, independently induced atomic columns, a complex
threefold screw and changed endpoint representatives. Invalid factors and numerically unsafe phases
must fail without returning a coordinate map. The full development sweep reproduces both compatible
ranks and finite invariant factors in all 2,120 Hall-setting/symmetry combinations when compared
independently with Tables I-IV and IX-XII of
[Po, Vishwanath and Watanabe (2017)](https://arxiv.org/abs/1703.00911). This benchmark does not
prove completeness of an arbitrary supplied graph or elementary-band labels.

### Gaussian integration

Enable `ATOMIC_SIGNATURES T` in `DFT/PRINT/WANNIER90` with explicit `NNKP`, `WILSON` or `TRIM`
points, or automatic `SYMMETRY` sampling. It implies `LITTLE_GROUP_IRREPS` and requires SPGLIB. For
example, add to an existing NNKP setup with a selected, isolated band set:

```text
ATOMIC_SIGNATURES T
ATOMIC_SIGNATURE_MAX_NODES 1000000
LITTLE_GROUP_COMPATIBILITY T
```

The compatibility option is recommended for the NNKP/Wilson neighbour segments and adds the joint
lattice above; it is not required for a TRIM-only signature. All existing physical guards remain:
the cell must be periodic in all three directions; the selected/excluded bands must have a gap at
each sampled point; metric covariance, selected-subspace closure, eigenvalue commutation and sewing
products must pass. SOC uses the existing post-SCF GTH treatment. Time reversal requires a
restricted SCF. The selected set need not be an occupied prefix, but an insulating ground-state
classification requires the full occupied space and separately established BZ-wide isolation.

The code generates all site-induced columns in the actual input-cell setting and matches the
validated Gaussian little groups bijectively to the reference operations. Operation ordering and
local irrep ordering do not define identity. When a reference operation differs by an integer
translation $L$, its band character is rephased by $e^{-2\pi i k\cdot L}$. The full product and
factor tables, including antiunitary conjugation, must transform consistently before decomposition.
Different cells, mismatched operations, inconsistent spin factors or different band ranks are
rejected. This is an algebraic convention conversion, not a fitted gauge rotation.

The summary reports two `Sampled ... atomic membership` values: `1` means yes, `0` means a proved
negative decision for the supplied matrix, and `-1` means unresolved. `ATOMIC_SIGNATURE_MAX_NODES`
defaults to one million; zero skips the nonnegative search. Exact signed nonmembership also proves
nonnegative nonmembership without a search. Arithmetic-growth limits can leave signed membership
unresolved; a verified nonnegative witness still proves signed membership. Invalid data or a failed
witness check abort rather than reporting a physical conclusion. Reference construction and solver
matrices use the estimated `LITTLE_GROUP_MAX_MEMORY_MB` budget; the geometric site search and
external-library workspace are excluded from this estimate. The integer search and factorization are
replicated on each MPI rank, not distributed sparse solvers.

`SEED_NAME.little_group` appends the reference cell and operations, character/corepresentation rows,
integer target, full atomic matrix, column site/local-representation provenance, and available
signed/nonnegative witnesses. Local reference labels are separate from the earlier Gaussian-band
labels; the recorded characters specify their meaning. An affirmative result is not proof of
Bloch-bundle triviality; a negative result is not by itself a choice between a symmetry-enforced gap
obstruction and an isolated topological band set.

Gaussian regressions exercise GPW, GAPW, post-SCF SOC, a sheared cell, centering, screw phases,
generic-point antiunitary pairing and a refined Wilson mesh. The one-band screw-monodromy example
has no signed atomic signature; its two-band reference is atomically compatible. A zero-node TRIM
case proves signed membership while leaving nonnegative membership unresolved. No existing physical
reference values are changed. Native all-setting tests additionally change integer operation
representatives and reorder operations and irrep columns, regenerating the factors independently;
the band signature must remain invariant. Corrupted factors or missing operation matches are
rejected before any integer decision.

## Automatic reciprocal geometry

The native `topology_reciprocal` module supplies the geometric sampling backend for
`KPOINTS_SOURCE SYMMETRY`. In fractional coordinates an operation with direct rotation $W$ and
antiunitary flag $a$ acts on reciprocal points through $(-1)^a W^{-T}$. The code enumerates the
connected fixed tori and their nonempty intersections, using the existing saturated affine-torus
solver. It identifies symmetry-equivalent closures, retains a generic point of each, and restores
the full original stabilizer. Identical geometric actions are collapsed only during geometric
enumeration. In particular, centering cosets, nonsymmorphic translations and an antiunitary PT
stabilizer must remain in the little-group data used to construct representations.

Every higher-symmetry specialization has an explicit group operation and integer reciprocal shift
embedding its seed into the parent closure. A checked Smith factorization also supplies a primitive
integer basis of each closure's tangent lattice. These are reciprocal torus cycles, not merely
floating-point nullspace vectors. `reciprocal_sampling` returns representative points and directed
incidence/cycle edges, retaining destination shifts for Bloch-phase/monodromy calculations. Child
images are evaluated as explicit additional points, so this interface does not assume a convention
for transporting local irrep labels between star arms.

The native Gaussian analysis can be enabled in `DFT/PRINT/WANNIER90`, for example for an isolated
two-band occupied prefix with a third computed band:

```text
KPOINTS_SOURCE SYMMETRY
EXCLUDE_BANDS 3
TIME_REVERSAL T
LITTLE_GROUP_PATH_POINTS 3
LITTLE_GROUP_MAX_POINTS 4096
REQUIRE_GLOBAL_GAP T
ATOMIC_SIGNATURES T
```

The band indices are illustrative: select the actual occupied space and compute excluded bands for
the system of interest. SPGLIB and full three-dimensional periodicity are required. The calculation
diagonalizes the frozen SCF Hamiltonian at each generated point; it does not change the SCF mesh or
density, or reuse irreducible SCF orbitals. Both little-group and compatibility analysis are
implicit. Atomic-signature comparison is optional. Scalar GPW/GAPW and the existing post-SCF GTH-SOC
path share the same isolation, metric, subspace and sewing-law guards.

`LITTLE_GROUP_PATH_POINTS` includes the endpoints and defaults to three. Uniform interior samples
are wrapped and deduplicated, while each subedge retains the difference of its endpoint cell
offsets. This preserves positive, negative and multiple boundary crossings and total winding.
Increase this count to test sampling convergence. `LITTLE_GROUP_MAX_POINTS` is a conservative work
budget before duplicate interiors are merged; it does not bound the geometric enumeration itself.
`REQUIRE_GLOBAL_GAP` rejects a nonpositive **sampled** indirect gap, not an unobserved crossing
between samples. A finite sample cannot prove global isolation or complete connectivity.

The `.little_group` file begins with `AUTO_SIZES`, `AUTO_FAMILY`, `AUTO_CYCLE`, `AUTO_POINT` and
`AUTO_EDGE` records. These retain closure normals/offsets, star sizes, primitive cycles, fractional
coordinates and directed reciprocal shifts. Subsequent band and edge records use these point
indices. Eigenvalues are written to `.eig`; `STATE_EXPORT` can additionally retain the AO states. No
`.mmn` file is created: these ragged symmetry paths are not a Wannier90 neighbour mesh or a
Wilson-loop surface. `WILSON_LOOP` with this source is rejected. Parity analysis may use included
TRIM, but `INVERSION_TQC` still requires all relevant TRIM; star representatives alone need not
contain them all. Use `KPOINTS_SOURCE TRIM` for a guaranteed complete inversion-only sample.

The native tests check full spinful stabilizers, primitive cycles, lifted incidence segments,
unimodular shears, arbitrary origin and coset shifts, operation permutations and rational reciprocal
meshes. Induced scalar/spinful atomic columns must satisfy every generated unitary and antiunitary
segment restriction. A database-free subset covers inversion/time reversal, PT, a magnetic half
translation, a screw, centering and orthorhombic intersections. `--all-settings` extends this to all
530 Hall settings, with and without time reversal.

Gaussian regressions cover scalar He/GPW, all-electron He/GAPW, Ne/GTH-SOC and a consistently
transformed sheared cell. Each case generates 15 fixed families, 56 points and 82 compatible
segments. Local differential tests replay the same points and shifts through explicit NNKP input and
compare eigenvalues, characters, segment restrictions and atomic witnesses. The path budget, invalid
subdivision count, Wilson-mode conflict and a nonisolated single screw branch are tested as explicit
rejections; refined sampling and the unitary-only mode are also checked.

Connected fixed-torus closures are not necessarily connected open strata after higher-symmetry
subsets are removed. The returned incidences and primitive cycles are not a complete equivariant
cell complex, a global band-connectivity classification, or an EBR elementarity test.
Conventional-cell folding is retained; primitive-cell equivalence remains a separate task.

## Onsite reference correspondences

`atomic_band_site_match` identifies a constructed site's local columns against a complete
independent character table. The caller supplies Cartesian reference operations, their antiunitary
flags, explicit spin lifts and an orthogonal map from reference axes to the native axes. Equal band
dimensions or identical sampled induced signatures are not sufficient to assign onsite labels.

The operation map is established geometrically. If the orientation has spin lift $V$, reference
unitary matrices transform as $V U_g V^\dagger$, while the matrix part of an antiunitary operation
transforms as $V A_g V^T$. Each $A_g$ includes the physical $i\sigma_y$ factor. The phase relating
these matrices to the actual spin lifts retained by the native factor constructor fixes the
character convention. It is not inferred from an arbitrary factor coboundary or fitted for each
irrep. Scalar onsite representations use no spin phases.

The matcher checks the full product/factor map, character completeness and a bijection of columns.
For an antiunitary stabilizer, the supplied columns must be the unitary restrictions of complete
corepresentations; paired and doubled restrictions are retained. Duplicate operations/columns,
inconsistent lift/character gauges, missing spin time reversal and invalid axes are rejected.
Failure leaves the output label map unallocated.

The bounded native tests distinguish the one-dimensional C3 irreps, including paired/doubled grey
extensions. A nonsymmorphic P6_3 example has a two-site orbit and C3 onsite symmetry: the same
reference labels retain the analytic induced screw phases at three points along the reciprocal axis,
also after a basis shear, Cartesian rotation, origin shift and operation reversal. Magnetic tests
distinguish a local antiunitary C2\*T stabilizer from a time-reversed half translation that
exchanges sites and imposes no antiunitary onsite restriction. The optional
`topology_band_unittest --site-reference=FILE` sweep uses the Gamma subset of the independent
character-reference fixture. It tests scalar/spinful point-group tables from all 230 groups in three
coordinate conventions. Removing their translations realizes onsite point groups; this sweep is not
a character-level check of every actual Wyckoff-site EBR.

The additional `--wyckoff-reference=FILE` development sweep keeps the actual fractional space-group
translations and supplies generic representatives of all 1,731 conventional Wyckoff families.
Centering is removed by an explicitly recorded primitive basis. Scalar/spinful and ordinary/grey
choices give 6,924 cases, each repeated after a simultaneous Cartesian rotation, lattice shear,
origin shift, operation reversal and integer coset change. Complete onsite character tables come
from the Gamma tables of 32 symmorphic point-group representatives. Their Cartesian orientation is
recorded explicitly; it is not inferred from representation dimensions or induced band signatures.

An independent Python orbit trace additionally checks the induced characters at six reciprocal
points. It combines tabulated onsite characters, explicit orbit representatives, physical SU(2)
intertwiners and Bloch translation phases. The comparison removes only the declared operation-lift
and integer-coset convention changes. It checks all character entries and rejects incomplete output;
the two-rank run repeats this audit on each process rather than distributing its algebra. The table
precision tolerance is dimension-scaled for whole-band characters and does not relax the native
construction tolerance. This covers real-site induction but not every position in a free Wyckoff
family, all reciprocal strata, canonical Bilbao onsite axes/labels, or EBR elementarity. The large
reference fixture is optional and is not installed or read in production calculations.

This is a reference-matching kernel, not yet automatic standard labels in the Gaussian input path.
It introduces no input keyword or runtime database dependency. A named reference correspondence does
not by itself establish EBR elementarity, complete connectivity or material topology.

### Site-resolved EBR character sequences

The optional `topology_band_unittest --ebr-reference=FILE` compares induced columns against named
EBR vectors combined with independent little-group character tables. A reference column must match
the same native onsite column at every supplied point and operation. The test retains all matching
columns rather than forcing a unique onsite label. Coincident signatures are compared as multisets,
so duplicate references cannot consume the same single native column twice.

The development fixture uses the ordinary-group scalar and spinful EBR data in `irreptables` 3.1.0
for all 230 space groups. There are 1,599 site/spin cases, 5,641 reference columns, 9,667 reciprocal
queries and 297,529 character entries per coordinate convention. Explicit type-I character tables
supply 62 additional points in 40 tables, including the opposite valleys KA/HA and PA/WA. Their
shared labelled characters agree with the original tables after checking the operation, spin-lift
and integer-coset maps; no missing labels are inferred by complex conjugation. The adapter retains
the source precision and the declared convention `k_native = -transpose(P) * k_table`.

Both the original and combined sheared/rotated/origin-shifted/reordered conventions pass. Within the
specified Wyckoff position, 5,263 columns have one candidate and 378 have multiple candidates at the
tabulated points. This is sampled character matching, not a canonical onsite-axis identification, an
isomorphism of Bloch bundles or a connectivity proof. The 5,704 native local columns at the selected
sites also include 63 columns absent from the supplied reference; this test does not certify their
elementarity. Grey-group EBR references and automatic Gaussian reference assignment are not part of
this development sweep. No table is installed or read by a production calculation.

The full invariant-torus Fourier comparison finds equal unitary character functions within all 378
multi-candidate reference sets, in both conventions. Finer k sampling alone therefore cannot
separate these cases. This does not assign canonical onsite labels or prove equivalent bundles. The
Fourier sums are also evaluated against raw induction on every torsion component and three samples
of the free coordinates. The `--all-settings` sweep covers all 530 Hall settings, scalar and spinful
ordinary/grey groups at three sites, with 536,410 such queries including analytic controls. The
separate Gaussian `ATOMIC_CHARACTER_CLASS` output is a diagnostic only.

## References

- L. Fu and C. L. Kane, *Topological insulators with inversion symmetry*,
  [Phys. Rev. B **76**, 045302 (2007)](https://doi.org/10.1103/PhysRevB.76.045302).
- B. Bradlyn et al., *Topological quantum chemistry*,
  [Nature **547**, 298--305 (2017)](https://doi.org/10.1038/nature23268).
- H. C. Po, A. Vishwanath and H. Watanabe, *Symmetry-based indicators of band topology in the 230
  space groups*,
  [Nature Communications **8**, 50 (2017)](https://doi.org/10.1038/s41467-017-00133-2).
- J. Cano and B. Bradlyn, *Band representations and topological quantum chemistry*,
  [Annual Review of Condensed Matter Physics **12**, 225--246 (2021)](https://arxiv.org/abs/2006.04890).
- J. Cano et al., *Building blocks of topological quantum chemistry: Elementary band
  representations*, [Phys. Rev. B **97**, 035139 (2018)](https://arxiv.org/abs/1709.01935).
- [Crystalline.jl EBR reference data](https://github.com/thchr/Crystalline.jl/tree/9cfb644a1a4cc1c7baec457b321885459bb98bd1/data/bandreps/3d),
  archived from the Bilbao Crystallographic Server and used only for independent development checks.
- [Spgrep: on-the-fly space-group irreducible representations](https://spglib.github.io/spgrep/),
  used as an independent reference for unitary projective character generation.
- [Bilbao reciprocal-space groups and wave-vector types](https://cryst.ehu.es/cryst/help/definitions_kvec.html),
  for the relation between reciprocal-space orbits and Wyckoff geometry.
