! Development test of the production graph collectives, not a new CP2K dependency.
! Thomas D. Kuehne, tkuehne@cp2k.org
program edge_collectives
   use kinds, only: dp
   use message_passing, only: mp_para_env_type, mp_world_init, mp_world_finalize
   use cp_log_handling, only: cp_logger_type, cp_logger_create, cp_add_default_logger, &
      cp_rm_default_logger, cp_logger_release
   use topology_compatibility, only: little_group_data_type
   use qs_little_group, only: write_little_group_graph
   implicit none
   type(mp_para_env_type), pointer :: para
   type(cp_logger_type), pointer :: logger
   type(little_group_data_type) :: points(3)
   integer :: i, output, detail, shifts(3, 4)
   character(len=32) :: mode

   allocate(para)
   call mp_world_init(para)
   output = -1
   detail = -1
   if (para%is_source()) then
      output = 6
      detail = 21
      open(unit=detail, file='edge_records.txt', status='replace')
   end if
   call cp_logger_create(logger, para_env=para, default_global_unit_nr=output, &
      close_global_unit_on_dealloc=.false.)
   call cp_add_default_logger(logger)
   call get_command_argument(1, mode)
   allocate(points(1)%rotations(3, 3, 1), points(1)%translations(3, 1), &
      points(1)%product(1, 1), points(1)%factors(1, 1), &
      points(1)%characters(1, 1), points(1)%multiplicity(1))
   points(1)%rotations = 0
   do i = 1, 3
      points(1)%rotations(i, i, 1) = 1
      points(1)%cell(i, i) = 1.0_dp
   end do
   points(1)%translations = 0.0_dp
   points(1)%product = 1
   points(1)%factors = 1.0_dp
   points(1)%characters = 1.0_dp
   points(1)%multiplicity = 2
   points(2) = points(1)
   points(3) = points(1)
   points(2)%k(3) = 0.25_dp
   points(3)%k(3) = 0.5_dp
   shifts = 0
   ! Only the second edge fails: rank 1 owns it for any tested multi-rank layout.
   if (mode == 'invalid') points(3)%factors = 0.0_dp
   if (mode == 'incompatible') points(3)%multiplicity = 1
   call write_little_group_graph(points, [1, 2, 1, 2], [2, 3, 1, 1], shifts, &
      1.e-9_dp, 1.0_dp, output, detail, para)
   if (mode == 'invalid') error stop 'Invalid factor unexpectedly accepted'
   if (detail > 0) close(detail)
   call cp_rm_default_logger()
   call cp_logger_release(logger)
   call mp_world_finalize()
end program edge_collectives
