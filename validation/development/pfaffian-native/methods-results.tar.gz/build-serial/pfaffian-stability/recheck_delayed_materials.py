"""Run the immutable material suite with delayed skew pivots, one process per material."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("library", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    library = args.library.resolve()
    output = args.output.resolve()
    output.mkdir(exist_ok=False)
    helper = root / "build-serial/check_sparse_bloch_localizer.py"
    paths = [root / "build-mpi/stanene-bloch-localizer/mesh3"]
    paths += [root / "build-mpi/stanene-flattening" / label for label in
              ("mesh6", "mesh8", "mesh9", "mesh6-tzvp")]
    paths += [root / "build-mpi/stanene-material-convergence" / label for label in
              ("mesh12", "mesh15", "mesh18", "mesh12-tzvp", "mesh12-scf12")]
    summary = []
    manifest = dict(library_sha256=sha(library), helper_sha256=sha(helper),
                    omp_num_threads=os.environ.get("OMP_NUM_THREADS"),
                    openblas_num_threads=os.environ.get("OPENBLAS_NUM_THREADS"), inputs={})
    for work in paths:
        old = json.loads((work / "sparse-final-scan.json").read_text())
        queries = old["queries"]
        manifest["inputs"][work.name] = {name: sha(work / name) for name in
                                        ("stanene.topology", "stanene.mmn", "sparse-final-scan.json")}
        with (output / "manifest.json").open("w") as handle:
            json.dump(manifest, handle, indent=2)
        command = ["/usr/bin/time", "-l", sys.executable, str(helper), str(work),
                   "--library", str(library), "--energy", str(queries[0]["energy"]),
                   "--scale", str(queries[0]["flatten_scale"]),
                   "--eta", *(str(q["eta"]) for q in queries),
                   "--output", str(output / f"{work.name}.json")]
        if work.name == "mesh3":
            command.append("--dense-check")
        print(f"BEGIN {work.name}", flush=True)
        with (output / f"{work.name}.log").open("x") as handle:
            subprocess.run(command, stdout=handle, stderr=subprocess.STDOUT, check=True)
        report = json.loads((output / f"{work.name}.json").read_text())
        for before, after in zip(queries, report["queries"], strict=True):
            assert before["eta"] == after["eta"]
            assert abs(before["gap"] - after["gap"]) < 1e-10
            if before["nu"] is not None:
                assert after["nu"] == before["nu"], (work.name, before, after)
            summary.append(dict(case=work.name, eta=after["eta"], before=before["nu"],
                                after=after["nu"], gap=after["gap"], residual=after["factor_residual"],
                                attempts=len(after["factor_attempts"])))
        with (output / "summary.json").open("w") as handle:
            json.dump(summary, handle, indent=2)
        print(f"END {work.name}", flush=True)
    print(json.dumps(dict(queries=len(summary), resolved=sum(q["after"] is not None for q in summary))), flush=True)


if __name__ == "__main__":
    main()
