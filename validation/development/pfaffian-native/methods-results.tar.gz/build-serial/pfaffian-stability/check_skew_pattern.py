"""Diagnose tolerated roundoff entries with a one-sided sparse pattern."""
import ctypes
import json
import sys
import numpy as np

library = ctypes.CDLL(sys.argv[1])
fun = library.cp2k_tacho_pfaffian_limited
ip = ctypes.POINTER(ctypes.c_int)
dp = ctypes.POINTER(ctypes.c_double)
llp = ctypes.POINTER(ctypes.c_longlong)
fun.argtypes = [ctypes.c_int, ctypes.c_int, ip, ip, dp, ctypes.c_double, ip, dp, llp, ctypes.c_longlong, llp]
fun.restype = ctypes.c_int
a = np.zeros((8, 8))
for i, j, value in [(0, 1, -1), (0, 5, 1), (0, 7, -1), (1, 6, -1), (2, 3, 1), (2, 7, -3), (3, 4, -1), (4, 5, 1), (6, 7, 1)]:
    a[i, j], a[j, i] = value, -value
results = []
if len(sys.argv) > 2:
    n = int(sys.argv[2])
    a = np.diag(np.ones(n - 1), 1) - np.diag(np.ones(n - 1), -1)
n = len(a)
for i, j in zip(*np.where((a == 0) & ~np.eye(n, dtype=bool))):
    b = a.copy()
    b[i, j] = 1e-15
    rows, cols = np.indices(b.shape)
    rows = np.asarray(rows.flatten() + 1, dtype=np.int32)
    cols = np.asarray(cols.flatten() + 1, dtype=np.int32)
    values = b.flatten()
    sign, residual, fill, peak = ctypes.c_int(), ctypes.c_double(), ctypes.c_longlong(), ctypes.c_longlong()
    status = fun(n, n*n, rows.ctypes.data_as(ip), cols.ctypes.data_as(ip), values.ctypes.data_as(dp), 1e-10,
                 ctypes.byref(sign), ctypes.byref(residual), ctypes.byref(fill), 1 << 30, ctypes.byref(peak))
    results.append(dict(i=int(i), j=int(j), status=status, sign=sign.value, residual=residual.value))
print(json.dumps(results, indent=2))
