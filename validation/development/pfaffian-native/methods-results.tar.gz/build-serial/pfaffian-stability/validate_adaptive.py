"""Independent, deterministic sign and rejection checks for a research library."""

import argparse
import ctypes
import json
from pathlib import Path
import sys

import numpy as np
from scipy import linalg, sparse

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from check_sparse_bloch_localizer import tacho_sign_once


def reference(matrix):
    h, q = linalg.hessenberg(matrix, calc_q=True)
    sign = int(np.linalg.slogdet(q)[0] * np.prod(np.sign(np.diag(h, 1)[::2])))
    return sign, float(linalg.svdvals(matrix)[-1])


def cases():
    rng = np.random.default_rng(95832)
    for n in (8, 16, 32, 64, 96):
        for seed in range(12):
            upper = np.triu(rng.integers(-5, 6, (n, n)) * (rng.random((n, n)) < 0.12), 1)
            upper[np.arange(0, n, 2), np.arange(1, n, 2)] += 2
            yield f"sparse-{n}-{seed}", upper - upper.T, None
        for seed in range(4):
            lower = np.eye(n)
            for j in range(n):
                for i in range(j + 1, min(n, j + 5)):
                    lower[i, j] = rng.integers(-2, 3) / 8
            blocks = np.zeros((n, n))
            signs = rng.choice((-1.0, 1.0), n // 2)
            blocks[np.arange(0, n, 2), np.arange(1, n, 2)] = signs
            blocks -= blocks.T.copy()
            yield f"congruence-{n}-{seed}", lower @ blocks @ lower.T, int(np.prod(signs))
            blocks[-2:, -2:] = 0
            yield f"singular-{n}-{seed}", lower @ blocks @ lower.T, 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("library", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    library = ctypes.CDLL(str(args.library.resolve()))
    results = []
    for label, matrix, analytic in cases():
        n = len(matrix)
        expected, gap = reference(matrix)
        singular = bool(gap <= 1e-12 * np.linalg.norm(matrix, 2))
        if analytic not in (0, None):
            assert not singular and expected == analytic, (label, expected, analytic)
        if analytic == 0:
            assert singular, (label, gap)
        for scale in (1.0, 1e-120, 1e120):
            for swap in (False, True):
                order = np.arange(n)
                if swap:
                    order[:2] = [1, 0]
                sign, residual, fill = tacho_sign_once(sparse.csr_matrix(scale * matrix[order][:, order]), library)
                target = expected * (-1 if swap else 1)
                assert sign is None or singular or sign == target, (label, scale, swap, sign, target, gap)
                if analytic not in (0, None):
                    assert sign == target, (label, scale, swap)
                if sign is not None:
                    assert residual <= 1e-10
                results.append(dict(case=label, scale=scale, swap=swap, expected=target,
                                    gap=gap, singular=singular, sign=sign, residual=residual,
                                    panel_entries=fill))
    summary = dict(queries=len(results), resolved=sum(r["sign"] is not None for r in results),
                   singular_queries=sum(r["singular"] for r in results),
                   nonsingular_unresolved=sum(not r["singular"] and r["sign"] is None for r in results),
                   wrong_accepted_signs=0,
                   singular_accepted=sum(r["singular"] and r["sign"] is not None for r in results))
    with args.output.open("x") as handle:
        json.dump(dict(summary=summary, results=results), handle, indent=2)
    print(json.dumps(summary), flush=True)
    if summary["singular_accepted"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
