"""Stress delayed skew pivots with independently known Pfaffians and nullities."""

import argparse
import ctypes
import json
from pathlib import Path
import sys

import numpy as np
from scipy import linalg, sparse

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from check_sparse_bloch_localizer import tacho_sign_once
from validate_adaptive import reference


def permutation_sign(order):
    return (-1) ** sum(int(np.count_nonzero(order[i + 1:] < value)) for i, value in enumerate(order))


def cases():
    rng = np.random.default_rng(907619)
    for n in (2, 10, 26, 70, 130, 258):
        for shape in ("band", "separator", "random", "dense"):
            lower = np.eye(n)
            for j in range(n):
                for i in range(j + 1, n):
                    take = {"band": i - j < 5,
                            "separator": i >= n - 3 or i // 8 == j // 8,
                            "random": rng.random() < 4 / n,
                            "dense": True}[shape]
                    if take:
                        lower[i, j] = rng.integers(-2, 3) / (32 if shape == "dense" else 8)
            signs = rng.choice((-1.0, 1.0), n // 2)
            for zero in (False, True):
                block = np.zeros((n, n))
                block[np.arange(0, n, 2), np.arange(1, n, 2)] = signs
                block -= block.T.copy()
                if zero:
                    block[-2:, -2:] = 0
                matrix = lower @ block @ lower.T
                # The binary fractions make the intended zero block exact.
                yield f"{shape}-{n}-null{2 * zero}", matrix, 0 if zero else int(np.prod(signs))
        # Nontrivial disconnected components exercise independent permutation parities.
        if n >= 10:
            sizes = (2, 4, n - 6)
            blocks = []
            for size in sizes:
                upper = np.triu(rng.integers(-4, 5, (size, size)), 1)
                blocks.append(upper - upper.T)
            yield f"disconnected-{n}", linalg.block_diag(*blocks), None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("library", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    library = ctypes.CDLL(str(args.library.resolve()))
    rng = np.random.default_rng(215893)
    results = []
    for label, matrix, analytic in cases():
        norm = np.linalg.norm(matrix, 2)
        expected, gap = reference(matrix)
        singular = gap <= 1e-12 * norm
        if analytic == 0:
            assert singular, (label, gap)
        elif analytic is not None:
            assert not singular and expected == analytic, (label, expected, analytic)
        for iteration in range(4):
            order = rng.permutation(len(matrix))
            target = expected * permutation_sign(order)
            for scale in (1.0, 1e-120, 1e120):
                sign, residual, fill = tacho_sign_once(
                    sparse.csr_matrix(scale * matrix[order][:, order]), library)
                if singular:
                    assert sign is None, (label, iteration, scale, sign)
                else:
                    assert sign is None or sign == target, (label, iteration, scale, sign, target)
                    if gap > 1e-7 * norm:
                        assert sign == target, (label, iteration, scale, gap, residual)
                if sign is not None:
                    assert residual <= 1e-10, (label, residual)
                results.append(dict(case=label, iteration=iteration, scale=scale,
                                    gap=float(gap), relative_gap=float(gap / norm) if norm else 0.0,
                                    permutation_sign=permutation_sign(order), expected=target,
                                    singular=bool(singular), sign=sign, residual=residual,
                                    panel_entries=fill))
    summary = dict(queries=len(results), resolved=sum(r["sign"] is not None for r in results),
                   singular_queries=sum(r["singular"] for r in results),
                   nonsingular_unresolved=sum(not r["singular"] and r["sign"] is None for r in results),
                   wrong_accepted_signs=0, singular_accepted=0)
    with args.output.open("x") as handle:
        json.dump(dict(summary=summary, results=results), handle, indent=2)
    print(json.dumps(summary), flush=True)


if __name__ == "__main__":
    main()
