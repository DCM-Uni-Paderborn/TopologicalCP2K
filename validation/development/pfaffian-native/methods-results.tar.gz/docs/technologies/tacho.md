# Tacho Sparse Pfaffians

`CP2K_USE_TACHO=ON` adds optional native sparse real skew-LDL Pfaffian signs for
`FORCE_EVAL/PROPERTIES/SPECTRAL_LOCALIZER/SOLVER TACHO` with `INVARIANT Z2`. It also requires
`CP2K_USE_MUMPS=ON`: MUMPS independently checks the positive AO metric and brackets the generalized
localizer gap. Neither a determinant nor ordinary inertia can replace the orientation-sensitive
Pfaffian sign.

The tested library is the Tacho skew-LDL development branch:
[iyamazaki/Trilinos, branch tacho-sk](https://github.com/iyamazaki/Trilinos/tree/tacho-sk). The
tested source revision is `02ef047cb4e1e16959714ce50462bb09511d0e9a`. The current numerical
extension uses Tacho's public symbolic analysis and BLAS interfaces, not its fixed-front skew
factorization. Other Trilinos versions have not been validated. Tacho is BSD-2-Clause licensed. The
native adapter uses Boost Graph's header-only general-graph matching (Boost Software License) and
the serial Kokkos execution space. No MATLAB, SuperLU_DIST or proprietary matching library is
required. No external sources are copied into CP2K.

Build Trilinos with `Trilinos_ENABLE_ShyLU_NodeTacho=ON`, `Kokkos_ENABLE_SERIAL=ON`,
`Tacho_ENABLE_INT_INT=ON`, BLAS/LAPACK enabled, and MATLAB/tests/examples disabled. Set
`ShyLU_NodeTacho_DIR` to the installed `lib/cmake/ShyLU_NodeTacho` and provide Boost's CMake
configuration through `CMAKE_PREFIX_PATH` as needed. Use the same C++ ABI and BLAS integer width as
CP2K. Tacho's skew API is experimental; pin the tested revision when reproducing results.

To reproduce comparisons with the former fixed-front numerical path, apply CP2K's
`tools/toolchain/scripts/stage5/tacho-sk-floating-pivot.patch` to the Trilinos source tree:

```shell
git -C /path/to/Trilinos apply /path/to/cp2k/tools/toolchain/scripts/stage5/tacho-sk-floating-pivot.patch
```

Rebuild and reinstall Tacho, then relink the comparison adapter. Updating installed headers alone
does not repair the compiled factorization. The original unqualified `abs` calls can select the
integer overload and truncate subunit pivot magnitudes to zero. The patch uses
`ArithTraits<value_type>::abs` without changing the pivot threshold, candidate rows or permutation
signs. The sparse unit test includes an 8x8 integer-entry matrix with exact Pfaffian 60 that fails
with the affected library and succeeds with the patch, including an odd permutation and scales
`1e-120` and `1e120`. The current native numerical extension no longer executes this dependency
routine.

## Algorithm and Safeguards

DBCSR assembly and MUMPS gap checks remain distributed. Only sparse coordinate data are gathered to
the source rank for the native Pfaffian factorization. The fixed AII transformation
`Q = (I - i C)/sqrt(2)` has two entries per row and is applied by sparse permutations/additions,
without dense localizer or metric matrices. The imaginary residual and real skew structure are
checked. Tolerated roundoff is removed by `A = (Re(A) - Re(A)^T)/2`, with a symmetric union of the
two sparse patterns. The maximum of the discarded part's row and column absolute sums bounds its
spectral norm and must be small relative to the independently bounded gap in the AO metric. A
one-sided roundoff entry must not invalidate the symbolic frontal pattern.

Connected components are factored separately. A largest-entry-first greedy matching is augmented
with general-graph Edmonds matching to supply nonzero 2x2 pivots; its permutation parity is
retained. Tacho's public `GraphTools_Metis` and `SymbolicTools` interfaces provide the scalar
fill-reducing ordering and frontal tree. CP2K's real skew-specific numerical extension passes
unstable variables and their Schur contributions to the parent front, without restarting symbolic
analysis. Odd-sized fronts are allowed. Original entries are assembled exactly once, and pivot tests
include both complete updated columns, including the separator, at threshold 0.01. The root uses a
rook search. A blocked BLAS-3 update accumulates 64 accepted columns. Pivot perturbations and entry
dropping are disabled; isolated 2x2 components are evaluated analytically. Conventional upper-entry
pivot signs and the complete elimination permutation give the component Pfaffian, with the initial
matching parity included separately.

The atomic reference orientation is `(-1)**nao` in CP2K's fixed auxiliary/spin/AO order. A positive,
time-reversal-compatible metric can be continuously deformed to the identity without closing this
reference gap, so its sign needs no additional factorization. The physical localizer is not
orthogonalized or projected onto occupied states.

Four deterministic, independent right-hand sides diagnose inaccurate factors. They are not formed as
`b = A*x`, which would mask nullspace errors by restricting the probes to the range of `A`. Their
worst relative two-norm residual is reported, but is not a rigorous backward-error certificate for
the entire factorization. Small pivots, nonfinite factors, failed probes or an unresolved spectral
gap do not yield an index. Solver exceptions are propagated collectively. There is no silent dense
fallback.

`PFAFFIAN_MEMORY` limits requested double-precision factor, pivot, frontal, update and solve buffers
in MiB (default 4096). A rejected allocation produces a collective error and no index. This is not a
whole-process cap: sparse input, matching, symbolic ordering, integer metadata, allocator overhead,
DBCSR and MUMPS allocations are outside it. The reported peak covers the same numerical buffers.
Scalar panel entries are reported separately, excluding pivot vectors. Disconnected components are
processed one at a time; their peak buffer usage is a maximum, whereas their reported panel entries
are summed. Analytic 2x2 components store no panels.

## Limits

This is a **single-rank sparse Pfaffian factorization**, not an MPI-distributed Pfaffian solver.
Factor fill-in, Boost matching and the source-rank coordinate storage limit the largest usable
problem. The reported MUMPS memory excludes Tacho, matching and coordinate buffers. The Pfaffian
scalar panel count is a separate diagnostic, not whole-process memory. The former unimplemented
Tacho factor-export function is not used. This path also evaluates the two-dimensional periodic
full-torus localizer. That construction retains all property k-point sectors rather than summing
independently reduced k-point indices; it does not change the source-rank Pfaffian factorization
limit. See the [localizer documentation](../methods/properties/spectral_localizer.md) for the
finite-AO interpretation and required size, basis and scale checks.

Delays handle local elimination blocks that are singular despite a gapped complete matrix. They can
increase fill-in and do not guarantee a bounded front size or a successful numerical factorization.
Small pivots or failed solve probes still remain unresolved, without relaxing the threshold or
substituting a reference index. Distributed numerical factors remain future work.

The mathematical and independent-model validation is in `spectral_localizer_sparse_unittest`; the
optional GTH-SOC end-to-end inputs are in `QS/regtest-spectral-localizer-tacho`.

Local validation covers 344 dense/sparse Pfaffian comparisons over sizes 2 through 24, odd
permutations, disconnected components, numerical singularities with perfect graph matchings, and
scales from `1e-120` to `1e120`. Six further checks reject an analytically rank-22 matrix of order
24 with no zero rows, including odd swaps and the same extreme scales. Its nullspace is hidden from
the former `A*x` probes. A further integer-entry fixture with exact Pfaffian 3 checks recovery from
a fixed-front failure, including odd swaps and both extreme scales. Buffer tests check an exactly
sufficient budget and its one-byte reduction, collective exhaustion, and inconsistent positive
limits on different ranks. Additional checks cover invalid coordinates, non-skew input, additive
duplicates, unresolved pivots and a 32-site chain with one-sided roundoff, its transpose, odd
permutations and extreme scales. Spin-mixed QWZ/Kramers-pair models exercise both Z2 indices,
complex nonorthogonal metrics, roundoff and broken time reversal, and gap closings. The largest
checked complex localizer has order 800 (realified order 1600).

The dense/MUMPS/Tacho finite and periodic directories pass 74 checks with four MPI ranks and two
OpenMP threads; the dense directory also passes 45 checks in a build without the optional libraries.
Neon and bismuth GPW SOC gaps agree with the dense oracle. A separate bismuth GAPW SOC smoke test
also agrees, and the numerical Fortran modules pass bounds checks and floating-point traps with two
MPI ranks. These are solver and integration tests, not size-converged topological-material
benchmarks or a claim of multi-node Pfaffian scaling.

Two additional synthetic suites exercise the native C++ extension under undefined-behaviour
instrumentation: 804 nonsingular queries return the independently expected signs and 432 singular
queries are rejected. A 32-site chain also passes all 930 placements of a one-sided roundoff
coupling, including the 435 placements that previously failed symbolic assembly. Instrumentation
does not cover the prebuilt dependencies. These checks supplement, not replace, the physical gap
validation and full CP2K regression inputs.
