"""Check the frozen small pivot fixture with one loaded dependency version."""
import argparse
import ctypes
import json
from pathlib import Path
import sys

import numpy as np
from scipy import sparse

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from check_sparse_bloch_localizer import tacho_sign_once


def pfaffian(a):
    if not a:
        return 1
    return sum((-1)**(j + 1) * a[0][j] * pfaffian([
        [a[k][l] for l in range(len(a)) if l not in (0, j)]
        for k in range(len(a)) if k not in (0, j)]) for j in range(1, len(a)))


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("library", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()
fixture = json.loads(Path(__file__).with_name("pivot-fixture-v2.json").read_text())
a = np.array(fixture["matrix"])
exact = pfaffian(a.astype(int).tolist())
library = ctypes.CDLL(str(args.library.resolve()))
results = []
for scale in (1.0, 1e-120, 1e120):
    for order in (np.arange(len(a)), np.r_[1, 0, np.arange(2, len(a))]):
        sign, residual, fill = tacho_sign_once(sparse.csr_matrix(scale*a[order][:, order]), library)
        expected = int(np.sign(exact)) * (1 if order[0] == 0 else -1)
        results.append(dict(scale=scale, ordering=order.tolist(), sign=sign,
                            expected=expected, residual=residual, fill=fill))
report = dict(exact_pfaffian=exact, smallest_singular_value=fixture["gap"], results=results)
with args.output.open("x") as handle:
    json.dump(report, handle, indent=2)
print(json.dumps(report), flush=True)
