"""Complete the scan while retaining, rather than aborting on, new unresolved cases."""
import ctypes
import hashlib
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from check_sparse_bloch_localizer import analyze

root = Path(__file__).resolve().parents[2]
output = Path(__file__).with_name("material-recheck")
library_path = root / "build-mpi/src/libcp2k.2026.2.dylib"
library_hash = hashlib.sha256(library_path.read_bytes()).hexdigest()
library = ctypes.CDLL(str(library_path))
paths = [root / "build-mpi/stanene-bloch-localizer/mesh3"]
paths += [root / "build-mpi/stanene-flattening" / label for label in ("mesh6", "mesh8", "mesh9", "mesh6-tzvp")]
paths += [root / "build-mpi/stanene-material-convergence" / label for label in
          ("mesh12", "mesh15", "mesh18", "mesh12-tzvp", "mesh12-scf12")]
summary = []
for work in paths:
    baseline = json.loads((work / "sparse-final-scan.json").read_text())
    queries = baseline["queries"]
    target = output / f"{work.name}.json"
    if target.exists():
        report = json.loads(target.read_text())
        assert report["library_sha256"] == library_hash
        for name, expected in report["inputs"].items():
            assert hashlib.sha256((work / name).read_bytes()).hexdigest() == expected
    else:
        print(f"BEGIN {work.name}", flush=True)
        report = analyze(work, queries[0]["energy"], [q["eta"] for q in queries],
                         queries[0]["flatten_scale"], library)
        report["inputs"] = {name: hashlib.sha256((work / name).read_bytes()).hexdigest()
                            for name in ("stanene.topology", "stanene.mmn", "sparse-final-scan.json")}
        report["library_sha256"] = library_hash
        report["reference_script_sha256"] = hashlib.sha256(
            (root / "build-serial/check_sparse_bloch_localizer.py").read_bytes()).hexdigest()
        with target.open("x") as handle:
            json.dump(report, handle, indent=2)
        print(f"END {work.name}", flush=True)
    for old, new in zip(queries, report["queries"], strict=True):
        assert old["eta"] == new["eta"] and abs(old["gap"] - new["gap"]) < 1e-10
        if old["nu"] is not None and new["nu"] is not None:
            assert old["nu"] == new["nu"]
        summary.append(dict(case=work.name, eta=new["eta"], before=old["nu"], after=new["nu"],
                            residual=new["factor_residual"], attempts=len(new["factor_attempts"])))
with (output / "summary.json").open("x") as handle:
    json.dump(summary, handle, indent=2)
print(json.dumps(summary), flush=True)
