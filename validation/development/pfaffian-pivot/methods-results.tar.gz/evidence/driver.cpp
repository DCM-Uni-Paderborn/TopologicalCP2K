#include "Kokkos_Core.hpp"
#include "Tacho.hpp"
#include "Tacho_Driver.hpp"
#include "Tacho_Driver_Impl.hpp"

template struct Tacho::Driver<double, Kokkos::Device<Kokkos::Serial, Kokkos::HostSpace>>;
