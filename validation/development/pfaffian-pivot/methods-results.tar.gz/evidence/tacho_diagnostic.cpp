/*----------------------------------------------------------------------------*/
/*  CP2K: A general program to perform molecular dynamics simulations         */
/*  Copyright 2000-2026 CP2K developers group <https://cp2k.org>              */
/*                                                                            */
/*  SPDX-License-Identifier: GPL-2.0-or-later                                 */
/*----------------------------------------------------------------------------*/

// Native adapter for the BSD-licensed Tacho skew-LDL extension; no MATLAB API.
#include <Kokkos_Core.hpp>
#include <Tacho_Solver.hpp>
#include <algorithm>
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/connected_components.hpp>
#include <boost/graph/max_cardinality_matching.hpp>
#include <cmath>
#include <complex>
#include <cstdio>
#include <limits>
#include <map>
#include <set>
#include <stdexcept>
#include <tuple>
#include <vector>

namespace {
using Complex = std::complex<double>;
using Matrix = std::vector<std::map<int, Complex>>;
using Graph =
    boost::adjacency_list<boost::vecS, boost::vecS, boost::undirectedS>;
using Solver =
    Tacho::Solver<double, Kokkos::Device<Kokkos::Serial, Kokkos::HostSpace>>;

struct Runtime {
  bool owner = !Kokkos::is_initialized();
  Runtime() {
    if (Kokkos::is_finalized())
      throw std::runtime_error("Kokkos already finalized");
    if (owner)
      Kokkos::initialize();
  }
  ~Runtime() {
    if (owner && Kokkos::is_initialized() && !Kokkos::is_finalized())
      Kokkos::finalize();
  }
};

struct Factorization {
  Solver solver;
  ~Factorization() { solver.release(); }
};

Complex entry(const Matrix &a, int i, int j) {
  auto p = a[i].find(j);
  return p == a[i].end() ? Complex{} : p->second;
}

int parity(const std::vector<int> &permutation) {
  std::vector<bool> visited(permutation.size(), false);
  int sign = 1;
  for (size_t i = 0; i < permutation.size(); ++i) {
    if (visited[i])
      continue;
    visited[i] = true;
    for (size_t j = permutation[i]; j != i; j = permutation[j]) {
      visited[j] = true;
      sign = -sign;
    }
  }
  return sign;
}

// Q=(I-iC)/sqrt(2), C a signed involution. At most four sparse insertions per
// entry.
Matrix transform(const Matrix &a, bool multiply_i) {
  const int n = a.size(), quarter = n / 4;
  Matrix result(n);
  auto partner = [quarter](int i) {
    return (3 - i / quarter) * quarter + i % quarter;
  };
  auto sign = [quarter](int i) {
    return i / quarter == 0 || i / quarter == 3 ? 1.0 : -1.0;
  };
  const Complex factor = multiply_i ? Complex(0, 0.5) : Complex(0.5, 0);
  for (int i = 0; i < n; ++i) {
    for (const auto &[j, value] : a[i]) {
      const Complex v = factor * value;
      result[i][j] += v;
      result[partner(i)][partner(j)] += sign(i) * sign(j) * v;
      result[partner(i)][j] += Complex(0, sign(i)) * v;
      result[i][partner(j)] -= Complex(0, sign(j)) * v;
    }
  }
  return result;
}

// Factor each connected component independently. Pairing uses a general-graph
// perfect matching, not the bipartite matching assumed by Tacho's MATLAB
// driver.
int pfaffian(const Matrix &input, double tolerance, double &residual,
             long long &fill) {
  static Runtime runtime;
  const int n = input.size();
  if (n < 2 || n % 2)
    throw std::invalid_argument("Invalid skew order");
  Graph graph(n);
  double scale = 0;
  for (int i = 0; i < n; ++i) {
    for (const auto &[j, v] : input[i]) {
      if (!std::isfinite(v.real()) || !std::isfinite(v.imag()))
        throw std::invalid_argument("Nonfinite skew matrix");
      scale = std::max(scale, std::abs(v));
      if (j > i && v.real() != 0)
        boost::add_edge(i, j, graph);
    }
  }
  if (scale == 0)
    return 0;
  for (int i = 0; i < n; ++i)
    for (const auto &[j, v] : input[i])
      if (std::abs(v.imag()) > tolerance * scale ||
          std::abs(v + entry(input, j, i)) > tolerance * scale)
        throw std::invalid_argument("Not real skew symmetric");

  std::vector<int> component(n);
  const int count = boost::connected_components(graph, component.data());
  std::vector<std::vector<int>> members(count);
  for (int i = 0; i < n; ++i)
    members[component[i]].push_back(i);
  const auto unmatched = boost::graph_traits<Graph>::null_vertex();
  std::vector<Graph::vertex_descriptor> mate(n, unmatched);
  std::vector<std::tuple<double, int, int>> edges;
  for (int i = 0; i < n; ++i)
    for (const auto &[j, v] : input[i])
      if (j > i && v.real() != 0)
        edges.emplace_back(-std::abs(v.real()), i, j);
  std::sort(edges.begin(), edges.end());
  double cutoff = scale;
  for (int i = 0; i < n; ++i) {
    double row_max = 0;
    for (const auto &[j, value] : input[i])
      if (j != i) row_max = std::max(row_max, std::abs(value.real()));
    cutoff = std::min(cutoff, row_max);
  }
  for (;;) {
    graph = Graph(n);
    std::fill(mate.begin(), mate.end(), unmatched);
    for (const auto &[weight, i, j] : edges) {
      if (-weight < cutoff) break;
      boost::add_edge(i, j, graph);
      if (mate[i] == unmatched && mate[j] == unmatched) {
        mate[i] = j;
        mate[j] = i;
      }
    }
    auto vertex_index = boost::get(boost::vertex_index, graph);
    boost::edmonds_augmenting_path_finder<Graph, Graph::vertex_descriptor *,
                                          decltype(vertex_index)>
        augmentor(graph, mate.data(), vertex_index);
    while (augmentor.augment_matching()) {}
    augmentor.get_current_matching(mate.data());
    const auto matched = 2 * boost::matching_size(graph, mate.data());
    std::fprintf(stderr, "CANDIDATES cutoff=%.17g matched=%zu/%d\n", cutoff/scale, matched, n);
    if (matched == static_cast<size_t>(n)) break;
    if (cutoff == 0) return 0;
    cutoff *= 0.5;
    if (cutoff <= std::numeric_limits<double>::epsilon()*scale) cutoff = 0;
  }
  double min_match = std::numeric_limits<double>::infinity();
  for (int i = 0; i < n; ++i)
    min_match = std::min(min_match, std::abs(entry(input, i, mate[i]))/scale);
  std::fprintf(stderr, "MATCH order=%d min=%.17g\n", n, min_match);

  std::vector<int> permutation, inverse(n);
  permutation.reserve(n);
  for (const auto &vertices : members)
    for (int i : vertices)
      if (i < static_cast<int>(mate[i])) {
        permutation.push_back(i);
        permutation.push_back(mate[i]);
      }
  for (int i = 0; i < n; ++i)
    inverse[permutation[i]] = i;
  int result = parity(permutation), begin = 0;
  for (const auto &vertices : members) {
    const int m = vertices.size();
    if (m % 2)
      return 0;
    // Exact sparse 2x2 component; also avoids Tacho's unsupported one-node
    // graph.
    if (m == 2) {
      const double pivot =
          entry(input, permutation[begin], permutation[begin + 1]).real();
      if (std::abs(pivot) <= tolerance * scale)
        return 0;
      result *= pivot > 0 ? 1 : -1;
      fill += 1;
      begin += m;
      continue;
    }
    std::vector<std::map<int, double>> rows(m);
    size_t nnz = 0;
    for (int i = 0; i < m; ++i) {
      rows[i][i] = 0;
      for (const auto &[j, v] : input[permutation[begin + i]]) {
        if (v.real() != 0) {
          const int column = inverse[j] - begin;
          if (column < 0 || column >= m)
            throw std::invalid_argument("Asymmetric component pattern");
          rows[i][column] = v.real() / scale;
        }
      }
      nnz += rows[i].size();
    }
    if (nnz > static_cast<size_t>(std::numeric_limits<int>::max()))
      throw std::overflow_error("Tacho index overflow");
    Solver::size_type_array ap("rowptr", m + 1);
    Solver::ordinal_type_array aj("columns", nnz);
    Solver::value_type_array av("values", nnz), diagonal("pivots", m);
    size_t k = 0;
    for (int i = 0; i < m; ++i) {
      ap(i) = k;
      for (const auto &[j, v] : rows[i]) {
        aj(k) = j;
        av(k++) = v;
      }
    }
    ap(m) = k;
    Factorization factors;
    auto &solver = factors.solver;
    solver.setVerbose(0);
    solver.setSolutionMethod(5);
    solver.setSmallProblemThresholdsize(0);
    solver.setLevelSetScheduling(false);
    solver.doLocalPivot(true);
    solver.useNoPivotTolerance();
    // Keep matched pairs together in the fill-reducing ordering. Pair
    // permutations are even; our scalar matching parity is accounted for
    // separately above.
    std::vector<std::set<int>> graph_rows(m / 2);
    size_t graph_nnz = 0;
    for (int i = 0; i < m; ++i)
      for (const auto &[j, v] : rows[i])
        graph_rows[i / 2].insert(j / 2);
    for (const auto &row : graph_rows)
      graph_nnz += row.size();
    Solver::size_type_array graph_ptr("pair_rowptr", m / 2 + 1);
    Solver::ordinal_type_array graph_col("pair_columns", graph_nnz),
        weights("pair_weights", m / 2);
    k = 0;
    for (int i = 0; i < m / 2; ++i) {
      graph_ptr(i) = k;
      weights(i) = 2;
      for (int j : graph_rows[i])
        graph_col(k++) = j;
    }
    graph_ptr(m / 2) = k;
    solver.analyze(m, ap, aj, m / 2, graph_ptr, graph_col, weights);
    solver.initialize();
    solver.factorize(av);
    solver.diag(diagonal);
    double smallest = std::numeric_limits<double>::infinity(), largest = 0;
    bool small_pivot = false;
    for (int i = 1; i < m; i += 2) {
      smallest = std::min(smallest, std::abs(diagonal(i)));
      largest = std::max(largest, std::abs(diagonal(i)));
      small_pivot |= !std::isfinite(diagonal(i)) || std::abs(diagonal(i)) <= tolerance;
    }
    std::fprintf(stderr, "PIVOTS order=%d min=%.17g max=%.17g rejected=%d\n", m, smallest, largest, small_pivot);
    int sign = solver.pfaffian();
    if (sign != 1 && sign != -1)
      return 0;
    // Tacho multiplies the LOWER entries D(2i+1,2i). The conventional
    // Pfaffian uses UPPER entries, hence one additional minus sign per pair.
    if ((m / 2) % 2)
      sign = -sign;
    auto ordering = solver.getPermutationVector();
    std::vector<int> ordered(m);
    for (int i = 0; i < m; ++i)
      ordered[i] = ordering(i);
    sign *= parity(ordered);
    // This revision reports the condensed (2x2-block) symbolic upper pattern.
    // Its factor-export API is a no-op; do not report it as scalar storage.
    fill += solver.getNumNonZerosU();

    // Deterministic solve probes diagnose inaccurate factors. These complement,
    // but do not replace, the independently computed MUMPS spectral-gap test.
    constexpr int probes = 4;
    Solver::value_type_matrix exact("probe", m, probes), rhs("rhs", m, probes),
        solution("solution", m, probes), workspace("workspace", m, probes);
    for (int p = 0; p < probes; ++p)
      for (int i = 0; i < m; ++i)
        exact(i, p) =
            std::sin((i + 1.0) * (p + 1.0)) + std::cos((i + 1.0) / (p + 2.0));
    solver.computeSpMV(av, exact, rhs);
    solver.solve(solution, rhs, workspace);
    const double error = solver.computeRelativeResidual(av, solution, rhs);
    double forward_error = 0;
    for (int p = 0; p < probes; ++p)
      for (int i = 0; i < m; ++i)
        forward_error = std::max(forward_error, std::abs(solution(i,p)-exact(i,p)));
    std::fprintf(stderr, "SOLVE residual=%.17g forward=%.17g sign=%d\n", error, forward_error, sign);
    if (!std::isfinite(error))
      return 0;
    residual = std::max(residual, error);
    if (small_pivot || error > tolerance)
      return 0;
    result *= sign;
    begin += m;
  }
  return result;
}
} // namespace

extern "C" int cp2k_tacho_pfaffian(int n, int nnz, const int *rows,
                                   const int *cols, const double *values,
                                   double tolerance, int *sign,
                                   double *residual, long long *fill) {
  *sign = 0;
  *residual = 0;
  *fill = 0;
  try {
    if (n < 2 || n % 2 || nnz < 0 || !(tolerance > 0) ||
        !std::isfinite(tolerance))
      return -1;
    Matrix a(n);
    for (int k = 0; k < nnz; ++k) {
      if (rows[k] < 1 || rows[k] > n || cols[k] < 1 || cols[k] > n)
        return -1;
      a[rows[k] - 1][cols[k] - 1] += values[k];
    }
    *sign = pfaffian(a, tolerance, *residual, *fill);
    return *sign == 0 ? 1 : 0;
  } catch (const std::invalid_argument &) {
    return -1;
  } catch (...) {
    return -4;
  }
}

extern "C" int cp2k_tacho_z2(int order, int nnz, const int *rows,
                             const int *cols, const double *a, const double *b,
                             double tolerance, double metric_ratio, double gap,
                             int *index, double *residual, long long *fill) {
  *index = 0;
  *residual = 0;
  *fill = 0;
  try {
    if (order < 8 || order % 8 || nnz < 0 || !std::isfinite(tolerance) ||
        !std::isfinite(metric_ratio) || !std::isfinite(gap) || tolerance <= 0 ||
        tolerance >= 1 || metric_ratio <= 0 || metric_ratio > 1 || gap <= 0)
      return -1;
    const int n = order / 2;
    Matrix localizer(n), metric(n);
    std::vector<double> bnorm(order, 0);
    for (int k = 0; k < nnz; ++k) {
      const int i = rows[k] - 1, j = cols[k] - 1;
      if (j < 0 || i < j || i >= order || !std::isfinite(a[k]) ||
          !std::isfinite(b[k]))
        return -1;
      bnorm[i] += std::abs(b[k]);
      if (i != j)
        bnorm[j] += std::abs(b[k]);
      if (i < n) {
        localizer[i][j] += a[k];
        metric[i][j] += b[k];
        if (i != j) {
          localizer[j][i] += a[k];
          metric[j][i] += b[k];
        }
      } else if (j < n) {
        localizer[i - n][j] += Complex(0, a[k]);
        metric[i - n][j] += Complex(0, b[k]);
      }
    }
    Matrix skew = transform(localizer, true),
           real_metric = transform(metric, false);
    double scale = 0, structure_error = 0, metric_scale = 0, metric_error = 0;
    for (int i = 0; i < n; ++i) {
      double discarded = 0;
      for (auto &[j, v] : skew[i]) {
        if (!std::isfinite(v.real()) || !std::isfinite(v.imag()))
          return -1;
        scale = std::max(scale, std::abs(v));
        discarded += std::abs(v.imag());
        v = v.real();
      }
      structure_error = std::max(structure_error, discarded);
      for (const auto &[j, v] : real_metric[i]) {
        if (!std::isfinite(v.real()) || !std::isfinite(v.imag()))
          return -1;
        metric_scale = std::max(metric_scale, std::abs(v));
        metric_error = std::max(metric_error, std::abs(v.imag()));
      }
    }
    if (structure_error > tolerance * scale ||
        metric_error > tolerance * metric_scale)
      return -3;
    const double metric_min =
        metric_ratio * *std::max_element(bnorm.begin(), bnorm.end());
    if (structure_error >= 0.25 * gap * metric_min)
      return 1;
    // Positive TR-compatible S deforms continuously to I without a Pfaffian
    // zero. In this fixed component ordering the atomic reference has sign
    // (-1)^(n/4).
    const int reference = (n / 4) % 2 ? -1 : 1;
    const int sign = pfaffian(skew, tolerance, *residual, *fill);
    if (!sign)
      return 1;
    *index = (1 - reference * sign) / 2;
    return 0;
  } catch (...) {
    return -4;
  }
}
