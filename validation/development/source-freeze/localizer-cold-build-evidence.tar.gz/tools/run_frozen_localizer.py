"""Reconstruct and build the archived localizer source outside the working tree."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

from freeze_native_localizer_source import current_state, git
from run_frozen_pfaffian import HERE, NATIVE, ENV, json_new, run, sha

OUT = HERE.parent / 'localizer-frozen-mpi'
SOURCE = OUT / 'source'
BUILD = OUT / 'build'
TARGETS = ['cp2k-bin', 'spectral_localizer_unittest', 'spectral_localizer_flatten_unittest',
           'spectral_localizer_sparse_unittest', 'quadratic_pseudospectrum_unittest',
           'quadratic_dbcsr_unittest']


def prepare():
    if shutil.disk_usage(OUT.parent).free < 4 * 1024**3:
        raise RuntimeError('Less than 4 GiB free for the isolated build')
    before = current_state()
    OUT.mkdir(exist_ok=False)
    SOURCE.mkdir()
    manifest = json.loads((HERE / 'source-reproduction/source-manifest.json').read_text())
    patch = HERE / 'source-reproduction/source.patch'
    assert sha(patch) == manifest['patch_sha256']
    with tempfile.TemporaryDirectory(prefix='localizer-frozen-index-') as temporary:
        env = dict(os.environ, GIT_INDEX_FILE=str(Path(temporary) / 'index'), GIT_NO_LAZY_FETCH='1')
        git('read-tree', manifest['base_commit'], env=env)
        git('apply', '--cached', '--binary', str(patch), env=env)
        actual_tree = git('write-tree', env=env).decode().strip()
        assert actual_tree == manifest['target_tree']
        git('checkout-index', '--all', '--prefix=' + str(SOURCE) + '/', env=env)
        entries = git('ls-files', '--stage', '-z', env=env).decode().split('\0')
    checks = {}
    for entry in entries:
        if not entry:
            continue
        header, name = entry.split('\t', 1)
        mode, expected, stage = header.split()
        assert stage == '0' and mode in ('100644', '100755', '120000')
        path = SOURCE / name
        data = os.readlink(path).encode() if mode == '120000' else path.read_bytes()
        actual = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        assert actual == expected, name
        checks[name] = {'git_blob': actual, 'sha256': hashlib.sha256(data).hexdigest(), 'mode': mode}
    assert current_state() == before
    json_new(OUT / 'source-provenance.json', {'base_commit': manifest['base_commit'],
             'target_commit': manifest['target_commit'], 'target_tree': actual_tree,
             'patch_sha256': sha(patch), 'files': checks, 'working_tree_unchanged': True})
    print(f'Verified {len(checks)} source paths against reconstructed Git tree', flush=True)
    cache = {}
    for line in (NATIVE / 'build-mpi/CMakeCache.txt').read_text().splitlines():
        if line.startswith(('#', '//')) or '=' not in line or ':' not in line.split('=', 1)[0]:
            continue
        keytype, value = line.split('=', 1)
        key, kind = keytype.split(':', 1)
        if kind not in ('INTERNAL', 'STATIC'):
            cache[key] = value
    keys = ['CMAKE_C_COMPILER', 'CMAKE_CXX_COMPILER', 'CMAKE_Fortran_COMPILER',
            'CMAKE_PREFIX_PATH', 'CP2K_BLAS_VENDOR', 'CP2K_BLAS_INTERFACE',
            'CP2K_BLAS_THREADING', 'CP2K_BLAS_LINK_LIBRARIES', 'CP2K_BLAS_INCLUDE_DIRS',
            'CP2K_LAPACK_LINK_LIBRARIES', 'DBCSR_DIR', 'MUMPS_ROOT',
            'MUMPS_INCLUDE_DIR', 'MUMPS_LIBRARIES', 'ShyLU_NodeTacho_DIR']
    options = {key: cache[key] for key in keys}
    options.update({key: value for key, value in cache.items() if key.startswith('CP2K_USE_')})
    options.update(CMAKE_BUILD_TYPE='Release', CMAKE_Fortran_FLAGS='-D__NO_STATM_ACCESS -fcheck=bounds',
                   CMAKE_Fortran_FLAGS_RELEASE='-O1 -g', CMAKE_C_FLAGS_RELEASE='-O1 -g',
                   CMAKE_CXX_FLAGS_RELEASE='-O1 -g', CMAKE_EXPORT_COMPILE_COMMANDS='ON',
                   CP2K_ENABLE_FFTW3_OPENMP_SUPPORT='ON')
    assert options['CP2K_USE_MUMPS'] == options['CP2K_USE_TACHO'] == options['CP2K_USE_MPI'] == 'ON'
    dependencies = {}
    for prefix in [NATIVE / 'build-sparse-deps/tacho-install',
                   NATIVE / 'build-sparse-deps/MUMPS_5.9.1/include',
                   NATIVE / 'build-sparse-deps/MUMPS_5.9.1/lib']:
        for path in sorted(prefix.rglob('*')):
            if path.is_file():
                dependencies[str(path)] = sha(path)
    for key in ('CP2K_BLAS_LINK_LIBRARIES', 'CP2K_LAPACK_LINK_LIBRARIES'):
        for name in options[key].split(';'):
            dependencies[name] = sha(name)
    json_new(OUT / 'build-provenance.json', {'options': options, 'dependencies': dependencies,
             'targets': TARGETS, 'environment': {key: ENV[key] for key in
                 ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'PYTHONDONTWRITEBYTECODE', 'UBSAN_OPTIONS')},
             'scope': 'Cold full CP2K source build with pre-existing numerical dependencies; '
                      'Fortran bounds checking. Dependency libraries are not rebuilt here.'})
    run(['cmake', '-S', SOURCE, '-B', BUILD, '-G', 'Ninja',
         *[f'-D{key}={value}' for key, value in options.items()]], OUT / 'configure.log')


def build():
    provenance = json.loads((OUT / 'build-provenance.json').read_text())
    for name, expected in provenance['dependencies'].items():
        assert sha(name) == expected, name
    run(['cmake', '--build', BUILD, '--target', *TARGETS, '--parallel', '4'], OUT / 'build.log')
    binaries = {}
    for target in TARGETS:
        name = 'cp2k.psmp' if target == 'cp2k-bin' else target + '.psmp'
        path = BUILD / 'bin' / name
        assert path.is_file(), path
        binaries[name] = {'sha256': sha(path), 'bytes': path.stat().st_size}
    libraries = {str(path.relative_to(BUILD)): sha(path)
                 for path in (BUILD / 'src').glob('*.dylib') if not path.is_symlink()}
    assert libraries
    json_new(OUT / 'build-result.json', {'passed': True, 'binaries': binaries, 'libraries': libraries})


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('stage', choices=['prepare', 'build'])
    args = parser.parse_args()
    prepare() if args.stage == 'prepare' else build()
