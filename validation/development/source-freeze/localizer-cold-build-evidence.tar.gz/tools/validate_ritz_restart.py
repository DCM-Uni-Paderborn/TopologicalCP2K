"""Reproduce the premature Ritz restart and build a separately labelled correction."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

from run_frozen_localizer import TARGETS
from run_frozen_pfaffian import ENV, NATIVE, json_new, sha

ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'localizer-frozen-mpi'
OUT = ROOT / 'localizer-ritz-restart'
FILES = ['src/quadratic_pseudospectrum.F', 'src/quadratic_pseudospectrum_unittest.F']


def run(command, log, expected_failure=None, threads=1):
    env = dict(ENV, OMP_NUM_THREADS=str(threads), VECLIB_MAXIMUM_THREADS='1')
    command = [str(item) for item in command]
    print('BEGIN', log.name, flush=True)
    start = time.monotonic()
    with log.open('x') as stream:
        result = subprocess.run(command, cwd=OUT, env=env, stdout=stream, stderr=subprocess.STDOUT)
    text = log.read_text()
    passed = (result.returncode == 0) if expected_failure is None else (
        result.returncode != 0 and expected_failure in text)
    record = {'command': command, 'cwd': str(OUT), 'returncode': result.returncode,
              'seconds': time.monotonic()-start, 'passed': passed,
              'expected_failure': expected_failure, 'log_sha256': sha(log),
              'environment': {key: env[key] for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS',
                              'VECLIB_MAXIMUM_THREADS')}}
    json_new(log.with_suffix('.command.json'), record)
    if not passed:
        raise RuntimeError(f'Unexpected result: {log}')
    print('END', log.name, round(record['seconds'], 2), flush=True)
    return record


def controls():
    OUT.mkdir(exist_ok=False)
    report = []
    for optimization in ('O0', 'O3'):
        for version in ('original', 'fixed'):
            directory = OUT / f'{version}-{optimization}'
            directory.mkdir()
            module = (BASE / 'source' if version == 'original' else NATIVE) / FILES[0]
            obj = directory / 'quadratic.o'
            flags = ['gfortran', '-cpp', '-ffree-form', '-' + optimization, '-g',
                     '-fcheck=all', '-D__HAS_IEEE_EXCEPTIONS', '-J', directory,
                     '-I', directory, '-I', BASE / 'build/src/mod_files']
            run([*flags, '-c', module, '-o', obj], directory / 'compile-module.log')
            executable = directory / 'regression'
            run([*flags, NATIVE / FILES[1], obj, '-L/opt/homebrew/opt/openblas/lib',
                 '-lopenblas', '-o', executable], directory / 'compile-test.log')
            for threads in (1, 2):
                result = run([executable], directory / f'regression-{threads}t.log',
                             None if version == 'fixed' else
                             'Partial residual block did not fill the available space', threads)
                report.append(dict(result, optimization=optimization, version=version, threads=threads))
    for version in ('original', 'fixed'):
        directory = OUT / (version + '-O3')
        executable = directory / 'probe'
        run(['gfortran', '-cpp', '-ffree-form', '-O3', '-g', '-fcheck=all',
             '-I', directory, '-I', BASE / 'build/src/mod_files',
             ROOT / 'periodic_quadratic_probe.F', directory / 'quadratic.o',
             '-L/opt/homebrew/opt/openblas/lib', '-lopenblas', '-o', executable], directory / 'compile-probe.log')
        run([executable], directory / 'probe.log')
    patch = subprocess.check_output(['git', '-C', str(NATIVE), 'diff', '--binary', 'HEAD', '--', *FILES])
    assert patch
    with (OUT / 'fix.patch').open('xb') as stream:
        stream.write(patch)
    json_new(OUT / 'control-result.json', {'passed': True, 'runs': report,
             'original_source_sha256': {name: sha(BASE / 'source' / name) for name in FILES},
             'fixed_source_sha256': {name: sha(NATIVE / name) for name in FILES},
             'fix_patch_sha256': sha(OUT / 'fix.patch'),
             'compiler': subprocess.check_output(['gfortran', '--version']).decode(),
             'scope': 'Two optimization levels and one/two OpenMP threads with all Fortran runtime checks. '
                      'Original module plus new regression must fail specifically at partial-block expansion.'})


def verify_source(directory, files):
    for name, record in files.items():
        path = directory / name
        data = os.readlink(path).encode() if record['mode'] == '120000' else path.read_bytes()
        assert hashlib.sha256(data).hexdigest() == record['sha256'], name


def prepare():
    if shutil.disk_usage(OUT).free < 4 * 1024**3:
        raise RuntimeError('Less than 4 GiB free for separate corrected build')
    control = json.loads((OUT / 'control-result.json').read_text())
    assert control['passed']
    for name, expected in control['fixed_source_sha256'].items():
        assert sha(NATIVE / name) == expected
    provenance = json.loads((BASE / 'source-provenance.json').read_text())
    verify_source(BASE / 'source', provenance['files'])
    source, build = OUT / 'source', OUT / 'build'
    shutil.copytree(BASE / 'source', source, symlinks=True)
    for name in FILES:
        assert sha(source / name) == control['original_source_sha256'][name]
        shutil.copy2(NATIVE / name, source / name)
        provenance['files'][name]['sha256'] = sha(source / name)
        data = (source / name).read_bytes()
        provenance['files'][name]['git_blob'] = hashlib.sha1(
            b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    verify_source(source, provenance['files'])
    json_new(OUT / 'source-provenance.json', {
        'description': 'Frozen source plus the targeted Ritz-restart correction and regression tests.',
        'original_commit': provenance['target_commit'], 'original_tree': provenance['target_tree'],
        'patch_sha256': sha(OUT / 'fix.patch'), 'changed_files': FILES, 'files': provenance['files']})
    configuration = json.loads((BASE / 'build-provenance.json').read_text())
    for name, expected in configuration['dependencies'].items():
        assert sha(name) == expected
    configuration['source_provenance_sha256'] = sha(OUT / 'source-provenance.json')
    json_new(OUT / 'build-provenance.json', configuration)
    run(['cmake', '-S', source, '-B', build, '-G', 'Ninja',
         *[f'-D{key}={value}' for key, value in configuration['options'].items()]], OUT / 'configure.log')


def build(log_name='build.log'):
    configuration = json.loads((OUT / 'build-provenance.json').read_text())
    for name, expected in configuration['dependencies'].items():
        assert sha(name) == expected
    build = OUT / 'build'
    run(['cmake', '--build', build, '--target', *TARGETS, '--parallel', '4'], OUT / log_name)
    binaries = {}
    for target in TARGETS:
        name = 'cp2k.psmp' if target == 'cp2k-bin' else target + '.psmp'
        path = build / 'bin' / name
        binaries[name] = {'sha256': sha(path), 'bytes': path.stat().st_size}
    libraries = {str(path.relative_to(build)): sha(path)
                 for path in (build / 'src').glob('*.dylib') if not path.is_symlink()}
    assert libraries
    json_new(OUT / 'build-result.json', {'passed': True, 'binaries': binaries, 'libraries': libraries})


def apply_gapw():
    original_build = json.loads((OUT / 'build-result.json').read_text())
    for name, record in original_build['binaries'].items():
        assert sha(OUT / 'build/bin' / name) == record['sha256']
    for name, expected in original_build['libraries'].items():
        assert sha(OUT / 'build' / name) == expected
    for ranks in (1, 2):
        run(['mpiexec', '--bind-to', 'none', '-np', str(ranks),
             OUT / 'build/bin/quadratic_pseudospectrum_unittest.psmp'], OUT / f'ritz-only-unit-{ranks}r.log')
    provenance = json.loads((OUT / 'source-provenance.json').read_text())
    verify_source(OUT / 'source', provenance['files'])
    name = 'src/qs_rho_atom_methods.F'
    assert sha(OUT / 'source' / name) == sha(BASE / 'source' / name)
    for filename in ('source-provenance.json', 'build-provenance.json', 'build-result.json'):
        (OUT / filename).rename(OUT / ('ritz-only-' + filename))
    for relative in original_build['libraries']:
        path = OUT / 'build' / relative
        shutil.copy2(path, OUT / ('ritz-only-' + path.name))
    shutil.copy2(NATIVE / name, OUT / 'source' / name)
    data = (OUT / 'source' / name).read_bytes()
    provenance['files'][name]['sha256'] = hashlib.sha256(data).hexdigest()
    provenance['files'][name]['git_blob'] = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    provenance['changed_files'].append(name)
    patch = subprocess.check_output(['git', '-C', str(NATIVE), 'diff', '--binary', 'HEAD', '--', *FILES, name])
    with (OUT / 'combined-fix.patch').open('xb') as stream:
        stream.write(patch)
    provenance['patch_sha256'] = sha(OUT / 'combined-fix.patch')
    provenance['patch_file'] = 'combined-fix.patch'
    provenance['description'] = 'Frozen source plus Ritz partial-block expansion and scalar GAPW slice aliases.'
    verify_source(OUT / 'source', provenance['files'])
    json_new(OUT / 'source-provenance.json', provenance)
    configuration = json.loads((OUT / 'ritz-only-build-provenance.json').read_text())
    configuration['source_provenance_sha256'] = sha(OUT / 'source-provenance.json')
    configuration['previous_build_result'] = 'ritz-only-build-result.json'
    json_new(OUT / 'build-provenance.json', configuration)
    build('build-final.log')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('stage', choices=('controls', 'prepare', 'build', 'apply-gapw'))
    args = parser.parse_args()
    {'controls': controls, 'prepare': prepare, 'build': build, 'apply-gapw': apply_gapw}[args.stage]()
