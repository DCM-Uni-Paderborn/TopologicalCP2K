"""Run the frozen CP2K localizer units and unchanged official regression tests."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

from run_frozen_localizer import BUILD, OUT, SOURCE, TARGETS
from run_frozen_pfaffian import ENV, json_new, sha


def run(command, label, threads=1):
    env = dict(ENV, OMP_NUM_THREADS=str(threads), OPENBLAS_NUM_THREADS='1',
               VECLIB_MAXIMUM_THREADS='1', CP2K_DATA_DIR=str(SOURCE / 'data'))
    log = OUT / (label + '.log')
    command = [str(item) for item in command]
    environment = {key: env[key] for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS',
                    'VECLIB_MAXIMUM_THREADS', 'CP2K_DATA_DIR')}
    record = OUT / (label + '.command.json')
    if record.exists():
        result = json.loads(record.read_text())
        assert result['command'] == command and result['environment'] == environment
        assert result['log_sha256'] == sha(log)
        print('REUSE', label, 'exit', result['returncode'], flush=True)
    else:
        print('BEGIN', label, flush=True)
        start = time.monotonic()
        with log.open('x') as stream:
            process = subprocess.run(command, env=env, cwd=OUT,
                                     stdout=stream, stderr=subprocess.STDOUT)
        result = {'command': command, 'returncode': process.returncode,
                  'seconds': time.monotonic()-start, 'log': log.name, 'log_sha256': sha(log),
                  'environment': environment}
        json_new(record, result)
    result['passed'] = (result['returncode'] == 0 and not re.search(
        r'Fortran runtime error|ERROR STOP|runtime error:', log.read_text()))
    print('END', label, round(result['seconds'], 2), 'passed', result['passed'], flush=True)
    return result


def main():
    global OUT, SOURCE, BUILD
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=OUT)
    args = parser.parse_args()
    OUT = args.root.resolve()
    SOURCE, BUILD = OUT / 'source', OUT / 'build'
    build = json.loads((OUT / 'build-result.json').read_text())
    assert build['passed']
    for name, value in build['binaries'].items():
        assert sha(BUILD / 'bin' / name) == value['sha256']
    for name, value in build['libraries'].items():
        assert sha(BUILD / name) == value
    results = []
    version = run([BUILD / 'bin/cp2k.psmp', '--version'], 'version')
    assert version['passed']
    flags = (OUT / 'version.log').read_text().split('cp2kflags:')[1].splitlines()[0].split()
    assert {'mumps', 'tacho', 'parallel', 'spglib', 'libint'} <= set(flags), flags
    for ranks in (1, 2):
        for target in TARGETS[1:]:
            command = ['mpiexec', '--bind-to', 'none', '-np', str(ranks), BUILD / 'bin' / (target + '.psmp')]
            if target == 'spectral_localizer_sparse_unittest':
                command.append('5')
            result = run(command, f'{target}-{ranks}r1t')
            if target == 'spectral_localizer_sparse_unittest':
                text = (OUT / result['log']).read_text()
                assert 'Sparse Pfaffian polynomial/permutation/scale/component tests passed' in text
                assert 'AII spin-mixed' in text and 'AII atomic reference' in text
            results.append(result)
    for ranks, threads in ((4, 1), (2, 2)):
        results.append(run(['mpiexec', '--bind-to', 'none', '-np', str(ranks),
                            BUILD / 'bin/spectral_localizer_sparse_unittest.psmp', '7'],
                           f'spectral_localizer_sparse_unittest-{ranks}r{threads}t', threads))
    regression = []
    expression = r'QS/regtest-(spectral-localizer(|-mumps|-tacho)|quadratic-pseudospectrum(|-mumps))'
    for ranks, threads in ((2, 1), (1, 2)):
        label = f'regtests-{ranks}r{threads}t'
        regression.append(run([sys.executable, '-B', SOURCE / 'tests/do_regtest.py',
                               '--mpiranks', str(ranks), '--ompthreads', str(threads),
                               '--maxtasks', '1', '--timeout', '180', '--skip_unittests',
                               '--mpiexec', 'mpiexec --bind-to none -np {N}',
                               '--restrictdir', expression, '--workbasedir', OUT / label,
                               '--cp2kdatadir', SOURCE / 'data', BUILD / 'bin', 'psmp'], label, threads))
    unchanged = json.loads((OUT / 'source-provenance.json').read_text())['files']
    for name, record in unchanged.items():
        path = SOURCE / name
        data = os.readlink(path).encode() if record['mode'] == '120000' else path.read_bytes()
        assert hashlib.sha256(data).hexdigest() == record['sha256'], name
    passed = all(result['passed'] for result in results + regression)
    json_new(OUT / 'validation-result.json', {'passed': passed, 'version': version,
             'unit_runs': results, 'regression_runs': regression,
             'source_paths_verified_unchanged': len(unchanged),
             'scope': 'Single-machine MPI/OpenMP build and tests at the frozen source. '
                      'This does not establish multi-node scaling or spatially distributed Pfaffian factors.'})
    if not passed:
        raise SystemExit('Validation contains failures; all completed runs have been preserved.')


if __name__ == '__main__':
    main()
