"""Compare GAPW startup on the archived cold build and existing executable."""

import argparse
import json
from pathlib import Path
import shlex
import shutil
import subprocess
import time

from run_frozen_pfaffian import ENV, NATIVE, json_new, sha

ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'localizer-frozen-mpi'
OUT = ROOT / 'gapw-build-diagnosis'


def run(command, directory, env=None):
    start = time.monotonic()
    environment = dict(ENV, VECLIB_MAXIMUM_THREADS='1',
                       CP2K_DATA_DIR=str(BASE / 'source/data'), **(env or {}))
    with (directory / 'run.log').open('x') as log:
        result = subprocess.run([str(arg) for arg in command], cwd=directory, env=environment,
                                stdout=log, stderr=subprocess.STDOUT, timeout=120)
    record = {'command': [str(arg) for arg in command], 'returncode': result.returncode,
              'seconds': time.monotonic()-start, 'log_sha256': sha(directory / 'run.log'),
              'environment': {key: value for key, value in environment.items()
                              if key.startswith(('OMP_', 'OPENBLAS_', 'VECLIB_', 'CP2K_', 'DYLD_'))}}
    json_new(directory / 'command.json', record)
    print(directory.name, result.returncode, flush=True)


def controls():
    OUT.mkdir(exist_ok=False)
    for version, executable in [('existing', NATIVE / 'build-mpi/bin/cp2k.psmp'),
                                ('frozen', BASE / 'build/bin/cp2k.psmp')]:
        for ranks in (1, 2):
            directory = OUT / f'{version}-{ranks}r1t'
            shutil.copytree(BASE / 'source/tests/QS/regtest-spectral-localizer', directory)
            run(['mpiexec', '--bind-to', 'none', '-np', str(ranks), executable, 'h2-gapw.inp'], directory)
    compile_commands = json.loads((BASE / 'build/compile_commands.json').read_text())
    selected = [record for record in compile_commands
                if Path(record['file']).name in ('qs_rho_atom_methods.F', 'qs_oce_methods.F', 'sap_kind_types.F')]
    json_new(OUT / 'compile-commands.json', selected)
    link_commands = subprocess.check_output(['ninja', '-C', str(BASE / 'build'), '-t', 'commands', 'cp2k-bin']).decode()
    selected_links = [line for line in link_commands.splitlines()
                      if ' -dynamiclib ' in line and 'libcp2k.2026.2.dylib' in line]
    assert len(selected_links) == 1
    arguments = shlex.split(selected_links[0])
    assert arguments[:2] == [':', '&&']
    arguments = arguments[2:arguments.index('&&', 2)]
    json_new(OUT / 'link-command.json', arguments)


def variants():
    commands = json.loads((OUT / 'compile-commands.json').read_text())
    linker = json.loads((OUT / 'link-command.json').read_text())
    variants = [
            ('qs_oce_methods', ['-O0'], 'oce-O0'),
            ('qs_rho_atom_methods', ['-O0'], 'rho-O0'),
            ('qs_oce_methods', ['-fcheck=no-bounds'], 'oce-no-bounds'),
            ('qs_rho_atom_methods', ['-fcheck=no-bounds'], 'rho-no-bounds'),
            ('sap_kind_types', ['-O0'], 'sap-O0')]
    for module, flags, label in variants:
        directory = OUT / label
        directory.mkdir()
        (directory / 'mod').mkdir()
        record = next(item for item in commands if Path(item['file']).stem == module)
        arguments = shlex.split(record['command'])
        arguments = [arg for arg in arguments if not arg.startswith(('-D', '-J'))]
        obj = directory / (module + '.o')
        arguments[arguments.index('-c') + 1] = str(BASE / f'build/src/CMakeFiles/cp2k.dir/{module}.F-pp.f')
        arguments[arguments.index('-o') + 1] = str(obj)
        arguments += ['-fpreprocessed', '-J' + str(directory / 'mod'), *flags]
        with (directory / 'compile.log').open('x') as log:
            subprocess.run(arguments, cwd=BASE / 'build', stdout=log, stderr=subprocess.STDOUT, check=True)
        link = list(linker)
        old_object = f'src/CMakeFiles/cp2k.dir/{module}.F.o'
        assert link.count(old_object) == 1
        link[link.index(old_object)] = str(obj)
        library = directory / 'libcp2k.2026.2.dylib'
        link[link.index('-o') + 1] = str(library)
        with (directory / 'link.log').open('x') as log:
            subprocess.run(link, cwd=BASE / 'build', stdout=log, stderr=subprocess.STDOUT, check=True)
        json_new(directory / 'build.json', {'compile': arguments, 'link': link, 'sha256': sha(library)})
        case = directory / 'h2-gapw'
        shutil.copytree(BASE / 'source/tests/QS/regtest-spectral-localizer', case)
        run([BASE / 'build/bin/cp2k.psmp', 'h2-gapw.inp'], case,
            {'DYLD_LIBRARY_PATH': str(directory), 'DYLD_PRINT_LIBRARIES': '1'})
        assert str(library) in (case / 'run.log').read_text()


def trace(label='trace2'):
    commands = json.loads((OUT / 'compile-commands.json').read_text())
    link = json.loads((OUT / 'link-command.json').read_text())
    directory = OUT / label
    directory.mkdir()
    (directory / 'mod').mkdir()
    for module in ('qs_oce_methods', 'qs_rho_atom_methods'):
        record = next(item for item in commands if Path(item['file']).stem == module)
        arguments = shlex.split(record['command'])
        arguments = [arg for arg in arguments if not arg.startswith('-J')]
        obj = directory / (module + '.o')
        arguments[arguments.index('-c') + 1] = str(OUT / 'trace-source' / (module + '.F'))
        arguments[arguments.index('-o') + 1] = str(obj)
        arguments += ['-J' + str(directory / 'mod'), '-O0']
        with (directory / (module + '.log')).open('x') as log:
            subprocess.run(arguments, cwd=BASE / 'build', stdout=log, stderr=subprocess.STDOUT, check=True)
        old_object = f'src/CMakeFiles/cp2k.dir/{module}.F.o'
        assert link.count(old_object) == 1
        link[link.index(old_object)] = str(obj)
    library = directory / 'libcp2k.2026.2.dylib'
    link[link.index('-o') + 1] = str(library)
    with (directory / 'link.log').open('x') as log:
        subprocess.run(link, cwd=BASE / 'build', stdout=log, stderr=subprocess.STDOUT, check=True)
    case = directory / 'h2-gapw'
    shutil.copytree(BASE / 'source/tests/QS/regtest-spectral-localizer', case)
    run([BASE / 'build/bin/cp2k.psmp', 'h2-gapw.inp'], case,
        {'DYLD_LIBRARY_PATH': str(directory), 'DYLD_PRINT_LIBRARIES': '1'})


def alias():
    directory = OUT / 'scalar-alias'
    directory.mkdir()
    (directory / 'mod').mkdir()
    module = 'qs_rho_atom_methods'
    source = directory / (module + '.F')
    shutil.copy2(NATIVE / 'src' / source.name, source)
    records = json.loads((OUT / 'compile-commands.json').read_text())
    record = next(item for item in records if Path(item['file']).stem == module)
    arguments = [arg for arg in shlex.split(record['command']) if not arg.startswith('-J')]
    arguments[arguments.index('-c') + 1] = str(source)
    obj = directory / (module + '.o')
    arguments[arguments.index('-o') + 1] = str(obj)
    arguments += ['-J' + str(directory / 'mod')]
    with (directory / 'compile.log').open('x') as log:
        subprocess.run(arguments, cwd=BASE / 'build', stdout=log, stderr=subprocess.STDOUT, check=True)
    link = json.loads((OUT / 'link-command.json').read_text())
    link[link.index(f'src/CMakeFiles/cp2k.dir/{module}.F.o')] = str(obj)
    library = directory / 'libcp2k.2026.2.dylib'
    link[link.index('-o') + 1] = str(library)
    with (directory / 'link.log').open('x') as log:
        subprocess.run(link, cwd=BASE / 'build', stdout=log, stderr=subprocess.STDOUT, check=True)
    json_new(directory / 'build.json', {'compile': arguments, 'link': link,
             'source_sha256': sha(source), 'library_sha256': sha(library)})
    for ranks, threads in ((1, 1), (2, 1), (1, 2), (2, 2)):
        case = directory / f'h2-gapw-{ranks}r{threads}t'
        shutil.copytree(BASE / 'source/tests/QS/regtest-spectral-localizer', case)
        run(['mpiexec', '--bind-to', 'none', '-np', str(ranks),
             BASE / 'build/bin/cp2k.psmp', 'h2-gapw.inp'], case,
            {'DYLD_LIBRARY_PATH': str(directory), 'DYLD_PRINT_LIBRARIES': '1', 'OMP_NUM_THREADS': str(threads)})
        assert json.loads((case / 'command.json').read_text())['returncode'] == 0
        assert str(library) in (case / 'run.log').read_text()


def pointer_matrix():
    directory = OUT / 'pointer-matrix'
    directory.mkdir()
    source = ROOT / 'gapw_pointer_probe.F'
    results = []
    for optimization in ('O0', 'O3'):
        for openmp in (False, True):
            for use_alias in (False, True):
                label = f'{optimization}-omp{int(openmp)}-alias{int(use_alias)}'
                executable = directory / label
                args = ['gfortran', '-cpp', '-ffree-form', '-' + optimization, '-g', '-fcheck=all']
                args += ['-fopenmp'] if openmp else []
                args += ['-D__SLICE_ALIAS'] if use_alias else []
                args += [str(source), '-o', str(executable)]
                subprocess.run(args, check=True)
                for threads in ((1, 2, 4) if openmp else (1,)):
                    case = directory / (label + f'-{threads}t')
                    case.mkdir()
                    run([executable], case, {'OMP_NUM_THREADS': str(threads)})
                    result = json.loads((case / 'command.json').read_text())
                    results.append(dict(result, optimization=optimization, openmp=openmp,
                                        use_alias=use_alias, threads=threads))
                    if use_alias:
                        assert result['returncode'] == 0
    assert any(not row['use_alias'] and row['openmp'] and row['returncode'] for row in results)
    json_new(directory / 'result.json', {'source_sha256': sha(source), 'runs': results,
             'all_alias_variants_passed': True,
             'compiler': subprocess.check_output(['gfortran', '--version']).decode()})


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('stage', choices=['controls', 'variants', 'trace', 'alias', 'pointer-matrix'])
    args = parser.parse_args()
    {'controls': controls, 'variants': variants, 'trace': trace,
     'alias': alias, 'pointer-matrix': pointer_matrix}[args.stage]()
