"""Freeze the complete archived native CP2K tree through a verified source patch."""

import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile

from run_frozen_pfaffian import DEVELOPMENT, HERE, NATIVE, sha

BASE = '92574dc7b41b039d88f32e23bbd59a71b0eb8836'


def git(*args, data=None, env=None):
    return subprocess.check_output(['git', '-C', str(NATIVE), *args], input=data, env=env)


def current_state():
    return {'head': git('rev-parse', 'HEAD').decode().strip(),
            'status': git('status', '--porcelain=v1', '-z').hex(),
            'diff_sha256': hashlib.sha256(git('diff', '--binary', 'HEAD')).hexdigest()}


def main():
    before = current_state()
    index = json.loads((DEVELOPMENT / 'pfaffian-native/index.json').read_text())
    target = index['source_commit']
    tree = git('rev-parse', target + '^{tree}').decode().strip()
    checks = []
    for path, expected in index['source_sha256'].items():
        committed = hashlib.sha256(git('show', target + ':' + path)).hexdigest()
        archived = sha(HERE / 'source' / path)
        assert committed == archived == expected, path
        checks.append({'path': path, 'sha256': expected})
    patch = git('diff', '--binary', '--full-index', BASE, target)
    license_text = git('show', target + ':LICENSE')
    with tempfile.TemporaryDirectory(prefix='localizer-source-check-') as temporary:
        env = dict(os.environ, GIT_INDEX_FILE=str(Path(temporary) / 'index'))
        git('read-tree', BASE, env=env)
        git('apply', '--cached', '--binary', '-', data=patch, env=env)
        actual_tree = git('write-tree', env=env).decode().strip()
        assert actual_tree == tree
    assert current_state() == before
    output = HERE / 'source-reproduction'
    output.mkdir(exist_ok=False)
    (output / 'source.patch').write_bytes(patch)
    (output / 'CP2K-LICENSE').write_bytes(license_text)
    report = {'base_commit': BASE, 'target_commit': target, 'target_tree': tree,
              'reconstructed_tree': actual_tree, 'exact_tree_reconstruction': True,
              'patch_sha256': hashlib.sha256(patch).hexdigest(),
              'patch_bytes': len(patch), 'license_sha256': hashlib.sha256(license_text).hexdigest(),
              'archived_source_files_verified': checks, 'current_checkout_unchanged': True,
              'scope': 'Exact source-tree reconstruction. Only the standalone native C++ adapter was rebuilt '
                       'in this validation, not every Fortran component in the reconstructed tree.'}
    (output / 'source-manifest.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
