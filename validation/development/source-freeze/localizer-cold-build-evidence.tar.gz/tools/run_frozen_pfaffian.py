"""Rebuild and test the archived native Pfaffian adapter, not the current tree."""

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time

ROOT = Path('/Users/tkuehne/paper-repositories/TopologicalCP2K')
NATIVE = Path('/Users/tkuehne/cp2k-spectral-localizer')
HERE = Path(__file__).resolve().parent / 'pfaffian-frozen-build'
DEVELOPMENT = ROOT / 'validation/development'
TACHO = NATIVE / 'build-sparse-deps/tacho-install'
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1',
           OPENBLAS_NUM_THREADS='1', UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')


def sha(path):
    with Path(path).open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args]).decode().strip()


def json_new(path, value):
    with Path(path).open('x') as handle:
        json.dump(value, handle, indent=2)
        handle.write('\n')


def source_guard():
    state = {'head': git('rev-parse', 'HEAD'), 'status': git('status', '--porcelain')}
    assert state == {'head': '3b27a33dbf1cef25752ae01bb1239482de8e3e90', 'status': ''}
    return state


def extract_verified(archive_path, expected, destination):
    assert sha(archive_path) == expected
    with tarfile.open(archive_path) as archive:
        manifest = json.load(archive.extractfile('manifest.json'))
        names = set()
        for member in archive:
            if not member.isfile():
                raise ValueError(f'Nonregular archive entry: {member.name}')
            name = PurePosixPath(member.name)
            assert not name.is_absolute() and '..' not in name.parts
            assert member.name not in names
            names.add(member.name)
            data = archive.extractfile(member).read()
            if member.name != 'manifest.json':
                record = manifest['files'][member.name]
                assert len(data) == record['bytes']
                assert hashlib.sha256(data).hexdigest() == record['sha256']
            path = destination / member.name
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open('xb') as handle:
                handle.write(data)
        assert names == set(manifest['files']) | {'manifest.json'}
    return manifest


def run(command, log, cwd=None):
    print('BEGIN', log.name, flush=True)
    start = time.monotonic()
    with log.open('x') as handle:
        result = subprocess.run([str(item) for item in command], cwd=cwd, env=ENV,
                                stdout=handle, stderr=subprocess.STDOUT)
    record = {'command': [str(item) for item in command], 'cwd': str(cwd) if cwd else None,
              'returncode': result.returncode, 'seconds': time.monotonic() - start,
              'log': log.name, 'log_sha256': sha(log)}
    json_new(log.with_suffix('.command.json'), record)
    if result.returncode:
        raise RuntimeError(f'Command failed, inspect {log}')
    print('END', log.name, round(record['seconds'], 2), 'seconds', flush=True)
    return record


def build():
    HERE.mkdir(exist_ok=False)
    index = json.loads((DEVELOPMENT / 'pfaffian-native/index.json').read_text())
    source = HERE / 'source'
    manifest = extract_verified(DEVELOPMENT / 'pfaffian-native' / index['archive']['file'],
                                index['archive']['sha256'], source)
    assert all(sha(source / name) == expected for name, expected in index['source_sha256'].items())
    committed = subprocess.check_output(['git', '-C', str(NATIVE), 'show',
                                        index['source_commit'] + ':src/tacho_c_api.cpp'])
    assert hashlib.sha256(committed).hexdigest() == index['source_sha256']['src/tacho_c_api.cpp']
    dependencies = []
    for path in sorted(TACHO.rglob('*')):
        if path.is_file():
            dependencies.append({'path': str(path.relative_to(TACHO)), 'sha256': sha(path),
                                 'bytes': path.stat().st_size})
    json_new(HERE / 'source-provenance.json', {
        'manuscript': source_guard(), 'archive_sha256': index['archive']['sha256'],
        'source_commit': index['source_commit'], 'source_sha256': index['source_sha256'],
        'verified_payload_files': len(manifest['files']),
        'standalone_cmake_sha256': sha(source / 'build-serial/pfaffian-stability/native-check/CMakeLists.txt'),
        'dependency_prefix': str(TACHO), 'dependency_files': dependencies,
        'scope': 'Cold rebuild of archived native C++ with existing fingerprinted Tacho/Boost/BLAS dependencies. '
                 'Not a new full CP2K build, not dependency sanitizer coverage, not an SCF rerun.',
    })
    run(['cmake', '-S', source / 'build-serial/pfaffian-stability/native-check', '-B', HERE / 'build',
         '-DCMAKE_CXX_COMPILER=/opt/homebrew/bin/g++-16',
         '-DShyLU_NodeTacho_DIR=' + str(TACHO / 'lib/cmake/ShyLU_NodeTacho'),
         '-DBoost_DIR=/opt/homebrew/lib/cmake/Boost-1.90.0', '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'],
        HERE / 'configure.log')
    run(['cmake', '--build', HERE / 'build', '--parallel', '2'], HERE / 'build.log')
    library = HERE / 'build/libpfaffian_native_checked.dylib'
    linked = subprocess.check_output(['otool', '-L', str(library)]).decode()
    symbols = subprocess.check_output(['nm', '-g', str(library)]).decode()
    checks = sorted({line.split()[-1] for line in symbols.splitlines() if 'ubsan_handle' in line})
    assert checks
    json_new(HERE / 'build-result.json', {
        'library': str(library), 'sha256': sha(library), 'linked_libraries': linked,
        'runtime_check_symbols': checks, 'compiler': subprocess.check_output(['/opt/homebrew/bin/g++-16', '--version']).decode(),
        'cmake_cache_sha256': sha(HERE / 'build/CMakeCache.txt'),
        'compile_commands_sha256': sha(HERE / 'build/compile_commands.json'),
    })


def library_guard():
    record = json.loads((HERE / 'build-result.json').read_text())
    library = Path(record['library'])
    assert sha(library) == record['sha256']
    provenance = json.loads((HERE / 'source-provenance.json').read_text())
    for entry in provenance['dependency_files']:
        assert sha(TACHO / entry['path']) == entry['sha256']
    for path, expected in provenance['source_sha256'].items():
        assert sha(HERE / 'source' / path) == expected
    return library


def synthetic():
    library = library_guard()
    work = HERE / 'source/build-serial/pfaffian-stability'
    summary = []
    for label, script, total, resolved, singular in (
        ('independent', 'validate_adaptive.py', 600, 468, 132),
        ('stress', 'validate_delayed.py', 636, 336, 300),
    ):
        output = HERE / (label + '.json')
        run([sys.executable, work / script, library, output], HERE / (label + '.log'))
        result = json.loads(output.read_text())
        expected = dict(queries=total, resolved=resolved, singular_queries=singular,
                        nonsingular_unresolved=0, wrong_accepted_signs=0, singular_accepted=0)
        assert result['summary'] == expected
        original = json.loads((HERE / 'source/build-mpi' / f'delayed-native-verified-{label}.json').read_text())
        assert len(result['results']) == total
        for old, new in zip(original['results'], result['results'], strict=True):
            for key in ('case', 'scale', 'expected', 'sign', 'singular'):
                assert old[key] == new[key]
            if not new['singular']:
                assert new['residual'] <= 1e-10
        assert not re.search(r'runtime error:|Assertion.*failed', (HERE / (label + '.log')).read_text())
        summary.append(expected)
    run([sys.executable, work / 'check_skew_pattern.py', library, '32'], HERE / 'roundoff-chain.log')
    pattern = json.loads((HERE / 'roundoff-chain.log').read_text())
    original = json.loads((HERE / 'source/build-mpi/delayed-native-pattern-chain-after.json').read_text())
    assert len(pattern) == len(original) == 930
    for new, old in zip(pattern, original, strict=True):
        assert (new['i'], new['j'], new['status'], new['sign']) == (old['i'], old['j'], 0, 1)
        assert new['residual'] <= 1e-10
    json_new(HERE / 'synthetic-comparison.json', {'passed': True, 'summary': summary,
             'roundoff_patterns': len(pattern), 'maximum_roundoff_residual': max(row['residual'] for row in pattern),
             'environment': {key: ENV[key] for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'UBSAN_OPTIONS')},
             'python': sys.version})


def material(label):
    library = library_guard()
    index = json.loads((DEVELOPMENT / 'stanene-convergence/index.json').read_text())
    case = next(row for row in index['cases'] if row['label'] == label)
    old = json.loads((HERE / 'source/build-mpi/delayed-native-materials-verified' / (label + '.json')).read_text())
    if case['new_export']:
        archive_path = DEVELOPMENT / 'stanene-convergence' / case['archive']
        expected = next(item['sha256'] for item in index['archives'] if item['file'] == case['archive'])
        prefix = ''
    else:
        archive_path = DEVELOPMENT / 'stanene-flattening.tar.gz'
        expected = index['previous_reference_sha256']
        prefix = case['directory'] + '/'
    assert sha(archive_path) == expected
    # Material exports are extracted one case at a time to bound temporary disk use.
    with tempfile.TemporaryDirectory(prefix='pfaffian-material-') as temporary:
        work = Path(temporary)
        with tarfile.open(archive_path) as archive:
            for name, expected_file in old['inputs'].items():
                data = archive.extractfile(prefix + name).read()
                assert hashlib.sha256(data).hexdigest() == expected_file
                assert PurePosixPath(name).name == name
                (work / name).write_bytes(data)
        queries = old['queries']
        output = HERE / (label + '.json')
        helper = HERE / 'source/build-serial/check_sparse_bloch_localizer.py'
        assert sha(helper) == old['script_sha256']
        command = [sys.executable, helper, work, '--library', library,
                   '--energy', str(queries[0]['energy']), '--scale', str(queries[0]['flatten_scale']),
                   '--eta', *(str(row['eta']) for row in queries), '--output', output]
        if label == 'mesh3':
            command.append('--dense-check')
        run(command, HERE / (label + '.log'))
        new = json.loads(output.read_text())
        assert old['inputs'] == new['inputs']
        comparisons = []
        for a, b in zip(queries, new['queries'], strict=True):
            for key in ('energy', 'eta', 'flatten_scale', 'nu'):
                assert a[key] == b[key], (label, key)
            gap_error = abs(a['gap'] - b['gap'])
            assert gap_error < 1e-10
            assert b['eigen_residual'] < 1e-8 and b['factor_residual'] <= 1e-10
            assert len(b['factor_attempts']) == 1
            comparisons.append({'eta': b['eta'], 'nu': b['nu'], 'gap_error': gap_error,
                                'factor_residual': b['factor_residual'], 'eigen_residual': b['eigen_residual']})
        assert not re.search(r'runtime error:|Assertion.*failed', (HERE / (label + '.log')).read_text())
        json_new(HERE / (label + '-comparison.json'), {'passed': True, 'archive_sha256': expected,
                 'source_library_sha256': sha(library), 'queries': comparisons})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('stage', choices=['build', 'synthetic', 'material'])
    parser.add_argument('--case')
    args = parser.parse_args()
    source_guard()
    if args.stage == 'build':
        build()
    elif args.stage == 'synthetic':
        synthetic()
    elif args.case == 'all':
        index = json.loads((DEVELOPMENT / 'stanene-convergence/index.json').read_text())
        for case in index['cases']:
            material(case['label'])
        comparisons = [json.loads((HERE / (case['label'] + '-comparison.json')).read_text())
                       for case in index['cases']]
        queries = [row for report in comparisons for row in report['queries']]
        assert all(report['passed'] for report in comparisons) and len(queries) == 33
        json_new(HERE / 'material-comparison.json', {'passed': True, 'materials': len(comparisons),
                 'queries': len(queries), 'max_gap_error': max(row['gap_error'] for row in queries),
                 'max_factor_residual': max(row['factor_residual'] for row in queries),
                 'max_eigen_residual': max(row['eigen_residual'] for row in queries)})
    elif args.case:
        material(args.case)
    else:
        parser.error('--case is required for material stage')
    source_guard()


if __name__ == '__main__':
    main()
