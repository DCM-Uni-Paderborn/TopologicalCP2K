"""Negative controls for the portable cold-build evidence verifier."""

import hashlib
import io
import json
from pathlib import Path
import tarfile
import tempfile

from verify_localizer_build import verify

ROOT = Path(__file__).resolve().parent / 'localizer-ritz-restart'
ARCHIVE = ROOT / 'localizer-cold-build-evidence.tar.gz'


def write_bundle(payload, path):
    manifest = {'files': {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                           for name, data in payload.items()}}
    entries = dict(payload, **{'manifest.json': json.dumps(manifest).encode()})
    with tarfile.open(path, 'w:gz') as archive:
        for name, data in entries.items():
            record = tarfile.TarInfo(name)
            record.size = len(data)
            archive.addfile(record, io.BytesIO(data))


def modify_json(payload, name, change):
    data = json.loads(payload[name])
    change(data)
    payload[name] = json.dumps(data).encode()


def fail_runtime(payload):
    name = 'regtests-2r1t.log'
    data = payload['corrected/' + name] + b'\nERROR STOP injected negative control\n'
    payload['corrected/' + name] = data
    modify_json(payload, 'corrected/validation-result.json',
                lambda report: report['regression_runs'][0].update(log_sha256=hashlib.sha256(data).hexdigest()))


def main():
    verify(ARCHIVE)
    with tarfile.open(ARCHIVE) as archive:
        original = {item.name: archive.extractfile(item).read()
                    for item in archive if item.name != 'manifest.json'}
    controls = [
        ('false-success', lambda p: modify_json(p, 'corrected/validation-result.json', lambda d: d.update(passed=False))),
        ('failed-unit', lambda p: modify_json(p, 'corrected/validation-result.json',
            lambda d: d['unit_runs'][0].update(returncode=1))),
        ('duplicated-unit', lambda p: modify_json(p, 'corrected/validation-result.json',
            lambda d: d['unit_runs'].__setitem__(1, d['unit_runs'][0]))),
        ('wrong-mpi-size', lambda p: modify_json(p, 'corrected/validation-result.json',
            lambda d: d['regression_runs'][0]['command'].__setitem__(d['regression_runs'][0]['command'].index('--mpiranks') + 1, '1'))),
        ('wrong-openmp-size', lambda p: modify_json(p, 'corrected/validation-result.json',
            lambda d: d['regression_runs'][1]['environment'].update(OMP_NUM_THREADS='1'))),
        ('runtime-in-successful-log', fail_runtime),
        ('unrelated-source-change', lambda p: modify_json(p, 'corrected/source-provenance.json',
            lambda d: d['files']['src/kpoint_types.F'].update(sha256='0'*64))),
        ('replaced-fixed-source', lambda p: p.update({'corrected/files/src/qs_rho_atom_methods.F': b'changed'})),
        ('lost-original-failure', lambda p: modify_json(p, 'original/validation-result.json', lambda d: d.update(passed=True))),
        ('lost-ritz-negative-control', lambda p: modify_json(p, 'corrected/control-result.json',
            lambda d: d['runs'][0].update(returncode=0))),
        ('lost-pointer-negative-control', lambda p: modify_json(p, 'pointer/result.json',
            lambda d: d['runs'][0].update(returncode=0))),
        ('replaced-pointer-log', lambda p: p.update({'pointer/O0-omp0-alias1-1t/run.log': b'replaced'})),
        ('duplicated-pointer-configuration', lambda p: modify_json(p, 'pointer/result.json',
            lambda d: d['runs'].__setitem__(1, d['runs'][3]))),
    ]
    results = []
    with tempfile.TemporaryDirectory(prefix='localizer-evidence-controls-') as temporary:
        path = Path(temporary) / 'mutated.tar.gz'
        for name, mutate in controls:
            payload = dict(original)
            mutate(payload)
            write_bundle(payload, path)
            try:
                verify(path)
            except (AssertionError, KeyError, ValueError):
                results.append({'case': name, 'rejected': True})
            else:
                raise RuntimeError(f'Verifier accepted {name}')
    report = {'archive_sha256': hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
              'baseline_passed': True, 'all_negative_controls_rejected': True, 'controls': results}
    with (ROOT / 'verifier-controls.json').open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
