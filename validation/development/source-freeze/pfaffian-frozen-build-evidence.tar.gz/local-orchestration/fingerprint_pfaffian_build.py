"""Record the actual C++ dependency closure without bundling third-party headers."""

from collections import Counter
import importlib.metadata
import json
from pathlib import Path
import shlex
import subprocess

from run_frozen_pfaffian import HERE, json_new, library_guard, sha


def main():
    library = library_guard()
    commands = json.loads((HERE / 'build/compile_commands.json').read_text())
    assert len(commands) == 1
    command = commands[0]
    depfile = Path(command['directory']) / (command['output'] + '.d')
    text = depfile.read_text().replace('\\\n', ' ')
    target, separator, body = text.partition(': ')
    assert separator and shlex.split(target) == [command['output']]
    inputs = []
    for name in sorted(set(shlex.split(body))):
        path = Path(name)
        assert path.is_absolute() and path.is_file(), path
        group = ('tacho-kokkos' if '/tacho-install/' in name else
                 'boost' if '/boost/' in name else 'compiler' if '/gcc/' in name else
                 'sdk' if '/MacOSX.sdk/' in name else 'native')
        inputs.append({'path': name, 'resolved_path': str(path.resolve()),
                       'sha256': sha(path), 'bytes': path.stat().st_size, 'group': group})
    linked = []
    identity = subprocess.check_output(['otool', '-D', str(library)]).decode().splitlines()[1].strip()
    for line in subprocess.check_output(['otool', '-L', str(library)]).decode().splitlines()[1:]:
        name = line.strip().split(' (compatibility version ', 1)[0]
        path = Path(name)
        if name == identity:
            continue
        record = {'path': name}
        if path.is_file():
            record.update(resolved_path=str(path.resolve()), sha256=sha(path), bytes=path.stat().st_size)
        else:
            assert name.startswith('/usr/lib/'), name
            record['scope'] = 'macOS shared-cache library; identified by operating-system build'
        linked.append(record)
    report = {'library_sha256': sha(library), 'depfile_sha256': sha(depfile),
              'compiled_inputs': inputs, 'counts': dict(Counter(row['group'] for row in inputs)),
              'linked_libraries': linked, 'operating_system': subprocess.check_output(['sw_vers']).decode(),
              'python_packages': {name: importlib.metadata.version(name) for name in ('numpy', 'scipy')},
              'scope': 'Hashes of actual compiler dependencies and direct linked libraries. '
                       'Existing dependencies are fingerprinted, not rebuilt or sanitizer-instrumented.'}
    json_new(HERE / 'dependency-closure.json', report)
    print(json.dumps(report['counts'], indent=2))


if __name__ == '__main__':
    main()
