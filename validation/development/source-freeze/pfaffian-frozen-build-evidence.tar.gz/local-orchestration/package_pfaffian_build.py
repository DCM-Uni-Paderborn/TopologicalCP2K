"""Package the completed standalone native Pfaffian reproduction evidence."""

import gzip
import io
import json
from pathlib import Path
import tarfile

from run_frozen_pfaffian import HERE, DEVELOPMENT, sha, json_new
from verify_pfaffian_bundle import unpack, verify


def main():
    archive_path = HERE / 'pfaffian-frozen-build-evidence.tar.gz'
    if archive_path.exists():
        raise FileExistsError(archive_path)
    sources = {}
    for path in sorted(HERE.iterdir()):
        if path.is_file() and path.suffix in ('.log', '.json'):
            sources['native/' + path.name] = path
    for name in ('compile_commands.json', 'CMakeCache.txt'):
        sources['native/' + name] = HERE / 'build' / name
    sources['RESULTS.txt'] = HERE / 'RESULTS.txt'
    for path in (HERE / 'source-reproduction').iterdir():
        assert path.is_file() and not path.is_symlink()
        sources['source-reproduction/' + path.name] = path
    sources['reference/index.json'] = DEVELOPMENT / 'pfaffian-native/index.json'
    sources['reference/methods-results.tar.gz'] = DEVELOPMENT / 'pfaffian-native/methods-results.tar.gz'
    sources['reference/stanene-convergence-index.json'] = DEVELOPMENT / 'stanene-convergence/index.json'
    for name in ('run_frozen_pfaffian.py', 'freeze_native_localizer_source.py', 'check_pfaffian_api.py',
                 'fingerprint_pfaffian_build.py', 'package_pfaffian_build.py'):
        sources['local-orchestration/' + name] = HERE.parent / name
    sources['tools/verify_pfaffian_bundle.py'] = HERE.parent / 'verify_pfaffian_bundle.py'
    files = {name: path.read_bytes() for name, path in sources.items()}
    numerical_result = verify(files)
    manifest = {'files': {name: {'sha256': sha(path), 'bytes': len(files[name])}
                          for name, path in sorted(sources.items())},
                'scope': 'Standalone native C++ rebuild and replay of historical matrices. '
                         'Not a full CP2K/MPI validation or new SCF dataset.'}
    with archive_path.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as archive:
                for name, data in sorted(files.items()):
                    info = tarfile.TarInfo(name)
                    info.size, info.mode = len(data), 0o644
                    archive.addfile(info, io.BytesIO(data))
                data = (json.dumps(manifest, indent=2) + '\n').encode()
                info = tarfile.TarInfo('manifest.json')
                info.size, info.mode = len(data), 0o644
                archive.addfile(info, io.BytesIO(data))
    assert all(sha(path) == manifest['files'][name]['sha256'] for name, path in sources.items())
    assert verify(unpack(archive_path.read_bytes())) == numerical_result
    result = {'archive': archive_path.name, 'sha256': sha(archive_path), 'bytes': archive_path.stat().st_size,
              'payload_files': len(files), 'numerical_comparison': numerical_result}
    json_new(HERE / 'bundle-result.json', result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
