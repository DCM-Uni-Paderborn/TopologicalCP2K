"""Exercise the frozen native C ABI without substituting for Fortran/MPI tests."""

import ctypes as ct
import json
import math
from pathlib import Path
import sys

import numpy as np

from run_frozen_pfaffian import HERE, json_new, library_guard, sha


def main():
    path = library_guard()
    library = ct.CDLL(str(path))
    ip = ct.POINTER(ct.c_int)
    dp = ct.POINTER(ct.c_double)
    lp = ct.POINTER(ct.c_longlong)
    pf = library.cp2k_tacho_pfaffian_limited
    pf.argtypes = [ct.c_int, ct.c_int, ip, ip, dp, ct.c_double, ip, dp, lp, ct.c_longlong, lp]
    pf.restype = ct.c_int
    z2 = library.cp2k_tacho_z2_limited
    z2.argtypes = [ct.c_int, ct.c_int, ip, ip, dp, dp, ct.c_double, ct.c_double,
                  ct.c_double, ip, dp, lp, ct.c_longlong, lp]
    z2.restype = ct.c_int
    records = []

    def check(label, status, expected, sign, residual, fill, peak, expected_sign=0):
        record = dict(case=label, status=status, expected_status=expected, sign=sign.value,
                      expected_sign=expected_sign, residual=residual.value,
                      fill=fill.value, peak_bytes=peak.value)
        records.append(record)
        assert status == expected, record
        assert sign.value == expected_sign, record
        assert math.isfinite(residual.value) and residual.value >= 0, record
        assert fill.value >= 0 and peak.value >= 0, record
        if status == 0:
            assert residual.value <= 1e-10, record
        return record

    def raw(label, matrix=None, *, n=None, rows=None, cols=None, values=None,
            nnz=None, tolerance=1e-10, budget=2**32, expected=0, expected_sign=1):
        if matrix is not None:
            n = matrix.shape[0]
            ii, jj = np.indices(matrix.shape)
            rows, cols, values = ii.ravel()+1, jj.ravel()+1, matrix.ravel()
        rows = np.ascontiguousarray(rows, dtype=np.int32)
        cols = np.ascontiguousarray(cols, dtype=np.int32)
        values = np.ascontiguousarray(values, dtype=np.float64)
        sign, residual, fill, peak = ct.c_int(99), ct.c_double(-9), ct.c_longlong(-9), ct.c_longlong(-9)
        status = pf(n, len(values) if nnz is None else nnz, rows.ctypes.data_as(ip),
                    cols.ctypes.data_as(ip), values.ctypes.data_as(dp), tolerance,
                    ct.byref(sign), ct.byref(residual), ct.byref(fill), budget, ct.byref(peak))
        return check(label, status, expected, sign, residual, fill, peak, expected_sign)

    a = np.zeros((8, 8))
    for i, j, v in [(0, 1, -1), (0, 5, 1), (0, 7, -1), (1, 6, -1), (2, 3, 1),
                    (2, 7, -3), (3, 4, -1), (4, 5, 1), (6, 7, 1)]:
        a[i, j], a[j, i] = v, -v
    measured = raw('connected-pfaffian-three', a)['peak_bytes']
    assert measured > 8 and measured % 8 == 0
    assert raw('exact-budget', a, budget=measured)['peak_bytes'] == measured
    for budget in (1, 7, 8, measured-8, measured-1):
        result = raw(f'insufficient-budget-{budget}', a, budget=budget, expected=-6, expected_sign=0)
        assert result['peak_bytes'] <= budget
    for budget in (0, -1):
        raw(f'invalid-budget-{budget}', a, budget=budget, expected=-1, expected_sign=0)
    raw('larger-budget', a, budget=measured+1)
    raw('largest-integer-budget', a, budget=2**63-1)
    for value, label in [(0.0, 'zero'), (-1.0, 'negative'), (math.nan, 'nan'),
                         (math.inf, 'inf'), (-math.inf, 'negative-inf')]:
        raw('tolerance-'+label, a, tolerance=value, expected=-1, expected_sign=0)
    for n in (-1, 0, 1, 3):
        raw(f'invalid-order-{n}', n=n, rows=[1, 2], cols=[2, 1], values=[1, -1],
            expected=-1, expected_sign=0)
    raw('negative-nnz', a, nnz=-1, expected=-1, expected_sign=0)
    for rows, cols, label in [([0, 2], [2, 1], 'zero-row'), ([1, 3], [2, 1], 'large-row'),
                               ([1, 2], [0, 1], 'zero-column'), ([1, 2], [3, 1], 'large-column')]:
        raw(label, n=2, rows=rows, cols=cols, values=[1, -1], expected=-1, expected_sign=0)
    for value, label in [(math.nan, 'nan'), (math.inf, 'inf'), (-math.inf, 'negative-inf')]:
        raw('matrix-'+label, n=2, rows=[1, 2], cols=[2, 1], values=[value, -value],
            expected=-1, expected_sign=0)
    raw('overflowing-additive-coordinates', n=2, rows=[1, 1, 2, 2], cols=[2, 2, 1, 1],
        values=[1e308, 1e308, -1e308, -1e308], expected=-1, expected_sign=0)
    raw('additive-coordinates', n=2, rows=[1, 1, 2, 2], cols=[2, 2, 1, 1], values=[2, -1, -2, 1])
    raw('non-skew', np.array([[0, 1], [1, 0]]), expected=-1, expected_sign=0)
    raw('nonzero-diagonal', np.array([[1, 1], [-1, 0]]), expected=-1, expected_sign=0)
    raw('zero-matrix', np.zeros((8, 8)), expected=1, expected_sign=0)
    raw('empty-coordinates', n=8, rows=[], cols=[], values=[], expected=1, expected_sign=0)
    raw('unresolved-pivot', np.array([[0, 1, 0, 0], [-1, 0, 0, 0],
                                    [0, 0, 0, 1e-12], [0, 0, -1e-12, 0]]),
        expected=1, expected_sign=0)
    swapped = a[[1, 0, 2, 3, 4, 5, 6, 7]][:, [1, 0, 2, 3, 4, 5, 6, 7]]
    raw('odd-permutation', swapped, expected_sign=-1)
    for scale in (1e-120, 1e120):
        raw(f'scale-{scale}', scale*a)
    raw('valid-after-failures', a)

    atomic = np.diag([1.0, 1.0, -1.0, -1.0]).astype(complex)
    identity = np.eye(4, dtype=complex)

    def zquery(label, localizer=atomic, metric=identity, *, tolerance=1e-10,
               ratio=1.0, gap=0.9, order=8, budget=2**32, expected=0):
        def realify(m):
            return np.block([[m.real, -m.imag], [m.imag, m.real]])
        ii, jj = np.tril_indices(8)
        rows = np.ascontiguousarray(ii+1, dtype=np.int32)
        cols = np.ascontiguousarray(jj+1, dtype=np.int32)
        aa = np.ascontiguousarray(realify(localizer)[ii, jj])
        bb = np.ascontiguousarray(realify(metric)[ii, jj])
        index, residual, fill, peak = ct.c_int(99), ct.c_double(-9), ct.c_longlong(-9), ct.c_longlong(-9)
        status = z2(order, len(aa), rows.ctypes.data_as(ip), cols.ctypes.data_as(ip),
                    aa.ctypes.data_as(dp), bb.ctypes.data_as(dp), tolerance, ratio, gap,
                    ct.byref(index), ct.byref(residual), ct.byref(fill), budget, ct.byref(peak))
        return check(label, status, expected, index, residual, fill, peak)

    zquery('z2-atomic')
    for tolerance, label in [(0, 'zero'), (1, 'one'), (math.nan, 'nan'), (math.inf, 'inf')]:
        zquery('z2-tolerance-'+label, tolerance=tolerance, expected=-1)
    for ratio, label in [(0, 'zero'), (-1, 'negative'), (1.1, 'above-one'),
                         (math.nan, 'nan'), (math.inf, 'inf')]:
        zquery('z2-ratio-'+label, ratio=ratio, expected=-1)
    for gap, label in [(0, 'zero'), (-1, 'negative'), (math.nan, 'nan'), (math.inf, 'inf')]:
        zquery('z2-gap-'+label, gap=gap, expected=-1)
    for order in (0, 4, 7, 9):
        zquery(f'z2-order-{order}', order=order, expected=-1)
    zquery('z2-zero-budget', budget=0, expected=-1)
    broken = atomic.copy()
    broken[0, 0] += 1e-3
    zquery('z2-broken-tr', localizer=broken, expected=-3)
    broken_metric = identity.copy()
    broken_metric[0, 0] += 0.1
    zquery('z2-broken-tr-metric', metric=broken_metric, expected=-3)
    roundoff = atomic.copy()
    roundoff[0, 0] += 1e-12
    zquery('z2-roundoff-safe-gap', localizer=roundoff)
    zquery('z2-roundoff-too-small-gap', localizer=roundoff, gap=1e-14, expected=1)
    zquery('z2-valid-after-failures')
    report = {'passed': True, 'library_sha256': sha(path), 'script_sha256': sha(Path(__file__)),
              'queries': len(records), 'exact_budget_bytes': measured, 'results': records,
              'scope': 'Native C ABI boundary checks. Valid non-null array/output pointers are assumed. '
                       'Not Fortran/MPI wrapper validation or a positivity proof for the supplied metric.',
              'python': sys.version, 'numpy': np.__version__}
    json_new(HERE / 'api-boundaries.json', report)
    print(json.dumps({key: report[key] for key in ('passed', 'queries', 'exact_budget_bytes')}, indent=2))


if __name__ == '__main__':
    main()
